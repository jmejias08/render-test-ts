
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model clients
 * 
 */
export type clients = $Result.DefaultSelection<Prisma.$clientsPayload>
/**
 * Model offices
 * 
 */
export type offices = $Result.DefaultSelection<Prisma.$officesPayload>
/**
 * Model pays
 * 
 */
export type pays = $Result.DefaultSelection<Prisma.$paysPayload>
/**
 * Model pending_pay_tickets
 * 
 */
export type pending_pay_tickets = $Result.DefaultSelection<Prisma.$pending_pay_ticketsPayload>
/**
 * Model products
 * 
 */
export type products = $Result.DefaultSelection<Prisma.$productsPayload>
/**
 * Model ticket_details
 * 
 */
export type ticket_details = $Result.DefaultSelection<Prisma.$ticket_detailsPayload>
/**
 * Model tickets
 * 
 */
export type tickets = $Result.DefaultSelection<Prisma.$ticketsPayload>
/**
 * Model users
 * This table contains check constraints and requires additional setup for migrations. Visit https://pris.ly/d/check-constraints for more info.
 */
export type users = $Result.DefaultSelection<Prisma.$usersPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const user_role: {
  super: 'super',
  admin: 'admin',
  employee: 'employee'
};

export type user_role = (typeof user_role)[keyof typeof user_role]

}

export type user_role = $Enums.user_role

export const user_role: typeof $Enums.user_role

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Clients
 * const clients = await prisma.clients.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Clients
   * const clients = await prisma.clients.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.clients`: Exposes CRUD operations for the **clients** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Clients
    * const clients = await prisma.clients.findMany()
    * ```
    */
  get clients(): Prisma.clientsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.offices`: Exposes CRUD operations for the **offices** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Offices
    * const offices = await prisma.offices.findMany()
    * ```
    */
  get offices(): Prisma.officesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.pays`: Exposes CRUD operations for the **pays** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Pays
    * const pays = await prisma.pays.findMany()
    * ```
    */
  get pays(): Prisma.paysDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.pending_pay_tickets`: Exposes CRUD operations for the **pending_pay_tickets** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Pending_pay_tickets
    * const pending_pay_tickets = await prisma.pending_pay_tickets.findMany()
    * ```
    */
  get pending_pay_tickets(): Prisma.pending_pay_ticketsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.products`: Exposes CRUD operations for the **products** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Products
    * const products = await prisma.products.findMany()
    * ```
    */
  get products(): Prisma.productsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.ticket_details`: Exposes CRUD operations for the **ticket_details** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Ticket_details
    * const ticket_details = await prisma.ticket_details.findMany()
    * ```
    */
  get ticket_details(): Prisma.ticket_detailsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.tickets`: Exposes CRUD operations for the **tickets** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Tickets
    * const tickets = await prisma.tickets.findMany()
    * ```
    */
  get tickets(): Prisma.ticketsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.users`: Exposes CRUD operations for the **users** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.users.findMany()
    * ```
    */
  get users(): Prisma.usersDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.8.2
   * Query Engine version: 2060c79ba17c6bb9f5823312b6f6b7f4a845738e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    clients: 'clients',
    offices: 'offices',
    pays: 'pays',
    pending_pay_tickets: 'pending_pay_tickets',
    products: 'products',
    ticket_details: 'ticket_details',
    tickets: 'tickets',
    users: 'users'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "clients" | "offices" | "pays" | "pending_pay_tickets" | "products" | "ticket_details" | "tickets" | "users"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      clients: {
        payload: Prisma.$clientsPayload<ExtArgs>
        fields: Prisma.clientsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.clientsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.clientsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          findFirst: {
            args: Prisma.clientsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.clientsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          findMany: {
            args: Prisma.clientsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>[]
          }
          create: {
            args: Prisma.clientsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          createMany: {
            args: Prisma.clientsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.clientsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>[]
          }
          delete: {
            args: Prisma.clientsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          update: {
            args: Prisma.clientsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          deleteMany: {
            args: Prisma.clientsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.clientsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.clientsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>[]
          }
          upsert: {
            args: Prisma.clientsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$clientsPayload>
          }
          aggregate: {
            args: Prisma.ClientsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateClients>
          }
          groupBy: {
            args: Prisma.clientsGroupByArgs<ExtArgs>
            result: $Utils.Optional<ClientsGroupByOutputType>[]
          }
          count: {
            args: Prisma.clientsCountArgs<ExtArgs>
            result: $Utils.Optional<ClientsCountAggregateOutputType> | number
          }
        }
      }
      offices: {
        payload: Prisma.$officesPayload<ExtArgs>
        fields: Prisma.officesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.officesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.officesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          findFirst: {
            args: Prisma.officesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.officesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          findMany: {
            args: Prisma.officesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>[]
          }
          create: {
            args: Prisma.officesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          createMany: {
            args: Prisma.officesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.officesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>[]
          }
          delete: {
            args: Prisma.officesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          update: {
            args: Prisma.officesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          deleteMany: {
            args: Prisma.officesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.officesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.officesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>[]
          }
          upsert: {
            args: Prisma.officesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$officesPayload>
          }
          aggregate: {
            args: Prisma.OfficesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOffices>
          }
          groupBy: {
            args: Prisma.officesGroupByArgs<ExtArgs>
            result: $Utils.Optional<OfficesGroupByOutputType>[]
          }
          count: {
            args: Prisma.officesCountArgs<ExtArgs>
            result: $Utils.Optional<OfficesCountAggregateOutputType> | number
          }
        }
      }
      pays: {
        payload: Prisma.$paysPayload<ExtArgs>
        fields: Prisma.paysFieldRefs
        operations: {
          findUnique: {
            args: Prisma.paysFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.paysFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          findFirst: {
            args: Prisma.paysFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.paysFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          findMany: {
            args: Prisma.paysFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>[]
          }
          create: {
            args: Prisma.paysCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          createMany: {
            args: Prisma.paysCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.paysCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>[]
          }
          delete: {
            args: Prisma.paysDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          update: {
            args: Prisma.paysUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          deleteMany: {
            args: Prisma.paysDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.paysUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.paysUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>[]
          }
          upsert: {
            args: Prisma.paysUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$paysPayload>
          }
          aggregate: {
            args: Prisma.PaysAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePays>
          }
          groupBy: {
            args: Prisma.paysGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaysGroupByOutputType>[]
          }
          count: {
            args: Prisma.paysCountArgs<ExtArgs>
            result: $Utils.Optional<PaysCountAggregateOutputType> | number
          }
        }
      }
      pending_pay_tickets: {
        payload: Prisma.$pending_pay_ticketsPayload<ExtArgs>
        fields: Prisma.pending_pay_ticketsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.pending_pay_ticketsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.pending_pay_ticketsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          findFirst: {
            args: Prisma.pending_pay_ticketsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.pending_pay_ticketsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          findMany: {
            args: Prisma.pending_pay_ticketsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>[]
          }
          create: {
            args: Prisma.pending_pay_ticketsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          createMany: {
            args: Prisma.pending_pay_ticketsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.pending_pay_ticketsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>[]
          }
          delete: {
            args: Prisma.pending_pay_ticketsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          update: {
            args: Prisma.pending_pay_ticketsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          deleteMany: {
            args: Prisma.pending_pay_ticketsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.pending_pay_ticketsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.pending_pay_ticketsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>[]
          }
          upsert: {
            args: Prisma.pending_pay_ticketsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$pending_pay_ticketsPayload>
          }
          aggregate: {
            args: Prisma.Pending_pay_ticketsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePending_pay_tickets>
          }
          groupBy: {
            args: Prisma.pending_pay_ticketsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Pending_pay_ticketsGroupByOutputType>[]
          }
          count: {
            args: Prisma.pending_pay_ticketsCountArgs<ExtArgs>
            result: $Utils.Optional<Pending_pay_ticketsCountAggregateOutputType> | number
          }
        }
      }
      products: {
        payload: Prisma.$productsPayload<ExtArgs>
        fields: Prisma.productsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.productsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.productsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          findFirst: {
            args: Prisma.productsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.productsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          findMany: {
            args: Prisma.productsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>[]
          }
          create: {
            args: Prisma.productsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          createMany: {
            args: Prisma.productsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.productsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>[]
          }
          delete: {
            args: Prisma.productsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          update: {
            args: Prisma.productsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          deleteMany: {
            args: Prisma.productsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.productsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.productsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>[]
          }
          upsert: {
            args: Prisma.productsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productsPayload>
          }
          aggregate: {
            args: Prisma.ProductsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProducts>
          }
          groupBy: {
            args: Prisma.productsGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProductsGroupByOutputType>[]
          }
          count: {
            args: Prisma.productsCountArgs<ExtArgs>
            result: $Utils.Optional<ProductsCountAggregateOutputType> | number
          }
        }
      }
      ticket_details: {
        payload: Prisma.$ticket_detailsPayload<ExtArgs>
        fields: Prisma.ticket_detailsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ticket_detailsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ticket_detailsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          findFirst: {
            args: Prisma.ticket_detailsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ticket_detailsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          findMany: {
            args: Prisma.ticket_detailsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>[]
          }
          create: {
            args: Prisma.ticket_detailsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          createMany: {
            args: Prisma.ticket_detailsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ticket_detailsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>[]
          }
          delete: {
            args: Prisma.ticket_detailsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          update: {
            args: Prisma.ticket_detailsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          deleteMany: {
            args: Prisma.ticket_detailsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ticket_detailsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ticket_detailsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>[]
          }
          upsert: {
            args: Prisma.ticket_detailsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticket_detailsPayload>
          }
          aggregate: {
            args: Prisma.Ticket_detailsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTicket_details>
          }
          groupBy: {
            args: Prisma.ticket_detailsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Ticket_detailsGroupByOutputType>[]
          }
          count: {
            args: Prisma.ticket_detailsCountArgs<ExtArgs>
            result: $Utils.Optional<Ticket_detailsCountAggregateOutputType> | number
          }
        }
      }
      tickets: {
        payload: Prisma.$ticketsPayload<ExtArgs>
        fields: Prisma.ticketsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ticketsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ticketsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          findFirst: {
            args: Prisma.ticketsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ticketsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          findMany: {
            args: Prisma.ticketsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>[]
          }
          create: {
            args: Prisma.ticketsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          createMany: {
            args: Prisma.ticketsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ticketsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>[]
          }
          delete: {
            args: Prisma.ticketsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          update: {
            args: Prisma.ticketsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          deleteMany: {
            args: Prisma.ticketsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ticketsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ticketsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>[]
          }
          upsert: {
            args: Prisma.ticketsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ticketsPayload>
          }
          aggregate: {
            args: Prisma.TicketsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTickets>
          }
          groupBy: {
            args: Prisma.ticketsGroupByArgs<ExtArgs>
            result: $Utils.Optional<TicketsGroupByOutputType>[]
          }
          count: {
            args: Prisma.ticketsCountArgs<ExtArgs>
            result: $Utils.Optional<TicketsCountAggregateOutputType> | number
          }
        }
      }
      users: {
        payload: Prisma.$usersPayload<ExtArgs>
        fields: Prisma.usersFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usersFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usersFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findFirst: {
            args: Prisma.usersFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usersFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findMany: {
            args: Prisma.usersFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          create: {
            args: Prisma.usersCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          createMany: {
            args: Prisma.usersCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.usersCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          delete: {
            args: Prisma.usersDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          update: {
            args: Prisma.usersUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          deleteMany: {
            args: Prisma.usersDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usersUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.usersUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          upsert: {
            args: Prisma.usersUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          aggregate: {
            args: Prisma.UsersAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsers>
          }
          groupBy: {
            args: Prisma.usersGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsersGroupByOutputType>[]
          }
          count: {
            args: Prisma.usersCountArgs<ExtArgs>
            result: $Utils.Optional<UsersCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    clients?: clientsOmit
    offices?: officesOmit
    pays?: paysOmit
    pending_pay_tickets?: pending_pay_ticketsOmit
    products?: productsOmit
    ticket_details?: ticket_detailsOmit
    tickets?: ticketsOmit
    users?: usersOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type ClientsCountOutputType
   */

  export type ClientsCountOutputType = {
    pays: number
    tickets: number
  }

  export type ClientsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    pays?: boolean | ClientsCountOutputTypeCountPaysArgs
    tickets?: boolean | ClientsCountOutputTypeCountTicketsArgs
  }

  // Custom InputTypes
  /**
   * ClientsCountOutputType without action
   */
  export type ClientsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientsCountOutputType
     */
    select?: ClientsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ClientsCountOutputType without action
   */
  export type ClientsCountOutputTypeCountPaysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paysWhereInput
  }

  /**
   * ClientsCountOutputType without action
   */
  export type ClientsCountOutputTypeCountTicketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticketsWhereInput
  }


  /**
   * Count Type OfficesCountOutputType
   */

  export type OfficesCountOutputType = {
    clients: number
    pays: number
    products: number
    tickets: number
    users: number
  }

  export type OfficesCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | OfficesCountOutputTypeCountClientsArgs
    pays?: boolean | OfficesCountOutputTypeCountPaysArgs
    products?: boolean | OfficesCountOutputTypeCountProductsArgs
    tickets?: boolean | OfficesCountOutputTypeCountTicketsArgs
    users?: boolean | OfficesCountOutputTypeCountUsersArgs
  }

  // Custom InputTypes
  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OfficesCountOutputType
     */
    select?: OfficesCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeCountClientsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: clientsWhereInput
  }

  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeCountPaysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paysWhereInput
  }

  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeCountProductsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: productsWhereInput
  }

  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeCountTicketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticketsWhereInput
  }

  /**
   * OfficesCountOutputType without action
   */
  export type OfficesCountOutputTypeCountUsersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
  }


  /**
   * Count Type ProductsCountOutputType
   */

  export type ProductsCountOutputType = {
    ticket_details: number
  }

  export type ProductsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ticket_details?: boolean | ProductsCountOutputTypeCountTicket_detailsArgs
  }

  // Custom InputTypes
  /**
   * ProductsCountOutputType without action
   */
  export type ProductsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductsCountOutputType
     */
    select?: ProductsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ProductsCountOutputType without action
   */
  export type ProductsCountOutputTypeCountTicket_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticket_detailsWhereInput
  }


  /**
   * Count Type TicketsCountOutputType
   */

  export type TicketsCountOutputType = {
    pays: number
    ticket_details: number
  }

  export type TicketsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    pays?: boolean | TicketsCountOutputTypeCountPaysArgs
    ticket_details?: boolean | TicketsCountOutputTypeCountTicket_detailsArgs
  }

  // Custom InputTypes
  /**
   * TicketsCountOutputType without action
   */
  export type TicketsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TicketsCountOutputType
     */
    select?: TicketsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * TicketsCountOutputType without action
   */
  export type TicketsCountOutputTypeCountPaysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paysWhereInput
  }

  /**
   * TicketsCountOutputType without action
   */
  export type TicketsCountOutputTypeCountTicket_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticket_detailsWhereInput
  }


  /**
   * Count Type UsersCountOutputType
   */

  export type UsersCountOutputType = {
    tickets: number
  }

  export type UsersCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tickets?: boolean | UsersCountOutputTypeCountTicketsArgs
  }

  // Custom InputTypes
  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersCountOutputType
     */
    select?: UsersCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeCountTicketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticketsWhereInput
  }


  /**
   * Models
   */

  /**
   * Model clients
   */

  export type AggregateClients = {
    _count: ClientsCountAggregateOutputType | null
    _avg: ClientsAvgAggregateOutputType | null
    _sum: ClientsSumAggregateOutputType | null
    _min: ClientsMinAggregateOutputType | null
    _max: ClientsMaxAggregateOutputType | null
  }

  export type ClientsAvgAggregateOutputType = {
    id: number | null
    office_id: number | null
  }

  export type ClientsSumAggregateOutputType = {
    id: number | null
    office_id: number | null
  }

  export type ClientsMinAggregateOutputType = {
    id: number | null
    office_id: number | null
    id_card: string | null
    name: string | null
    phone: string | null
    email: string | null
    address: string | null
  }

  export type ClientsMaxAggregateOutputType = {
    id: number | null
    office_id: number | null
    id_card: string | null
    name: string | null
    phone: string | null
    email: string | null
    address: string | null
  }

  export type ClientsCountAggregateOutputType = {
    id: number
    office_id: number
    id_card: number
    name: number
    phone: number
    email: number
    address: number
    _all: number
  }


  export type ClientsAvgAggregateInputType = {
    id?: true
    office_id?: true
  }

  export type ClientsSumAggregateInputType = {
    id?: true
    office_id?: true
  }

  export type ClientsMinAggregateInputType = {
    id?: true
    office_id?: true
    id_card?: true
    name?: true
    phone?: true
    email?: true
    address?: true
  }

  export type ClientsMaxAggregateInputType = {
    id?: true
    office_id?: true
    id_card?: true
    name?: true
    phone?: true
    email?: true
    address?: true
  }

  export type ClientsCountAggregateInputType = {
    id?: true
    office_id?: true
    id_card?: true
    name?: true
    phone?: true
    email?: true
    address?: true
    _all?: true
  }

  export type ClientsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which clients to aggregate.
     */
    where?: clientsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of clients to fetch.
     */
    orderBy?: clientsOrderByWithRelationInput | clientsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: clientsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` clients from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` clients.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned clients
    **/
    _count?: true | ClientsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ClientsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ClientsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ClientsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ClientsMaxAggregateInputType
  }

  export type GetClientsAggregateType<T extends ClientsAggregateArgs> = {
        [P in keyof T & keyof AggregateClients]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateClients[P]>
      : GetScalarType<T[P], AggregateClients[P]>
  }




  export type clientsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: clientsWhereInput
    orderBy?: clientsOrderByWithAggregationInput | clientsOrderByWithAggregationInput[]
    by: ClientsScalarFieldEnum[] | ClientsScalarFieldEnum
    having?: clientsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ClientsCountAggregateInputType | true
    _avg?: ClientsAvgAggregateInputType
    _sum?: ClientsSumAggregateInputType
    _min?: ClientsMinAggregateInputType
    _max?: ClientsMaxAggregateInputType
  }

  export type ClientsGroupByOutputType = {
    id: number
    office_id: number | null
    id_card: string | null
    name: string | null
    phone: string | null
    email: string | null
    address: string | null
    _count: ClientsCountAggregateOutputType | null
    _avg: ClientsAvgAggregateOutputType | null
    _sum: ClientsSumAggregateOutputType | null
    _min: ClientsMinAggregateOutputType | null
    _max: ClientsMaxAggregateOutputType | null
  }

  type GetClientsGroupByPayload<T extends clientsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ClientsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ClientsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ClientsGroupByOutputType[P]>
            : GetScalarType<T[P], ClientsGroupByOutputType[P]>
        }
      >
    >


  export type clientsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    id_card?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    address?: boolean
    offices?: boolean | clients$officesArgs<ExtArgs>
    pays?: boolean | clients$paysArgs<ExtArgs>
    tickets?: boolean | clients$ticketsArgs<ExtArgs>
    _count?: boolean | ClientsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["clients"]>

  export type clientsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    id_card?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    address?: boolean
    offices?: boolean | clients$officesArgs<ExtArgs>
  }, ExtArgs["result"]["clients"]>

  export type clientsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    id_card?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    address?: boolean
    offices?: boolean | clients$officesArgs<ExtArgs>
  }, ExtArgs["result"]["clients"]>

  export type clientsSelectScalar = {
    id?: boolean
    office_id?: boolean
    id_card?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    address?: boolean
  }

  export type clientsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "office_id" | "id_card" | "name" | "phone" | "email" | "address", ExtArgs["result"]["clients"]>
  export type clientsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | clients$officesArgs<ExtArgs>
    pays?: boolean | clients$paysArgs<ExtArgs>
    tickets?: boolean | clients$ticketsArgs<ExtArgs>
    _count?: boolean | ClientsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type clientsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | clients$officesArgs<ExtArgs>
  }
  export type clientsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | clients$officesArgs<ExtArgs>
  }

  export type $clientsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "clients"
    objects: {
      offices: Prisma.$officesPayload<ExtArgs> | null
      pays: Prisma.$paysPayload<ExtArgs>[]
      tickets: Prisma.$ticketsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      office_id: number | null
      id_card: string | null
      name: string | null
      phone: string | null
      email: string | null
      address: string | null
    }, ExtArgs["result"]["clients"]>
    composites: {}
  }

  type clientsGetPayload<S extends boolean | null | undefined | clientsDefaultArgs> = $Result.GetResult<Prisma.$clientsPayload, S>

  type clientsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<clientsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ClientsCountAggregateInputType | true
    }

  export interface clientsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['clients'], meta: { name: 'clients' } }
    /**
     * Find zero or one Clients that matches the filter.
     * @param {clientsFindUniqueArgs} args - Arguments to find a Clients
     * @example
     * // Get one Clients
     * const clients = await prisma.clients.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends clientsFindUniqueArgs>(args: SelectSubset<T, clientsFindUniqueArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Clients that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {clientsFindUniqueOrThrowArgs} args - Arguments to find a Clients
     * @example
     * // Get one Clients
     * const clients = await prisma.clients.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends clientsFindUniqueOrThrowArgs>(args: SelectSubset<T, clientsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Clients that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsFindFirstArgs} args - Arguments to find a Clients
     * @example
     * // Get one Clients
     * const clients = await prisma.clients.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends clientsFindFirstArgs>(args?: SelectSubset<T, clientsFindFirstArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Clients that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsFindFirstOrThrowArgs} args - Arguments to find a Clients
     * @example
     * // Get one Clients
     * const clients = await prisma.clients.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends clientsFindFirstOrThrowArgs>(args?: SelectSubset<T, clientsFindFirstOrThrowArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Clients that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Clients
     * const clients = await prisma.clients.findMany()
     * 
     * // Get first 10 Clients
     * const clients = await prisma.clients.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const clientsWithIdOnly = await prisma.clients.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends clientsFindManyArgs>(args?: SelectSubset<T, clientsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Clients.
     * @param {clientsCreateArgs} args - Arguments to create a Clients.
     * @example
     * // Create one Clients
     * const Clients = await prisma.clients.create({
     *   data: {
     *     // ... data to create a Clients
     *   }
     * })
     * 
     */
    create<T extends clientsCreateArgs>(args: SelectSubset<T, clientsCreateArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Clients.
     * @param {clientsCreateManyArgs} args - Arguments to create many Clients.
     * @example
     * // Create many Clients
     * const clients = await prisma.clients.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends clientsCreateManyArgs>(args?: SelectSubset<T, clientsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Clients and returns the data saved in the database.
     * @param {clientsCreateManyAndReturnArgs} args - Arguments to create many Clients.
     * @example
     * // Create many Clients
     * const clients = await prisma.clients.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Clients and only return the `id`
     * const clientsWithIdOnly = await prisma.clients.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends clientsCreateManyAndReturnArgs>(args?: SelectSubset<T, clientsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Clients.
     * @param {clientsDeleteArgs} args - Arguments to delete one Clients.
     * @example
     * // Delete one Clients
     * const Clients = await prisma.clients.delete({
     *   where: {
     *     // ... filter to delete one Clients
     *   }
     * })
     * 
     */
    delete<T extends clientsDeleteArgs>(args: SelectSubset<T, clientsDeleteArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Clients.
     * @param {clientsUpdateArgs} args - Arguments to update one Clients.
     * @example
     * // Update one Clients
     * const clients = await prisma.clients.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends clientsUpdateArgs>(args: SelectSubset<T, clientsUpdateArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Clients.
     * @param {clientsDeleteManyArgs} args - Arguments to filter Clients to delete.
     * @example
     * // Delete a few Clients
     * const { count } = await prisma.clients.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends clientsDeleteManyArgs>(args?: SelectSubset<T, clientsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Clients.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Clients
     * const clients = await prisma.clients.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends clientsUpdateManyArgs>(args: SelectSubset<T, clientsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Clients and returns the data updated in the database.
     * @param {clientsUpdateManyAndReturnArgs} args - Arguments to update many Clients.
     * @example
     * // Update many Clients
     * const clients = await prisma.clients.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Clients and only return the `id`
     * const clientsWithIdOnly = await prisma.clients.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends clientsUpdateManyAndReturnArgs>(args: SelectSubset<T, clientsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Clients.
     * @param {clientsUpsertArgs} args - Arguments to update or create a Clients.
     * @example
     * // Update or create a Clients
     * const clients = await prisma.clients.upsert({
     *   create: {
     *     // ... data to create a Clients
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Clients we want to update
     *   }
     * })
     */
    upsert<T extends clientsUpsertArgs>(args: SelectSubset<T, clientsUpsertArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Clients.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsCountArgs} args - Arguments to filter Clients to count.
     * @example
     * // Count the number of Clients
     * const count = await prisma.clients.count({
     *   where: {
     *     // ... the filter for the Clients we want to count
     *   }
     * })
    **/
    count<T extends clientsCountArgs>(
      args?: Subset<T, clientsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ClientsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Clients.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ClientsAggregateArgs>(args: Subset<T, ClientsAggregateArgs>): Prisma.PrismaPromise<GetClientsAggregateType<T>>

    /**
     * Group by Clients.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {clientsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends clientsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: clientsGroupByArgs['orderBy'] }
        : { orderBy?: clientsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, clientsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetClientsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the clients model
   */
  readonly fields: clientsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for clients.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__clientsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    offices<T extends clients$officesArgs<ExtArgs> = {}>(args?: Subset<T, clients$officesArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    pays<T extends clients$paysArgs<ExtArgs> = {}>(args?: Subset<T, clients$paysArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    tickets<T extends clients$ticketsArgs<ExtArgs> = {}>(args?: Subset<T, clients$ticketsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the clients model
   */
  interface clientsFieldRefs {
    readonly id: FieldRef<"clients", 'Int'>
    readonly office_id: FieldRef<"clients", 'Int'>
    readonly id_card: FieldRef<"clients", 'String'>
    readonly name: FieldRef<"clients", 'String'>
    readonly phone: FieldRef<"clients", 'String'>
    readonly email: FieldRef<"clients", 'String'>
    readonly address: FieldRef<"clients", 'String'>
  }
    

  // Custom InputTypes
  /**
   * clients findUnique
   */
  export type clientsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter, which clients to fetch.
     */
    where: clientsWhereUniqueInput
  }

  /**
   * clients findUniqueOrThrow
   */
  export type clientsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter, which clients to fetch.
     */
    where: clientsWhereUniqueInput
  }

  /**
   * clients findFirst
   */
  export type clientsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter, which clients to fetch.
     */
    where?: clientsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of clients to fetch.
     */
    orderBy?: clientsOrderByWithRelationInput | clientsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for clients.
     */
    cursor?: clientsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` clients from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` clients.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of clients.
     */
    distinct?: ClientsScalarFieldEnum | ClientsScalarFieldEnum[]
  }

  /**
   * clients findFirstOrThrow
   */
  export type clientsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter, which clients to fetch.
     */
    where?: clientsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of clients to fetch.
     */
    orderBy?: clientsOrderByWithRelationInput | clientsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for clients.
     */
    cursor?: clientsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` clients from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` clients.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of clients.
     */
    distinct?: ClientsScalarFieldEnum | ClientsScalarFieldEnum[]
  }

  /**
   * clients findMany
   */
  export type clientsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter, which clients to fetch.
     */
    where?: clientsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of clients to fetch.
     */
    orderBy?: clientsOrderByWithRelationInput | clientsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing clients.
     */
    cursor?: clientsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` clients from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` clients.
     */
    skip?: number
    distinct?: ClientsScalarFieldEnum | ClientsScalarFieldEnum[]
  }

  /**
   * clients create
   */
  export type clientsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * The data needed to create a clients.
     */
    data?: XOR<clientsCreateInput, clientsUncheckedCreateInput>
  }

  /**
   * clients createMany
   */
  export type clientsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many clients.
     */
    data: clientsCreateManyInput | clientsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * clients createManyAndReturn
   */
  export type clientsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * The data used to create many clients.
     */
    data: clientsCreateManyInput | clientsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * clients update
   */
  export type clientsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * The data needed to update a clients.
     */
    data: XOR<clientsUpdateInput, clientsUncheckedUpdateInput>
    /**
     * Choose, which clients to update.
     */
    where: clientsWhereUniqueInput
  }

  /**
   * clients updateMany
   */
  export type clientsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update clients.
     */
    data: XOR<clientsUpdateManyMutationInput, clientsUncheckedUpdateManyInput>
    /**
     * Filter which clients to update
     */
    where?: clientsWhereInput
    /**
     * Limit how many clients to update.
     */
    limit?: number
  }

  /**
   * clients updateManyAndReturn
   */
  export type clientsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * The data used to update clients.
     */
    data: XOR<clientsUpdateManyMutationInput, clientsUncheckedUpdateManyInput>
    /**
     * Filter which clients to update
     */
    where?: clientsWhereInput
    /**
     * Limit how many clients to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * clients upsert
   */
  export type clientsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * The filter to search for the clients to update in case it exists.
     */
    where: clientsWhereUniqueInput
    /**
     * In case the clients found by the `where` argument doesn't exist, create a new clients with this data.
     */
    create: XOR<clientsCreateInput, clientsUncheckedCreateInput>
    /**
     * In case the clients was found with the provided `where` argument, update it with this data.
     */
    update: XOR<clientsUpdateInput, clientsUncheckedUpdateInput>
  }

  /**
   * clients delete
   */
  export type clientsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    /**
     * Filter which clients to delete.
     */
    where: clientsWhereUniqueInput
  }

  /**
   * clients deleteMany
   */
  export type clientsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which clients to delete
     */
    where?: clientsWhereInput
    /**
     * Limit how many clients to delete.
     */
    limit?: number
  }

  /**
   * clients.offices
   */
  export type clients$officesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    where?: officesWhereInput
  }

  /**
   * clients.pays
   */
  export type clients$paysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    where?: paysWhereInput
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    cursor?: paysWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * clients.tickets
   */
  export type clients$ticketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    where?: ticketsWhereInput
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    cursor?: ticketsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * clients without action
   */
  export type clientsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
  }


  /**
   * Model offices
   */

  export type AggregateOffices = {
    _count: OfficesCountAggregateOutputType | null
    _avg: OfficesAvgAggregateOutputType | null
    _sum: OfficesSumAggregateOutputType | null
    _min: OfficesMinAggregateOutputType | null
    _max: OfficesMaxAggregateOutputType | null
  }

  export type OfficesAvgAggregateOutputType = {
    id: number | null
  }

  export type OfficesSumAggregateOutputType = {
    id: number | null
  }

  export type OfficesMinAggregateOutputType = {
    id: number | null
    name: string | null
    phone: string | null
    address: string | null
    email: string | null
    id_card: string | null
  }

  export type OfficesMaxAggregateOutputType = {
    id: number | null
    name: string | null
    phone: string | null
    address: string | null
    email: string | null
    id_card: string | null
  }

  export type OfficesCountAggregateOutputType = {
    id: number
    name: number
    phone: number
    address: number
    email: number
    id_card: number
    _all: number
  }


  export type OfficesAvgAggregateInputType = {
    id?: true
  }

  export type OfficesSumAggregateInputType = {
    id?: true
  }

  export type OfficesMinAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    address?: true
    email?: true
    id_card?: true
  }

  export type OfficesMaxAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    address?: true
    email?: true
    id_card?: true
  }

  export type OfficesCountAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    address?: true
    email?: true
    id_card?: true
    _all?: true
  }

  export type OfficesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which offices to aggregate.
     */
    where?: officesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of offices to fetch.
     */
    orderBy?: officesOrderByWithRelationInput | officesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: officesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` offices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` offices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned offices
    **/
    _count?: true | OfficesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OfficesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OfficesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OfficesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OfficesMaxAggregateInputType
  }

  export type GetOfficesAggregateType<T extends OfficesAggregateArgs> = {
        [P in keyof T & keyof AggregateOffices]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOffices[P]>
      : GetScalarType<T[P], AggregateOffices[P]>
  }




  export type officesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: officesWhereInput
    orderBy?: officesOrderByWithAggregationInput | officesOrderByWithAggregationInput[]
    by: OfficesScalarFieldEnum[] | OfficesScalarFieldEnum
    having?: officesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OfficesCountAggregateInputType | true
    _avg?: OfficesAvgAggregateInputType
    _sum?: OfficesSumAggregateInputType
    _min?: OfficesMinAggregateInputType
    _max?: OfficesMaxAggregateInputType
  }

  export type OfficesGroupByOutputType = {
    id: number
    name: string | null
    phone: string | null
    address: string | null
    email: string | null
    id_card: string | null
    _count: OfficesCountAggregateOutputType | null
    _avg: OfficesAvgAggregateOutputType | null
    _sum: OfficesSumAggregateOutputType | null
    _min: OfficesMinAggregateOutputType | null
    _max: OfficesMaxAggregateOutputType | null
  }

  type GetOfficesGroupByPayload<T extends officesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OfficesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OfficesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OfficesGroupByOutputType[P]>
            : GetScalarType<T[P], OfficesGroupByOutputType[P]>
        }
      >
    >


  export type officesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    phone?: boolean
    address?: boolean
    email?: boolean
    id_card?: boolean
    clients?: boolean | offices$clientsArgs<ExtArgs>
    pays?: boolean | offices$paysArgs<ExtArgs>
    products?: boolean | offices$productsArgs<ExtArgs>
    tickets?: boolean | offices$ticketsArgs<ExtArgs>
    users?: boolean | offices$usersArgs<ExtArgs>
    _count?: boolean | OfficesCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["offices"]>

  export type officesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    phone?: boolean
    address?: boolean
    email?: boolean
    id_card?: boolean
  }, ExtArgs["result"]["offices"]>

  export type officesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    phone?: boolean
    address?: boolean
    email?: boolean
    id_card?: boolean
  }, ExtArgs["result"]["offices"]>

  export type officesSelectScalar = {
    id?: boolean
    name?: boolean
    phone?: boolean
    address?: boolean
    email?: boolean
    id_card?: boolean
  }

  export type officesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "phone" | "address" | "email" | "id_card", ExtArgs["result"]["offices"]>
  export type officesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | offices$clientsArgs<ExtArgs>
    pays?: boolean | offices$paysArgs<ExtArgs>
    products?: boolean | offices$productsArgs<ExtArgs>
    tickets?: boolean | offices$ticketsArgs<ExtArgs>
    users?: boolean | offices$usersArgs<ExtArgs>
    _count?: boolean | OfficesCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type officesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type officesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $officesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "offices"
    objects: {
      clients: Prisma.$clientsPayload<ExtArgs>[]
      pays: Prisma.$paysPayload<ExtArgs>[]
      products: Prisma.$productsPayload<ExtArgs>[]
      tickets: Prisma.$ticketsPayload<ExtArgs>[]
      users: Prisma.$usersPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string | null
      phone: string | null
      address: string | null
      email: string | null
      id_card: string | null
    }, ExtArgs["result"]["offices"]>
    composites: {}
  }

  type officesGetPayload<S extends boolean | null | undefined | officesDefaultArgs> = $Result.GetResult<Prisma.$officesPayload, S>

  type officesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<officesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OfficesCountAggregateInputType | true
    }

  export interface officesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['offices'], meta: { name: 'offices' } }
    /**
     * Find zero or one Offices that matches the filter.
     * @param {officesFindUniqueArgs} args - Arguments to find a Offices
     * @example
     * // Get one Offices
     * const offices = await prisma.offices.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends officesFindUniqueArgs>(args: SelectSubset<T, officesFindUniqueArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Offices that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {officesFindUniqueOrThrowArgs} args - Arguments to find a Offices
     * @example
     * // Get one Offices
     * const offices = await prisma.offices.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends officesFindUniqueOrThrowArgs>(args: SelectSubset<T, officesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Offices that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesFindFirstArgs} args - Arguments to find a Offices
     * @example
     * // Get one Offices
     * const offices = await prisma.offices.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends officesFindFirstArgs>(args?: SelectSubset<T, officesFindFirstArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Offices that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesFindFirstOrThrowArgs} args - Arguments to find a Offices
     * @example
     * // Get one Offices
     * const offices = await prisma.offices.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends officesFindFirstOrThrowArgs>(args?: SelectSubset<T, officesFindFirstOrThrowArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Offices that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Offices
     * const offices = await prisma.offices.findMany()
     * 
     * // Get first 10 Offices
     * const offices = await prisma.offices.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const officesWithIdOnly = await prisma.offices.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends officesFindManyArgs>(args?: SelectSubset<T, officesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Offices.
     * @param {officesCreateArgs} args - Arguments to create a Offices.
     * @example
     * // Create one Offices
     * const Offices = await prisma.offices.create({
     *   data: {
     *     // ... data to create a Offices
     *   }
     * })
     * 
     */
    create<T extends officesCreateArgs>(args: SelectSubset<T, officesCreateArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Offices.
     * @param {officesCreateManyArgs} args - Arguments to create many Offices.
     * @example
     * // Create many Offices
     * const offices = await prisma.offices.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends officesCreateManyArgs>(args?: SelectSubset<T, officesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Offices and returns the data saved in the database.
     * @param {officesCreateManyAndReturnArgs} args - Arguments to create many Offices.
     * @example
     * // Create many Offices
     * const offices = await prisma.offices.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Offices and only return the `id`
     * const officesWithIdOnly = await prisma.offices.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends officesCreateManyAndReturnArgs>(args?: SelectSubset<T, officesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Offices.
     * @param {officesDeleteArgs} args - Arguments to delete one Offices.
     * @example
     * // Delete one Offices
     * const Offices = await prisma.offices.delete({
     *   where: {
     *     // ... filter to delete one Offices
     *   }
     * })
     * 
     */
    delete<T extends officesDeleteArgs>(args: SelectSubset<T, officesDeleteArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Offices.
     * @param {officesUpdateArgs} args - Arguments to update one Offices.
     * @example
     * // Update one Offices
     * const offices = await prisma.offices.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends officesUpdateArgs>(args: SelectSubset<T, officesUpdateArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Offices.
     * @param {officesDeleteManyArgs} args - Arguments to filter Offices to delete.
     * @example
     * // Delete a few Offices
     * const { count } = await prisma.offices.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends officesDeleteManyArgs>(args?: SelectSubset<T, officesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Offices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Offices
     * const offices = await prisma.offices.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends officesUpdateManyArgs>(args: SelectSubset<T, officesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Offices and returns the data updated in the database.
     * @param {officesUpdateManyAndReturnArgs} args - Arguments to update many Offices.
     * @example
     * // Update many Offices
     * const offices = await prisma.offices.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Offices and only return the `id`
     * const officesWithIdOnly = await prisma.offices.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends officesUpdateManyAndReturnArgs>(args: SelectSubset<T, officesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Offices.
     * @param {officesUpsertArgs} args - Arguments to update or create a Offices.
     * @example
     * // Update or create a Offices
     * const offices = await prisma.offices.upsert({
     *   create: {
     *     // ... data to create a Offices
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Offices we want to update
     *   }
     * })
     */
    upsert<T extends officesUpsertArgs>(args: SelectSubset<T, officesUpsertArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Offices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesCountArgs} args - Arguments to filter Offices to count.
     * @example
     * // Count the number of Offices
     * const count = await prisma.offices.count({
     *   where: {
     *     // ... the filter for the Offices we want to count
     *   }
     * })
    **/
    count<T extends officesCountArgs>(
      args?: Subset<T, officesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OfficesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Offices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OfficesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OfficesAggregateArgs>(args: Subset<T, OfficesAggregateArgs>): Prisma.PrismaPromise<GetOfficesAggregateType<T>>

    /**
     * Group by Offices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {officesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends officesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: officesGroupByArgs['orderBy'] }
        : { orderBy?: officesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, officesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOfficesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the offices model
   */
  readonly fields: officesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for offices.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__officesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    clients<T extends offices$clientsArgs<ExtArgs> = {}>(args?: Subset<T, offices$clientsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    pays<T extends offices$paysArgs<ExtArgs> = {}>(args?: Subset<T, offices$paysArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    products<T extends offices$productsArgs<ExtArgs> = {}>(args?: Subset<T, offices$productsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    tickets<T extends offices$ticketsArgs<ExtArgs> = {}>(args?: Subset<T, offices$ticketsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    users<T extends offices$usersArgs<ExtArgs> = {}>(args?: Subset<T, offices$usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the offices model
   */
  interface officesFieldRefs {
    readonly id: FieldRef<"offices", 'Int'>
    readonly name: FieldRef<"offices", 'String'>
    readonly phone: FieldRef<"offices", 'String'>
    readonly address: FieldRef<"offices", 'String'>
    readonly email: FieldRef<"offices", 'String'>
    readonly id_card: FieldRef<"offices", 'String'>
  }
    

  // Custom InputTypes
  /**
   * offices findUnique
   */
  export type officesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter, which offices to fetch.
     */
    where: officesWhereUniqueInput
  }

  /**
   * offices findUniqueOrThrow
   */
  export type officesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter, which offices to fetch.
     */
    where: officesWhereUniqueInput
  }

  /**
   * offices findFirst
   */
  export type officesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter, which offices to fetch.
     */
    where?: officesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of offices to fetch.
     */
    orderBy?: officesOrderByWithRelationInput | officesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for offices.
     */
    cursor?: officesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` offices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` offices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of offices.
     */
    distinct?: OfficesScalarFieldEnum | OfficesScalarFieldEnum[]
  }

  /**
   * offices findFirstOrThrow
   */
  export type officesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter, which offices to fetch.
     */
    where?: officesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of offices to fetch.
     */
    orderBy?: officesOrderByWithRelationInput | officesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for offices.
     */
    cursor?: officesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` offices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` offices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of offices.
     */
    distinct?: OfficesScalarFieldEnum | OfficesScalarFieldEnum[]
  }

  /**
   * offices findMany
   */
  export type officesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter, which offices to fetch.
     */
    where?: officesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of offices to fetch.
     */
    orderBy?: officesOrderByWithRelationInput | officesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing offices.
     */
    cursor?: officesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` offices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` offices.
     */
    skip?: number
    distinct?: OfficesScalarFieldEnum | OfficesScalarFieldEnum[]
  }

  /**
   * offices create
   */
  export type officesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * The data needed to create a offices.
     */
    data?: XOR<officesCreateInput, officesUncheckedCreateInput>
  }

  /**
   * offices createMany
   */
  export type officesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many offices.
     */
    data: officesCreateManyInput | officesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * offices createManyAndReturn
   */
  export type officesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * The data used to create many offices.
     */
    data: officesCreateManyInput | officesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * offices update
   */
  export type officesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * The data needed to update a offices.
     */
    data: XOR<officesUpdateInput, officesUncheckedUpdateInput>
    /**
     * Choose, which offices to update.
     */
    where: officesWhereUniqueInput
  }

  /**
   * offices updateMany
   */
  export type officesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update offices.
     */
    data: XOR<officesUpdateManyMutationInput, officesUncheckedUpdateManyInput>
    /**
     * Filter which offices to update
     */
    where?: officesWhereInput
    /**
     * Limit how many offices to update.
     */
    limit?: number
  }

  /**
   * offices updateManyAndReturn
   */
  export type officesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * The data used to update offices.
     */
    data: XOR<officesUpdateManyMutationInput, officesUncheckedUpdateManyInput>
    /**
     * Filter which offices to update
     */
    where?: officesWhereInput
    /**
     * Limit how many offices to update.
     */
    limit?: number
  }

  /**
   * offices upsert
   */
  export type officesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * The filter to search for the offices to update in case it exists.
     */
    where: officesWhereUniqueInput
    /**
     * In case the offices found by the `where` argument doesn't exist, create a new offices with this data.
     */
    create: XOR<officesCreateInput, officesUncheckedCreateInput>
    /**
     * In case the offices was found with the provided `where` argument, update it with this data.
     */
    update: XOR<officesUpdateInput, officesUncheckedUpdateInput>
  }

  /**
   * offices delete
   */
  export type officesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    /**
     * Filter which offices to delete.
     */
    where: officesWhereUniqueInput
  }

  /**
   * offices deleteMany
   */
  export type officesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which offices to delete
     */
    where?: officesWhereInput
    /**
     * Limit how many offices to delete.
     */
    limit?: number
  }

  /**
   * offices.clients
   */
  export type offices$clientsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    where?: clientsWhereInput
    orderBy?: clientsOrderByWithRelationInput | clientsOrderByWithRelationInput[]
    cursor?: clientsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ClientsScalarFieldEnum | ClientsScalarFieldEnum[]
  }

  /**
   * offices.pays
   */
  export type offices$paysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    where?: paysWhereInput
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    cursor?: paysWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * offices.products
   */
  export type offices$productsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    where?: productsWhereInput
    orderBy?: productsOrderByWithRelationInput | productsOrderByWithRelationInput[]
    cursor?: productsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProductsScalarFieldEnum | ProductsScalarFieldEnum[]
  }

  /**
   * offices.tickets
   */
  export type offices$ticketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    where?: ticketsWhereInput
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    cursor?: ticketsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * offices.users
   */
  export type offices$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    where?: usersWhereInput
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    cursor?: usersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * offices without action
   */
  export type officesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
  }


  /**
   * Model pays
   */

  export type AggregatePays = {
    _count: PaysCountAggregateOutputType | null
    _avg: PaysAvgAggregateOutputType | null
    _sum: PaysSumAggregateOutputType | null
    _min: PaysMinAggregateOutputType | null
    _max: PaysMaxAggregateOutputType | null
  }

  export type PaysAvgAggregateOutputType = {
    id: number | null
    office_id: number | null
    ticket_id: number | null
    client_id: number | null
    cash: Decimal | null
    transfer: Decimal | null
    card: Decimal | null
    sinpe: Decimal | null
    bank_check: Decimal | null
    mixed: Decimal | null
  }

  export type PaysSumAggregateOutputType = {
    id: number | null
    office_id: number | null
    ticket_id: number | null
    client_id: number | null
    cash: Decimal | null
    transfer: Decimal | null
    card: Decimal | null
    sinpe: Decimal | null
    bank_check: Decimal | null
    mixed: Decimal | null
  }

  export type PaysMinAggregateOutputType = {
    id: number | null
    office_id: number | null
    ticket_id: number | null
    client_id: number | null
    type: string | null
    cash: Decimal | null
    transfer: Decimal | null
    card: Decimal | null
    sinpe: Decimal | null
    bank_check: Decimal | null
    mixed: Decimal | null
  }

  export type PaysMaxAggregateOutputType = {
    id: number | null
    office_id: number | null
    ticket_id: number | null
    client_id: number | null
    type: string | null
    cash: Decimal | null
    transfer: Decimal | null
    card: Decimal | null
    sinpe: Decimal | null
    bank_check: Decimal | null
    mixed: Decimal | null
  }

  export type PaysCountAggregateOutputType = {
    id: number
    office_id: number
    ticket_id: number
    client_id: number
    type: number
    cash: number
    transfer: number
    card: number
    sinpe: number
    bank_check: number
    mixed: number
    _all: number
  }


  export type PaysAvgAggregateInputType = {
    id?: true
    office_id?: true
    ticket_id?: true
    client_id?: true
    cash?: true
    transfer?: true
    card?: true
    sinpe?: true
    bank_check?: true
    mixed?: true
  }

  export type PaysSumAggregateInputType = {
    id?: true
    office_id?: true
    ticket_id?: true
    client_id?: true
    cash?: true
    transfer?: true
    card?: true
    sinpe?: true
    bank_check?: true
    mixed?: true
  }

  export type PaysMinAggregateInputType = {
    id?: true
    office_id?: true
    ticket_id?: true
    client_id?: true
    type?: true
    cash?: true
    transfer?: true
    card?: true
    sinpe?: true
    bank_check?: true
    mixed?: true
  }

  export type PaysMaxAggregateInputType = {
    id?: true
    office_id?: true
    ticket_id?: true
    client_id?: true
    type?: true
    cash?: true
    transfer?: true
    card?: true
    sinpe?: true
    bank_check?: true
    mixed?: true
  }

  export type PaysCountAggregateInputType = {
    id?: true
    office_id?: true
    ticket_id?: true
    client_id?: true
    type?: true
    cash?: true
    transfer?: true
    card?: true
    sinpe?: true
    bank_check?: true
    mixed?: true
    _all?: true
  }

  export type PaysAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which pays to aggregate.
     */
    where?: paysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pays to fetch.
     */
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: paysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pays from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pays.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned pays
    **/
    _count?: true | PaysCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PaysAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PaysSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaysMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaysMaxAggregateInputType
  }

  export type GetPaysAggregateType<T extends PaysAggregateArgs> = {
        [P in keyof T & keyof AggregatePays]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePays[P]>
      : GetScalarType<T[P], AggregatePays[P]>
  }




  export type paysGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: paysWhereInput
    orderBy?: paysOrderByWithAggregationInput | paysOrderByWithAggregationInput[]
    by: PaysScalarFieldEnum[] | PaysScalarFieldEnum
    having?: paysScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaysCountAggregateInputType | true
    _avg?: PaysAvgAggregateInputType
    _sum?: PaysSumAggregateInputType
    _min?: PaysMinAggregateInputType
    _max?: PaysMaxAggregateInputType
  }

  export type PaysGroupByOutputType = {
    id: number
    office_id: number | null
    ticket_id: number | null
    client_id: number | null
    type: string | null
    cash: Decimal | null
    transfer: Decimal | null
    card: Decimal | null
    sinpe: Decimal | null
    bank_check: Decimal | null
    mixed: Decimal | null
    _count: PaysCountAggregateOutputType | null
    _avg: PaysAvgAggregateOutputType | null
    _sum: PaysSumAggregateOutputType | null
    _min: PaysMinAggregateOutputType | null
    _max: PaysMaxAggregateOutputType | null
  }

  type GetPaysGroupByPayload<T extends paysGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaysGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaysGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaysGroupByOutputType[P]>
            : GetScalarType<T[P], PaysGroupByOutputType[P]>
        }
      >
    >


  export type paysSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    ticket_id?: boolean
    client_id?: boolean
    type?: boolean
    cash?: boolean
    transfer?: boolean
    card?: boolean
    sinpe?: boolean
    bank_check?: boolean
    mixed?: boolean
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }, ExtArgs["result"]["pays"]>

  export type paysSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    ticket_id?: boolean
    client_id?: boolean
    type?: boolean
    cash?: boolean
    transfer?: boolean
    card?: boolean
    sinpe?: boolean
    bank_check?: boolean
    mixed?: boolean
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }, ExtArgs["result"]["pays"]>

  export type paysSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    ticket_id?: boolean
    client_id?: boolean
    type?: boolean
    cash?: boolean
    transfer?: boolean
    card?: boolean
    sinpe?: boolean
    bank_check?: boolean
    mixed?: boolean
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }, ExtArgs["result"]["pays"]>

  export type paysSelectScalar = {
    id?: boolean
    office_id?: boolean
    ticket_id?: boolean
    client_id?: boolean
    type?: boolean
    cash?: boolean
    transfer?: boolean
    card?: boolean
    sinpe?: boolean
    bank_check?: boolean
    mixed?: boolean
  }

  export type paysOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "office_id" | "ticket_id" | "client_id" | "type" | "cash" | "transfer" | "card" | "sinpe" | "bank_check" | "mixed", ExtArgs["result"]["pays"]>
  export type paysInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }
  export type paysIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }
  export type paysIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | pays$clientsArgs<ExtArgs>
    offices?: boolean | pays$officesArgs<ExtArgs>
    tickets?: boolean | pays$ticketsArgs<ExtArgs>
  }

  export type $paysPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "pays"
    objects: {
      clients: Prisma.$clientsPayload<ExtArgs> | null
      offices: Prisma.$officesPayload<ExtArgs> | null
      tickets: Prisma.$ticketsPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      office_id: number | null
      ticket_id: number | null
      client_id: number | null
      type: string | null
      cash: Prisma.Decimal | null
      transfer: Prisma.Decimal | null
      card: Prisma.Decimal | null
      sinpe: Prisma.Decimal | null
      bank_check: Prisma.Decimal | null
      mixed: Prisma.Decimal | null
    }, ExtArgs["result"]["pays"]>
    composites: {}
  }

  type paysGetPayload<S extends boolean | null | undefined | paysDefaultArgs> = $Result.GetResult<Prisma.$paysPayload, S>

  type paysCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<paysFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaysCountAggregateInputType | true
    }

  export interface paysDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['pays'], meta: { name: 'pays' } }
    /**
     * Find zero or one Pays that matches the filter.
     * @param {paysFindUniqueArgs} args - Arguments to find a Pays
     * @example
     * // Get one Pays
     * const pays = await prisma.pays.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends paysFindUniqueArgs>(args: SelectSubset<T, paysFindUniqueArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Pays that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {paysFindUniqueOrThrowArgs} args - Arguments to find a Pays
     * @example
     * // Get one Pays
     * const pays = await prisma.pays.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends paysFindUniqueOrThrowArgs>(args: SelectSubset<T, paysFindUniqueOrThrowArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pays that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysFindFirstArgs} args - Arguments to find a Pays
     * @example
     * // Get one Pays
     * const pays = await prisma.pays.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends paysFindFirstArgs>(args?: SelectSubset<T, paysFindFirstArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pays that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysFindFirstOrThrowArgs} args - Arguments to find a Pays
     * @example
     * // Get one Pays
     * const pays = await prisma.pays.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends paysFindFirstOrThrowArgs>(args?: SelectSubset<T, paysFindFirstOrThrowArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Pays that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Pays
     * const pays = await prisma.pays.findMany()
     * 
     * // Get first 10 Pays
     * const pays = await prisma.pays.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const paysWithIdOnly = await prisma.pays.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends paysFindManyArgs>(args?: SelectSubset<T, paysFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Pays.
     * @param {paysCreateArgs} args - Arguments to create a Pays.
     * @example
     * // Create one Pays
     * const Pays = await prisma.pays.create({
     *   data: {
     *     // ... data to create a Pays
     *   }
     * })
     * 
     */
    create<T extends paysCreateArgs>(args: SelectSubset<T, paysCreateArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Pays.
     * @param {paysCreateManyArgs} args - Arguments to create many Pays.
     * @example
     * // Create many Pays
     * const pays = await prisma.pays.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends paysCreateManyArgs>(args?: SelectSubset<T, paysCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Pays and returns the data saved in the database.
     * @param {paysCreateManyAndReturnArgs} args - Arguments to create many Pays.
     * @example
     * // Create many Pays
     * const pays = await prisma.pays.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Pays and only return the `id`
     * const paysWithIdOnly = await prisma.pays.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends paysCreateManyAndReturnArgs>(args?: SelectSubset<T, paysCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Pays.
     * @param {paysDeleteArgs} args - Arguments to delete one Pays.
     * @example
     * // Delete one Pays
     * const Pays = await prisma.pays.delete({
     *   where: {
     *     // ... filter to delete one Pays
     *   }
     * })
     * 
     */
    delete<T extends paysDeleteArgs>(args: SelectSubset<T, paysDeleteArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Pays.
     * @param {paysUpdateArgs} args - Arguments to update one Pays.
     * @example
     * // Update one Pays
     * const pays = await prisma.pays.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends paysUpdateArgs>(args: SelectSubset<T, paysUpdateArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Pays.
     * @param {paysDeleteManyArgs} args - Arguments to filter Pays to delete.
     * @example
     * // Delete a few Pays
     * const { count } = await prisma.pays.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends paysDeleteManyArgs>(args?: SelectSubset<T, paysDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Pays.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Pays
     * const pays = await prisma.pays.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends paysUpdateManyArgs>(args: SelectSubset<T, paysUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Pays and returns the data updated in the database.
     * @param {paysUpdateManyAndReturnArgs} args - Arguments to update many Pays.
     * @example
     * // Update many Pays
     * const pays = await prisma.pays.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Pays and only return the `id`
     * const paysWithIdOnly = await prisma.pays.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends paysUpdateManyAndReturnArgs>(args: SelectSubset<T, paysUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Pays.
     * @param {paysUpsertArgs} args - Arguments to update or create a Pays.
     * @example
     * // Update or create a Pays
     * const pays = await prisma.pays.upsert({
     *   create: {
     *     // ... data to create a Pays
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Pays we want to update
     *   }
     * })
     */
    upsert<T extends paysUpsertArgs>(args: SelectSubset<T, paysUpsertArgs<ExtArgs>>): Prisma__paysClient<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Pays.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysCountArgs} args - Arguments to filter Pays to count.
     * @example
     * // Count the number of Pays
     * const count = await prisma.pays.count({
     *   where: {
     *     // ... the filter for the Pays we want to count
     *   }
     * })
    **/
    count<T extends paysCountArgs>(
      args?: Subset<T, paysCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaysCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Pays.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaysAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaysAggregateArgs>(args: Subset<T, PaysAggregateArgs>): Prisma.PrismaPromise<GetPaysAggregateType<T>>

    /**
     * Group by Pays.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {paysGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends paysGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: paysGroupByArgs['orderBy'] }
        : { orderBy?: paysGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, paysGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaysGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the pays model
   */
  readonly fields: paysFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for pays.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__paysClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    clients<T extends pays$clientsArgs<ExtArgs> = {}>(args?: Subset<T, pays$clientsArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    offices<T extends pays$officesArgs<ExtArgs> = {}>(args?: Subset<T, pays$officesArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    tickets<T extends pays$ticketsArgs<ExtArgs> = {}>(args?: Subset<T, pays$ticketsArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the pays model
   */
  interface paysFieldRefs {
    readonly id: FieldRef<"pays", 'Int'>
    readonly office_id: FieldRef<"pays", 'Int'>
    readonly ticket_id: FieldRef<"pays", 'Int'>
    readonly client_id: FieldRef<"pays", 'Int'>
    readonly type: FieldRef<"pays", 'String'>
    readonly cash: FieldRef<"pays", 'Decimal'>
    readonly transfer: FieldRef<"pays", 'Decimal'>
    readonly card: FieldRef<"pays", 'Decimal'>
    readonly sinpe: FieldRef<"pays", 'Decimal'>
    readonly bank_check: FieldRef<"pays", 'Decimal'>
    readonly mixed: FieldRef<"pays", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * pays findUnique
   */
  export type paysFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter, which pays to fetch.
     */
    where: paysWhereUniqueInput
  }

  /**
   * pays findUniqueOrThrow
   */
  export type paysFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter, which pays to fetch.
     */
    where: paysWhereUniqueInput
  }

  /**
   * pays findFirst
   */
  export type paysFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter, which pays to fetch.
     */
    where?: paysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pays to fetch.
     */
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for pays.
     */
    cursor?: paysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pays from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pays.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of pays.
     */
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * pays findFirstOrThrow
   */
  export type paysFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter, which pays to fetch.
     */
    where?: paysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pays to fetch.
     */
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for pays.
     */
    cursor?: paysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pays from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pays.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of pays.
     */
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * pays findMany
   */
  export type paysFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter, which pays to fetch.
     */
    where?: paysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pays to fetch.
     */
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing pays.
     */
    cursor?: paysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pays from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pays.
     */
    skip?: number
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * pays create
   */
  export type paysCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * The data needed to create a pays.
     */
    data?: XOR<paysCreateInput, paysUncheckedCreateInput>
  }

  /**
   * pays createMany
   */
  export type paysCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many pays.
     */
    data: paysCreateManyInput | paysCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * pays createManyAndReturn
   */
  export type paysCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * The data used to create many pays.
     */
    data: paysCreateManyInput | paysCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * pays update
   */
  export type paysUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * The data needed to update a pays.
     */
    data: XOR<paysUpdateInput, paysUncheckedUpdateInput>
    /**
     * Choose, which pays to update.
     */
    where: paysWhereUniqueInput
  }

  /**
   * pays updateMany
   */
  export type paysUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update pays.
     */
    data: XOR<paysUpdateManyMutationInput, paysUncheckedUpdateManyInput>
    /**
     * Filter which pays to update
     */
    where?: paysWhereInput
    /**
     * Limit how many pays to update.
     */
    limit?: number
  }

  /**
   * pays updateManyAndReturn
   */
  export type paysUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * The data used to update pays.
     */
    data: XOR<paysUpdateManyMutationInput, paysUncheckedUpdateManyInput>
    /**
     * Filter which pays to update
     */
    where?: paysWhereInput
    /**
     * Limit how many pays to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * pays upsert
   */
  export type paysUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * The filter to search for the pays to update in case it exists.
     */
    where: paysWhereUniqueInput
    /**
     * In case the pays found by the `where` argument doesn't exist, create a new pays with this data.
     */
    create: XOR<paysCreateInput, paysUncheckedCreateInput>
    /**
     * In case the pays was found with the provided `where` argument, update it with this data.
     */
    update: XOR<paysUpdateInput, paysUncheckedUpdateInput>
  }

  /**
   * pays delete
   */
  export type paysDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    /**
     * Filter which pays to delete.
     */
    where: paysWhereUniqueInput
  }

  /**
   * pays deleteMany
   */
  export type paysDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which pays to delete
     */
    where?: paysWhereInput
    /**
     * Limit how many pays to delete.
     */
    limit?: number
  }

  /**
   * pays.clients
   */
  export type pays$clientsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    where?: clientsWhereInput
  }

  /**
   * pays.offices
   */
  export type pays$officesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    where?: officesWhereInput
  }

  /**
   * pays.tickets
   */
  export type pays$ticketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    where?: ticketsWhereInput
  }

  /**
   * pays without action
   */
  export type paysDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
  }


  /**
   * Model pending_pay_tickets
   */

  export type AggregatePending_pay_tickets = {
    _count: Pending_pay_ticketsCountAggregateOutputType | null
    _avg: Pending_pay_ticketsAvgAggregateOutputType | null
    _sum: Pending_pay_ticketsSumAggregateOutputType | null
    _min: Pending_pay_ticketsMinAggregateOutputType | null
    _max: Pending_pay_ticketsMaxAggregateOutputType | null
  }

  export type Pending_pay_ticketsAvgAggregateOutputType = {
    id_ticket: number | null
    total_to_pay: Decimal | null
    total_payed: Decimal | null
  }

  export type Pending_pay_ticketsSumAggregateOutputType = {
    id_ticket: number | null
    total_to_pay: Decimal | null
    total_payed: Decimal | null
  }

  export type Pending_pay_ticketsMinAggregateOutputType = {
    id_ticket: number | null
    state: string | null
    exp_date: Date | null
    total_to_pay: Decimal | null
    total_payed: Decimal | null
  }

  export type Pending_pay_ticketsMaxAggregateOutputType = {
    id_ticket: number | null
    state: string | null
    exp_date: Date | null
    total_to_pay: Decimal | null
    total_payed: Decimal | null
  }

  export type Pending_pay_ticketsCountAggregateOutputType = {
    id_ticket: number
    state: number
    exp_date: number
    total_to_pay: number
    total_payed: number
    _all: number
  }


  export type Pending_pay_ticketsAvgAggregateInputType = {
    id_ticket?: true
    total_to_pay?: true
    total_payed?: true
  }

  export type Pending_pay_ticketsSumAggregateInputType = {
    id_ticket?: true
    total_to_pay?: true
    total_payed?: true
  }

  export type Pending_pay_ticketsMinAggregateInputType = {
    id_ticket?: true
    state?: true
    exp_date?: true
    total_to_pay?: true
    total_payed?: true
  }

  export type Pending_pay_ticketsMaxAggregateInputType = {
    id_ticket?: true
    state?: true
    exp_date?: true
    total_to_pay?: true
    total_payed?: true
  }

  export type Pending_pay_ticketsCountAggregateInputType = {
    id_ticket?: true
    state?: true
    exp_date?: true
    total_to_pay?: true
    total_payed?: true
    _all?: true
  }

  export type Pending_pay_ticketsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which pending_pay_tickets to aggregate.
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pending_pay_tickets to fetch.
     */
    orderBy?: pending_pay_ticketsOrderByWithRelationInput | pending_pay_ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: pending_pay_ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pending_pay_tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pending_pay_tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned pending_pay_tickets
    **/
    _count?: true | Pending_pay_ticketsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Pending_pay_ticketsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Pending_pay_ticketsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Pending_pay_ticketsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Pending_pay_ticketsMaxAggregateInputType
  }

  export type GetPending_pay_ticketsAggregateType<T extends Pending_pay_ticketsAggregateArgs> = {
        [P in keyof T & keyof AggregatePending_pay_tickets]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePending_pay_tickets[P]>
      : GetScalarType<T[P], AggregatePending_pay_tickets[P]>
  }




  export type pending_pay_ticketsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: pending_pay_ticketsWhereInput
    orderBy?: pending_pay_ticketsOrderByWithAggregationInput | pending_pay_ticketsOrderByWithAggregationInput[]
    by: Pending_pay_ticketsScalarFieldEnum[] | Pending_pay_ticketsScalarFieldEnum
    having?: pending_pay_ticketsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Pending_pay_ticketsCountAggregateInputType | true
    _avg?: Pending_pay_ticketsAvgAggregateInputType
    _sum?: Pending_pay_ticketsSumAggregateInputType
    _min?: Pending_pay_ticketsMinAggregateInputType
    _max?: Pending_pay_ticketsMaxAggregateInputType
  }

  export type Pending_pay_ticketsGroupByOutputType = {
    id_ticket: number
    state: string | null
    exp_date: Date | null
    total_to_pay: Decimal | null
    total_payed: Decimal | null
    _count: Pending_pay_ticketsCountAggregateOutputType | null
    _avg: Pending_pay_ticketsAvgAggregateOutputType | null
    _sum: Pending_pay_ticketsSumAggregateOutputType | null
    _min: Pending_pay_ticketsMinAggregateOutputType | null
    _max: Pending_pay_ticketsMaxAggregateOutputType | null
  }

  type GetPending_pay_ticketsGroupByPayload<T extends pending_pay_ticketsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Pending_pay_ticketsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Pending_pay_ticketsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Pending_pay_ticketsGroupByOutputType[P]>
            : GetScalarType<T[P], Pending_pay_ticketsGroupByOutputType[P]>
        }
      >
    >


  export type pending_pay_ticketsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_ticket?: boolean
    state?: boolean
    exp_date?: boolean
    total_to_pay?: boolean
    total_payed?: boolean
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pending_pay_tickets"]>

  export type pending_pay_ticketsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_ticket?: boolean
    state?: boolean
    exp_date?: boolean
    total_to_pay?: boolean
    total_payed?: boolean
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pending_pay_tickets"]>

  export type pending_pay_ticketsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_ticket?: boolean
    state?: boolean
    exp_date?: boolean
    total_to_pay?: boolean
    total_payed?: boolean
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pending_pay_tickets"]>

  export type pending_pay_ticketsSelectScalar = {
    id_ticket?: boolean
    state?: boolean
    exp_date?: boolean
    total_to_pay?: boolean
    total_payed?: boolean
  }

  export type pending_pay_ticketsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_ticket" | "state" | "exp_date" | "total_to_pay" | "total_payed", ExtArgs["result"]["pending_pay_tickets"]>
  export type pending_pay_ticketsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }
  export type pending_pay_ticketsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }
  export type pending_pay_ticketsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }

  export type $pending_pay_ticketsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "pending_pay_tickets"
    objects: {
      tickets: Prisma.$ticketsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id_ticket: number
      state: string | null
      exp_date: Date | null
      total_to_pay: Prisma.Decimal | null
      total_payed: Prisma.Decimal | null
    }, ExtArgs["result"]["pending_pay_tickets"]>
    composites: {}
  }

  type pending_pay_ticketsGetPayload<S extends boolean | null | undefined | pending_pay_ticketsDefaultArgs> = $Result.GetResult<Prisma.$pending_pay_ticketsPayload, S>

  type pending_pay_ticketsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<pending_pay_ticketsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Pending_pay_ticketsCountAggregateInputType | true
    }

  export interface pending_pay_ticketsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['pending_pay_tickets'], meta: { name: 'pending_pay_tickets' } }
    /**
     * Find zero or one Pending_pay_tickets that matches the filter.
     * @param {pending_pay_ticketsFindUniqueArgs} args - Arguments to find a Pending_pay_tickets
     * @example
     * // Get one Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends pending_pay_ticketsFindUniqueArgs>(args: SelectSubset<T, pending_pay_ticketsFindUniqueArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Pending_pay_tickets that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {pending_pay_ticketsFindUniqueOrThrowArgs} args - Arguments to find a Pending_pay_tickets
     * @example
     * // Get one Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends pending_pay_ticketsFindUniqueOrThrowArgs>(args: SelectSubset<T, pending_pay_ticketsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pending_pay_tickets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsFindFirstArgs} args - Arguments to find a Pending_pay_tickets
     * @example
     * // Get one Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends pending_pay_ticketsFindFirstArgs>(args?: SelectSubset<T, pending_pay_ticketsFindFirstArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pending_pay_tickets that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsFindFirstOrThrowArgs} args - Arguments to find a Pending_pay_tickets
     * @example
     * // Get one Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends pending_pay_ticketsFindFirstOrThrowArgs>(args?: SelectSubset<T, pending_pay_ticketsFindFirstOrThrowArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Pending_pay_tickets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findMany()
     * 
     * // Get first 10 Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.findMany({ take: 10 })
     * 
     * // Only select the `id_ticket`
     * const pending_pay_ticketsWithId_ticketOnly = await prisma.pending_pay_tickets.findMany({ select: { id_ticket: true } })
     * 
     */
    findMany<T extends pending_pay_ticketsFindManyArgs>(args?: SelectSubset<T, pending_pay_ticketsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Pending_pay_tickets.
     * @param {pending_pay_ticketsCreateArgs} args - Arguments to create a Pending_pay_tickets.
     * @example
     * // Create one Pending_pay_tickets
     * const Pending_pay_tickets = await prisma.pending_pay_tickets.create({
     *   data: {
     *     // ... data to create a Pending_pay_tickets
     *   }
     * })
     * 
     */
    create<T extends pending_pay_ticketsCreateArgs>(args: SelectSubset<T, pending_pay_ticketsCreateArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Pending_pay_tickets.
     * @param {pending_pay_ticketsCreateManyArgs} args - Arguments to create many Pending_pay_tickets.
     * @example
     * // Create many Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends pending_pay_ticketsCreateManyArgs>(args?: SelectSubset<T, pending_pay_ticketsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Pending_pay_tickets and returns the data saved in the database.
     * @param {pending_pay_ticketsCreateManyAndReturnArgs} args - Arguments to create many Pending_pay_tickets.
     * @example
     * // Create many Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Pending_pay_tickets and only return the `id_ticket`
     * const pending_pay_ticketsWithId_ticketOnly = await prisma.pending_pay_tickets.createManyAndReturn({
     *   select: { id_ticket: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends pending_pay_ticketsCreateManyAndReturnArgs>(args?: SelectSubset<T, pending_pay_ticketsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Pending_pay_tickets.
     * @param {pending_pay_ticketsDeleteArgs} args - Arguments to delete one Pending_pay_tickets.
     * @example
     * // Delete one Pending_pay_tickets
     * const Pending_pay_tickets = await prisma.pending_pay_tickets.delete({
     *   where: {
     *     // ... filter to delete one Pending_pay_tickets
     *   }
     * })
     * 
     */
    delete<T extends pending_pay_ticketsDeleteArgs>(args: SelectSubset<T, pending_pay_ticketsDeleteArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Pending_pay_tickets.
     * @param {pending_pay_ticketsUpdateArgs} args - Arguments to update one Pending_pay_tickets.
     * @example
     * // Update one Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends pending_pay_ticketsUpdateArgs>(args: SelectSubset<T, pending_pay_ticketsUpdateArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Pending_pay_tickets.
     * @param {pending_pay_ticketsDeleteManyArgs} args - Arguments to filter Pending_pay_tickets to delete.
     * @example
     * // Delete a few Pending_pay_tickets
     * const { count } = await prisma.pending_pay_tickets.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends pending_pay_ticketsDeleteManyArgs>(args?: SelectSubset<T, pending_pay_ticketsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Pending_pay_tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends pending_pay_ticketsUpdateManyArgs>(args: SelectSubset<T, pending_pay_ticketsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Pending_pay_tickets and returns the data updated in the database.
     * @param {pending_pay_ticketsUpdateManyAndReturnArgs} args - Arguments to update many Pending_pay_tickets.
     * @example
     * // Update many Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Pending_pay_tickets and only return the `id_ticket`
     * const pending_pay_ticketsWithId_ticketOnly = await prisma.pending_pay_tickets.updateManyAndReturn({
     *   select: { id_ticket: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends pending_pay_ticketsUpdateManyAndReturnArgs>(args: SelectSubset<T, pending_pay_ticketsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Pending_pay_tickets.
     * @param {pending_pay_ticketsUpsertArgs} args - Arguments to update or create a Pending_pay_tickets.
     * @example
     * // Update or create a Pending_pay_tickets
     * const pending_pay_tickets = await prisma.pending_pay_tickets.upsert({
     *   create: {
     *     // ... data to create a Pending_pay_tickets
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Pending_pay_tickets we want to update
     *   }
     * })
     */
    upsert<T extends pending_pay_ticketsUpsertArgs>(args: SelectSubset<T, pending_pay_ticketsUpsertArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Pending_pay_tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsCountArgs} args - Arguments to filter Pending_pay_tickets to count.
     * @example
     * // Count the number of Pending_pay_tickets
     * const count = await prisma.pending_pay_tickets.count({
     *   where: {
     *     // ... the filter for the Pending_pay_tickets we want to count
     *   }
     * })
    **/
    count<T extends pending_pay_ticketsCountArgs>(
      args?: Subset<T, pending_pay_ticketsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Pending_pay_ticketsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Pending_pay_tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Pending_pay_ticketsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Pending_pay_ticketsAggregateArgs>(args: Subset<T, Pending_pay_ticketsAggregateArgs>): Prisma.PrismaPromise<GetPending_pay_ticketsAggregateType<T>>

    /**
     * Group by Pending_pay_tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {pending_pay_ticketsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends pending_pay_ticketsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: pending_pay_ticketsGroupByArgs['orderBy'] }
        : { orderBy?: pending_pay_ticketsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, pending_pay_ticketsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPending_pay_ticketsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the pending_pay_tickets model
   */
  readonly fields: pending_pay_ticketsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for pending_pay_tickets.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__pending_pay_ticketsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    tickets<T extends ticketsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ticketsDefaultArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the pending_pay_tickets model
   */
  interface pending_pay_ticketsFieldRefs {
    readonly id_ticket: FieldRef<"pending_pay_tickets", 'Int'>
    readonly state: FieldRef<"pending_pay_tickets", 'String'>
    readonly exp_date: FieldRef<"pending_pay_tickets", 'DateTime'>
    readonly total_to_pay: FieldRef<"pending_pay_tickets", 'Decimal'>
    readonly total_payed: FieldRef<"pending_pay_tickets", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * pending_pay_tickets findUnique
   */
  export type pending_pay_ticketsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter, which pending_pay_tickets to fetch.
     */
    where: pending_pay_ticketsWhereUniqueInput
  }

  /**
   * pending_pay_tickets findUniqueOrThrow
   */
  export type pending_pay_ticketsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter, which pending_pay_tickets to fetch.
     */
    where: pending_pay_ticketsWhereUniqueInput
  }

  /**
   * pending_pay_tickets findFirst
   */
  export type pending_pay_ticketsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter, which pending_pay_tickets to fetch.
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pending_pay_tickets to fetch.
     */
    orderBy?: pending_pay_ticketsOrderByWithRelationInput | pending_pay_ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for pending_pay_tickets.
     */
    cursor?: pending_pay_ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pending_pay_tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pending_pay_tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of pending_pay_tickets.
     */
    distinct?: Pending_pay_ticketsScalarFieldEnum | Pending_pay_ticketsScalarFieldEnum[]
  }

  /**
   * pending_pay_tickets findFirstOrThrow
   */
  export type pending_pay_ticketsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter, which pending_pay_tickets to fetch.
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pending_pay_tickets to fetch.
     */
    orderBy?: pending_pay_ticketsOrderByWithRelationInput | pending_pay_ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for pending_pay_tickets.
     */
    cursor?: pending_pay_ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pending_pay_tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pending_pay_tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of pending_pay_tickets.
     */
    distinct?: Pending_pay_ticketsScalarFieldEnum | Pending_pay_ticketsScalarFieldEnum[]
  }

  /**
   * pending_pay_tickets findMany
   */
  export type pending_pay_ticketsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter, which pending_pay_tickets to fetch.
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of pending_pay_tickets to fetch.
     */
    orderBy?: pending_pay_ticketsOrderByWithRelationInput | pending_pay_ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing pending_pay_tickets.
     */
    cursor?: pending_pay_ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` pending_pay_tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` pending_pay_tickets.
     */
    skip?: number
    distinct?: Pending_pay_ticketsScalarFieldEnum | Pending_pay_ticketsScalarFieldEnum[]
  }

  /**
   * pending_pay_tickets create
   */
  export type pending_pay_ticketsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * The data needed to create a pending_pay_tickets.
     */
    data: XOR<pending_pay_ticketsCreateInput, pending_pay_ticketsUncheckedCreateInput>
  }

  /**
   * pending_pay_tickets createMany
   */
  export type pending_pay_ticketsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many pending_pay_tickets.
     */
    data: pending_pay_ticketsCreateManyInput | pending_pay_ticketsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * pending_pay_tickets createManyAndReturn
   */
  export type pending_pay_ticketsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * The data used to create many pending_pay_tickets.
     */
    data: pending_pay_ticketsCreateManyInput | pending_pay_ticketsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * pending_pay_tickets update
   */
  export type pending_pay_ticketsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * The data needed to update a pending_pay_tickets.
     */
    data: XOR<pending_pay_ticketsUpdateInput, pending_pay_ticketsUncheckedUpdateInput>
    /**
     * Choose, which pending_pay_tickets to update.
     */
    where: pending_pay_ticketsWhereUniqueInput
  }

  /**
   * pending_pay_tickets updateMany
   */
  export type pending_pay_ticketsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update pending_pay_tickets.
     */
    data: XOR<pending_pay_ticketsUpdateManyMutationInput, pending_pay_ticketsUncheckedUpdateManyInput>
    /**
     * Filter which pending_pay_tickets to update
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * Limit how many pending_pay_tickets to update.
     */
    limit?: number
  }

  /**
   * pending_pay_tickets updateManyAndReturn
   */
  export type pending_pay_ticketsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * The data used to update pending_pay_tickets.
     */
    data: XOR<pending_pay_ticketsUpdateManyMutationInput, pending_pay_ticketsUncheckedUpdateManyInput>
    /**
     * Filter which pending_pay_tickets to update
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * Limit how many pending_pay_tickets to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * pending_pay_tickets upsert
   */
  export type pending_pay_ticketsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * The filter to search for the pending_pay_tickets to update in case it exists.
     */
    where: pending_pay_ticketsWhereUniqueInput
    /**
     * In case the pending_pay_tickets found by the `where` argument doesn't exist, create a new pending_pay_tickets with this data.
     */
    create: XOR<pending_pay_ticketsCreateInput, pending_pay_ticketsUncheckedCreateInput>
    /**
     * In case the pending_pay_tickets was found with the provided `where` argument, update it with this data.
     */
    update: XOR<pending_pay_ticketsUpdateInput, pending_pay_ticketsUncheckedUpdateInput>
  }

  /**
   * pending_pay_tickets delete
   */
  export type pending_pay_ticketsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    /**
     * Filter which pending_pay_tickets to delete.
     */
    where: pending_pay_ticketsWhereUniqueInput
  }

  /**
   * pending_pay_tickets deleteMany
   */
  export type pending_pay_ticketsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which pending_pay_tickets to delete
     */
    where?: pending_pay_ticketsWhereInput
    /**
     * Limit how many pending_pay_tickets to delete.
     */
    limit?: number
  }

  /**
   * pending_pay_tickets without action
   */
  export type pending_pay_ticketsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
  }


  /**
   * Model products
   */

  export type AggregateProducts = {
    _count: ProductsCountAggregateOutputType | null
    _avg: ProductsAvgAggregateOutputType | null
    _sum: ProductsSumAggregateOutputType | null
    _min: ProductsMinAggregateOutputType | null
    _max: ProductsMaxAggregateOutputType | null
  }

  export type ProductsAvgAggregateOutputType = {
    id: number | null
    price: Decimal | null
    office_id: number | null
  }

  export type ProductsSumAggregateOutputType = {
    id: number | null
    price: Decimal | null
    office_id: number | null
  }

  export type ProductsMinAggregateOutputType = {
    id: number | null
    name: string | null
    price: Decimal | null
    office_id: number | null
  }

  export type ProductsMaxAggregateOutputType = {
    id: number | null
    name: string | null
    price: Decimal | null
    office_id: number | null
  }

  export type ProductsCountAggregateOutputType = {
    id: number
    name: number
    price: number
    office_id: number
    _all: number
  }


  export type ProductsAvgAggregateInputType = {
    id?: true
    price?: true
    office_id?: true
  }

  export type ProductsSumAggregateInputType = {
    id?: true
    price?: true
    office_id?: true
  }

  export type ProductsMinAggregateInputType = {
    id?: true
    name?: true
    price?: true
    office_id?: true
  }

  export type ProductsMaxAggregateInputType = {
    id?: true
    name?: true
    price?: true
    office_id?: true
  }

  export type ProductsCountAggregateInputType = {
    id?: true
    name?: true
    price?: true
    office_id?: true
    _all?: true
  }

  export type ProductsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which products to aggregate.
     */
    where?: productsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productsOrderByWithRelationInput | productsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: productsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned products
    **/
    _count?: true | ProductsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProductsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProductsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductsMaxAggregateInputType
  }

  export type GetProductsAggregateType<T extends ProductsAggregateArgs> = {
        [P in keyof T & keyof AggregateProducts]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProducts[P]>
      : GetScalarType<T[P], AggregateProducts[P]>
  }




  export type productsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: productsWhereInput
    orderBy?: productsOrderByWithAggregationInput | productsOrderByWithAggregationInput[]
    by: ProductsScalarFieldEnum[] | ProductsScalarFieldEnum
    having?: productsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductsCountAggregateInputType | true
    _avg?: ProductsAvgAggregateInputType
    _sum?: ProductsSumAggregateInputType
    _min?: ProductsMinAggregateInputType
    _max?: ProductsMaxAggregateInputType
  }

  export type ProductsGroupByOutputType = {
    id: number
    name: string | null
    price: Decimal | null
    office_id: number | null
    _count: ProductsCountAggregateOutputType | null
    _avg: ProductsAvgAggregateOutputType | null
    _sum: ProductsSumAggregateOutputType | null
    _min: ProductsMinAggregateOutputType | null
    _max: ProductsMaxAggregateOutputType | null
  }

  type GetProductsGroupByPayload<T extends productsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProductsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductsGroupByOutputType[P]>
            : GetScalarType<T[P], ProductsGroupByOutputType[P]>
        }
      >
    >


  export type productsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    price?: boolean
    office_id?: boolean
    offices?: boolean | products$officesArgs<ExtArgs>
    ticket_details?: boolean | products$ticket_detailsArgs<ExtArgs>
    _count?: boolean | ProductsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["products"]>

  export type productsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    price?: boolean
    office_id?: boolean
    offices?: boolean | products$officesArgs<ExtArgs>
  }, ExtArgs["result"]["products"]>

  export type productsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    price?: boolean
    office_id?: boolean
    offices?: boolean | products$officesArgs<ExtArgs>
  }, ExtArgs["result"]["products"]>

  export type productsSelectScalar = {
    id?: boolean
    name?: boolean
    price?: boolean
    office_id?: boolean
  }

  export type productsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "price" | "office_id", ExtArgs["result"]["products"]>
  export type productsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | products$officesArgs<ExtArgs>
    ticket_details?: boolean | products$ticket_detailsArgs<ExtArgs>
    _count?: boolean | ProductsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type productsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | products$officesArgs<ExtArgs>
  }
  export type productsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | products$officesArgs<ExtArgs>
  }

  export type $productsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "products"
    objects: {
      offices: Prisma.$officesPayload<ExtArgs> | null
      ticket_details: Prisma.$ticket_detailsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string | null
      price: Prisma.Decimal | null
      office_id: number | null
    }, ExtArgs["result"]["products"]>
    composites: {}
  }

  type productsGetPayload<S extends boolean | null | undefined | productsDefaultArgs> = $Result.GetResult<Prisma.$productsPayload, S>

  type productsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<productsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProductsCountAggregateInputType | true
    }

  export interface productsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['products'], meta: { name: 'products' } }
    /**
     * Find zero or one Products that matches the filter.
     * @param {productsFindUniqueArgs} args - Arguments to find a Products
     * @example
     * // Get one Products
     * const products = await prisma.products.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends productsFindUniqueArgs>(args: SelectSubset<T, productsFindUniqueArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Products that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {productsFindUniqueOrThrowArgs} args - Arguments to find a Products
     * @example
     * // Get one Products
     * const products = await prisma.products.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends productsFindUniqueOrThrowArgs>(args: SelectSubset<T, productsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Products that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsFindFirstArgs} args - Arguments to find a Products
     * @example
     * // Get one Products
     * const products = await prisma.products.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends productsFindFirstArgs>(args?: SelectSubset<T, productsFindFirstArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Products that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsFindFirstOrThrowArgs} args - Arguments to find a Products
     * @example
     * // Get one Products
     * const products = await prisma.products.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends productsFindFirstOrThrowArgs>(args?: SelectSubset<T, productsFindFirstOrThrowArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Products that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Products
     * const products = await prisma.products.findMany()
     * 
     * // Get first 10 Products
     * const products = await prisma.products.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const productsWithIdOnly = await prisma.products.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends productsFindManyArgs>(args?: SelectSubset<T, productsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Products.
     * @param {productsCreateArgs} args - Arguments to create a Products.
     * @example
     * // Create one Products
     * const Products = await prisma.products.create({
     *   data: {
     *     // ... data to create a Products
     *   }
     * })
     * 
     */
    create<T extends productsCreateArgs>(args: SelectSubset<T, productsCreateArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Products.
     * @param {productsCreateManyArgs} args - Arguments to create many Products.
     * @example
     * // Create many Products
     * const products = await prisma.products.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends productsCreateManyArgs>(args?: SelectSubset<T, productsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Products and returns the data saved in the database.
     * @param {productsCreateManyAndReturnArgs} args - Arguments to create many Products.
     * @example
     * // Create many Products
     * const products = await prisma.products.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Products and only return the `id`
     * const productsWithIdOnly = await prisma.products.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends productsCreateManyAndReturnArgs>(args?: SelectSubset<T, productsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Products.
     * @param {productsDeleteArgs} args - Arguments to delete one Products.
     * @example
     * // Delete one Products
     * const Products = await prisma.products.delete({
     *   where: {
     *     // ... filter to delete one Products
     *   }
     * })
     * 
     */
    delete<T extends productsDeleteArgs>(args: SelectSubset<T, productsDeleteArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Products.
     * @param {productsUpdateArgs} args - Arguments to update one Products.
     * @example
     * // Update one Products
     * const products = await prisma.products.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends productsUpdateArgs>(args: SelectSubset<T, productsUpdateArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Products.
     * @param {productsDeleteManyArgs} args - Arguments to filter Products to delete.
     * @example
     * // Delete a few Products
     * const { count } = await prisma.products.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends productsDeleteManyArgs>(args?: SelectSubset<T, productsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Products
     * const products = await prisma.products.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends productsUpdateManyArgs>(args: SelectSubset<T, productsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products and returns the data updated in the database.
     * @param {productsUpdateManyAndReturnArgs} args - Arguments to update many Products.
     * @example
     * // Update many Products
     * const products = await prisma.products.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Products and only return the `id`
     * const productsWithIdOnly = await prisma.products.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends productsUpdateManyAndReturnArgs>(args: SelectSubset<T, productsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Products.
     * @param {productsUpsertArgs} args - Arguments to update or create a Products.
     * @example
     * // Update or create a Products
     * const products = await prisma.products.upsert({
     *   create: {
     *     // ... data to create a Products
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Products we want to update
     *   }
     * })
     */
    upsert<T extends productsUpsertArgs>(args: SelectSubset<T, productsUpsertArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsCountArgs} args - Arguments to filter Products to count.
     * @example
     * // Count the number of Products
     * const count = await prisma.products.count({
     *   where: {
     *     // ... the filter for the Products we want to count
     *   }
     * })
    **/
    count<T extends productsCountArgs>(
      args?: Subset<T, productsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductsAggregateArgs>(args: Subset<T, ProductsAggregateArgs>): Prisma.PrismaPromise<GetProductsAggregateType<T>>

    /**
     * Group by Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends productsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: productsGroupByArgs['orderBy'] }
        : { orderBy?: productsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, productsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the products model
   */
  readonly fields: productsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for products.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__productsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    offices<T extends products$officesArgs<ExtArgs> = {}>(args?: Subset<T, products$officesArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    ticket_details<T extends products$ticket_detailsArgs<ExtArgs> = {}>(args?: Subset<T, products$ticket_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the products model
   */
  interface productsFieldRefs {
    readonly id: FieldRef<"products", 'Int'>
    readonly name: FieldRef<"products", 'String'>
    readonly price: FieldRef<"products", 'Decimal'>
    readonly office_id: FieldRef<"products", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * products findUnique
   */
  export type productsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where: productsWhereUniqueInput
  }

  /**
   * products findUniqueOrThrow
   */
  export type productsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where: productsWhereUniqueInput
  }

  /**
   * products findFirst
   */
  export type productsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where?: productsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productsOrderByWithRelationInput | productsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for products.
     */
    cursor?: productsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of products.
     */
    distinct?: ProductsScalarFieldEnum | ProductsScalarFieldEnum[]
  }

  /**
   * products findFirstOrThrow
   */
  export type productsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where?: productsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productsOrderByWithRelationInput | productsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for products.
     */
    cursor?: productsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of products.
     */
    distinct?: ProductsScalarFieldEnum | ProductsScalarFieldEnum[]
  }

  /**
   * products findMany
   */
  export type productsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter, which products to fetch.
     */
    where?: productsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of products to fetch.
     */
    orderBy?: productsOrderByWithRelationInput | productsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing products.
     */
    cursor?: productsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` products.
     */
    skip?: number
    distinct?: ProductsScalarFieldEnum | ProductsScalarFieldEnum[]
  }

  /**
   * products create
   */
  export type productsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * The data needed to create a products.
     */
    data?: XOR<productsCreateInput, productsUncheckedCreateInput>
  }

  /**
   * products createMany
   */
  export type productsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many products.
     */
    data: productsCreateManyInput | productsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * products createManyAndReturn
   */
  export type productsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * The data used to create many products.
     */
    data: productsCreateManyInput | productsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * products update
   */
  export type productsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * The data needed to update a products.
     */
    data: XOR<productsUpdateInput, productsUncheckedUpdateInput>
    /**
     * Choose, which products to update.
     */
    where: productsWhereUniqueInput
  }

  /**
   * products updateMany
   */
  export type productsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update products.
     */
    data: XOR<productsUpdateManyMutationInput, productsUncheckedUpdateManyInput>
    /**
     * Filter which products to update
     */
    where?: productsWhereInput
    /**
     * Limit how many products to update.
     */
    limit?: number
  }

  /**
   * products updateManyAndReturn
   */
  export type productsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * The data used to update products.
     */
    data: XOR<productsUpdateManyMutationInput, productsUncheckedUpdateManyInput>
    /**
     * Filter which products to update
     */
    where?: productsWhereInput
    /**
     * Limit how many products to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * products upsert
   */
  export type productsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * The filter to search for the products to update in case it exists.
     */
    where: productsWhereUniqueInput
    /**
     * In case the products found by the `where` argument doesn't exist, create a new products with this data.
     */
    create: XOR<productsCreateInput, productsUncheckedCreateInput>
    /**
     * In case the products was found with the provided `where` argument, update it with this data.
     */
    update: XOR<productsUpdateInput, productsUncheckedUpdateInput>
  }

  /**
   * products delete
   */
  export type productsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
    /**
     * Filter which products to delete.
     */
    where: productsWhereUniqueInput
  }

  /**
   * products deleteMany
   */
  export type productsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which products to delete
     */
    where?: productsWhereInput
    /**
     * Limit how many products to delete.
     */
    limit?: number
  }

  /**
   * products.offices
   */
  export type products$officesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    where?: officesWhereInput
  }

  /**
   * products.ticket_details
   */
  export type products$ticket_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    where?: ticket_detailsWhereInput
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    cursor?: ticket_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Ticket_detailsScalarFieldEnum | Ticket_detailsScalarFieldEnum[]
  }

  /**
   * products without action
   */
  export type productsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the products
     */
    select?: productsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the products
     */
    omit?: productsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productsInclude<ExtArgs> | null
  }


  /**
   * Model ticket_details
   */

  export type AggregateTicket_details = {
    _count: Ticket_detailsCountAggregateOutputType | null
    _avg: Ticket_detailsAvgAggregateOutputType | null
    _sum: Ticket_detailsSumAggregateOutputType | null
    _min: Ticket_detailsMinAggregateOutputType | null
    _max: Ticket_detailsMaxAggregateOutputType | null
  }

  export type Ticket_detailsAvgAggregateOutputType = {
    ticket_id: number | null
    product_id: number | null
    quantity: number | null
    discount: Decimal | null
  }

  export type Ticket_detailsSumAggregateOutputType = {
    ticket_id: number | null
    product_id: number | null
    quantity: number | null
    discount: Decimal | null
  }

  export type Ticket_detailsMinAggregateOutputType = {
    ticket_id: number | null
    product_id: number | null
    quantity: number | null
    discount: Decimal | null
  }

  export type Ticket_detailsMaxAggregateOutputType = {
    ticket_id: number | null
    product_id: number | null
    quantity: number | null
    discount: Decimal | null
  }

  export type Ticket_detailsCountAggregateOutputType = {
    ticket_id: number
    product_id: number
    quantity: number
    discount: number
    _all: number
  }


  export type Ticket_detailsAvgAggregateInputType = {
    ticket_id?: true
    product_id?: true
    quantity?: true
    discount?: true
  }

  export type Ticket_detailsSumAggregateInputType = {
    ticket_id?: true
    product_id?: true
    quantity?: true
    discount?: true
  }

  export type Ticket_detailsMinAggregateInputType = {
    ticket_id?: true
    product_id?: true
    quantity?: true
    discount?: true
  }

  export type Ticket_detailsMaxAggregateInputType = {
    ticket_id?: true
    product_id?: true
    quantity?: true
    discount?: true
  }

  export type Ticket_detailsCountAggregateInputType = {
    ticket_id?: true
    product_id?: true
    quantity?: true
    discount?: true
    _all?: true
  }

  export type Ticket_detailsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ticket_details to aggregate.
     */
    where?: ticket_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ticket_details to fetch.
     */
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ticket_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ticket_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ticket_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ticket_details
    **/
    _count?: true | Ticket_detailsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Ticket_detailsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Ticket_detailsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Ticket_detailsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Ticket_detailsMaxAggregateInputType
  }

  export type GetTicket_detailsAggregateType<T extends Ticket_detailsAggregateArgs> = {
        [P in keyof T & keyof AggregateTicket_details]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTicket_details[P]>
      : GetScalarType<T[P], AggregateTicket_details[P]>
  }




  export type ticket_detailsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticket_detailsWhereInput
    orderBy?: ticket_detailsOrderByWithAggregationInput | ticket_detailsOrderByWithAggregationInput[]
    by: Ticket_detailsScalarFieldEnum[] | Ticket_detailsScalarFieldEnum
    having?: ticket_detailsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Ticket_detailsCountAggregateInputType | true
    _avg?: Ticket_detailsAvgAggregateInputType
    _sum?: Ticket_detailsSumAggregateInputType
    _min?: Ticket_detailsMinAggregateInputType
    _max?: Ticket_detailsMaxAggregateInputType
  }

  export type Ticket_detailsGroupByOutputType = {
    ticket_id: number
    product_id: number
    quantity: number | null
    discount: Decimal | null
    _count: Ticket_detailsCountAggregateOutputType | null
    _avg: Ticket_detailsAvgAggregateOutputType | null
    _sum: Ticket_detailsSumAggregateOutputType | null
    _min: Ticket_detailsMinAggregateOutputType | null
    _max: Ticket_detailsMaxAggregateOutputType | null
  }

  type GetTicket_detailsGroupByPayload<T extends ticket_detailsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Ticket_detailsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Ticket_detailsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Ticket_detailsGroupByOutputType[P]>
            : GetScalarType<T[P], Ticket_detailsGroupByOutputType[P]>
        }
      >
    >


  export type ticket_detailsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    ticket_id?: boolean
    product_id?: boolean
    quantity?: boolean
    discount?: boolean
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ticket_details"]>

  export type ticket_detailsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    ticket_id?: boolean
    product_id?: boolean
    quantity?: boolean
    discount?: boolean
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ticket_details"]>

  export type ticket_detailsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    ticket_id?: boolean
    product_id?: boolean
    quantity?: boolean
    discount?: boolean
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ticket_details"]>

  export type ticket_detailsSelectScalar = {
    ticket_id?: boolean
    product_id?: boolean
    quantity?: boolean
    discount?: boolean
  }

  export type ticket_detailsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"ticket_id" | "product_id" | "quantity" | "discount", ExtArgs["result"]["ticket_details"]>
  export type ticket_detailsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }
  export type ticket_detailsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }
  export type ticket_detailsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    products?: boolean | productsDefaultArgs<ExtArgs>
    tickets?: boolean | ticketsDefaultArgs<ExtArgs>
  }

  export type $ticket_detailsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ticket_details"
    objects: {
      products: Prisma.$productsPayload<ExtArgs>
      tickets: Prisma.$ticketsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      ticket_id: number
      product_id: number
      quantity: number | null
      discount: Prisma.Decimal | null
    }, ExtArgs["result"]["ticket_details"]>
    composites: {}
  }

  type ticket_detailsGetPayload<S extends boolean | null | undefined | ticket_detailsDefaultArgs> = $Result.GetResult<Prisma.$ticket_detailsPayload, S>

  type ticket_detailsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ticket_detailsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Ticket_detailsCountAggregateInputType | true
    }

  export interface ticket_detailsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ticket_details'], meta: { name: 'ticket_details' } }
    /**
     * Find zero or one Ticket_details that matches the filter.
     * @param {ticket_detailsFindUniqueArgs} args - Arguments to find a Ticket_details
     * @example
     * // Get one Ticket_details
     * const ticket_details = await prisma.ticket_details.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ticket_detailsFindUniqueArgs>(args: SelectSubset<T, ticket_detailsFindUniqueArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Ticket_details that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ticket_detailsFindUniqueOrThrowArgs} args - Arguments to find a Ticket_details
     * @example
     * // Get one Ticket_details
     * const ticket_details = await prisma.ticket_details.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ticket_detailsFindUniqueOrThrowArgs>(args: SelectSubset<T, ticket_detailsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ticket_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsFindFirstArgs} args - Arguments to find a Ticket_details
     * @example
     * // Get one Ticket_details
     * const ticket_details = await prisma.ticket_details.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ticket_detailsFindFirstArgs>(args?: SelectSubset<T, ticket_detailsFindFirstArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ticket_details that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsFindFirstOrThrowArgs} args - Arguments to find a Ticket_details
     * @example
     * // Get one Ticket_details
     * const ticket_details = await prisma.ticket_details.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ticket_detailsFindFirstOrThrowArgs>(args?: SelectSubset<T, ticket_detailsFindFirstOrThrowArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Ticket_details that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Ticket_details
     * const ticket_details = await prisma.ticket_details.findMany()
     * 
     * // Get first 10 Ticket_details
     * const ticket_details = await prisma.ticket_details.findMany({ take: 10 })
     * 
     * // Only select the `ticket_id`
     * const ticket_detailsWithTicket_idOnly = await prisma.ticket_details.findMany({ select: { ticket_id: true } })
     * 
     */
    findMany<T extends ticket_detailsFindManyArgs>(args?: SelectSubset<T, ticket_detailsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Ticket_details.
     * @param {ticket_detailsCreateArgs} args - Arguments to create a Ticket_details.
     * @example
     * // Create one Ticket_details
     * const Ticket_details = await prisma.ticket_details.create({
     *   data: {
     *     // ... data to create a Ticket_details
     *   }
     * })
     * 
     */
    create<T extends ticket_detailsCreateArgs>(args: SelectSubset<T, ticket_detailsCreateArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Ticket_details.
     * @param {ticket_detailsCreateManyArgs} args - Arguments to create many Ticket_details.
     * @example
     * // Create many Ticket_details
     * const ticket_details = await prisma.ticket_details.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ticket_detailsCreateManyArgs>(args?: SelectSubset<T, ticket_detailsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Ticket_details and returns the data saved in the database.
     * @param {ticket_detailsCreateManyAndReturnArgs} args - Arguments to create many Ticket_details.
     * @example
     * // Create many Ticket_details
     * const ticket_details = await prisma.ticket_details.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Ticket_details and only return the `ticket_id`
     * const ticket_detailsWithTicket_idOnly = await prisma.ticket_details.createManyAndReturn({
     *   select: { ticket_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ticket_detailsCreateManyAndReturnArgs>(args?: SelectSubset<T, ticket_detailsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Ticket_details.
     * @param {ticket_detailsDeleteArgs} args - Arguments to delete one Ticket_details.
     * @example
     * // Delete one Ticket_details
     * const Ticket_details = await prisma.ticket_details.delete({
     *   where: {
     *     // ... filter to delete one Ticket_details
     *   }
     * })
     * 
     */
    delete<T extends ticket_detailsDeleteArgs>(args: SelectSubset<T, ticket_detailsDeleteArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Ticket_details.
     * @param {ticket_detailsUpdateArgs} args - Arguments to update one Ticket_details.
     * @example
     * // Update one Ticket_details
     * const ticket_details = await prisma.ticket_details.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ticket_detailsUpdateArgs>(args: SelectSubset<T, ticket_detailsUpdateArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Ticket_details.
     * @param {ticket_detailsDeleteManyArgs} args - Arguments to filter Ticket_details to delete.
     * @example
     * // Delete a few Ticket_details
     * const { count } = await prisma.ticket_details.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ticket_detailsDeleteManyArgs>(args?: SelectSubset<T, ticket_detailsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ticket_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Ticket_details
     * const ticket_details = await prisma.ticket_details.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ticket_detailsUpdateManyArgs>(args: SelectSubset<T, ticket_detailsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ticket_details and returns the data updated in the database.
     * @param {ticket_detailsUpdateManyAndReturnArgs} args - Arguments to update many Ticket_details.
     * @example
     * // Update many Ticket_details
     * const ticket_details = await prisma.ticket_details.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Ticket_details and only return the `ticket_id`
     * const ticket_detailsWithTicket_idOnly = await prisma.ticket_details.updateManyAndReturn({
     *   select: { ticket_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ticket_detailsUpdateManyAndReturnArgs>(args: SelectSubset<T, ticket_detailsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Ticket_details.
     * @param {ticket_detailsUpsertArgs} args - Arguments to update or create a Ticket_details.
     * @example
     * // Update or create a Ticket_details
     * const ticket_details = await prisma.ticket_details.upsert({
     *   create: {
     *     // ... data to create a Ticket_details
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Ticket_details we want to update
     *   }
     * })
     */
    upsert<T extends ticket_detailsUpsertArgs>(args: SelectSubset<T, ticket_detailsUpsertArgs<ExtArgs>>): Prisma__ticket_detailsClient<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Ticket_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsCountArgs} args - Arguments to filter Ticket_details to count.
     * @example
     * // Count the number of Ticket_details
     * const count = await prisma.ticket_details.count({
     *   where: {
     *     // ... the filter for the Ticket_details we want to count
     *   }
     * })
    **/
    count<T extends ticket_detailsCountArgs>(
      args?: Subset<T, ticket_detailsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Ticket_detailsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Ticket_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Ticket_detailsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Ticket_detailsAggregateArgs>(args: Subset<T, Ticket_detailsAggregateArgs>): Prisma.PrismaPromise<GetTicket_detailsAggregateType<T>>

    /**
     * Group by Ticket_details.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticket_detailsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ticket_detailsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ticket_detailsGroupByArgs['orderBy'] }
        : { orderBy?: ticket_detailsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ticket_detailsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTicket_detailsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ticket_details model
   */
  readonly fields: ticket_detailsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ticket_details.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ticket_detailsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    products<T extends productsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, productsDefaultArgs<ExtArgs>>): Prisma__productsClient<$Result.GetResult<Prisma.$productsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    tickets<T extends ticketsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ticketsDefaultArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ticket_details model
   */
  interface ticket_detailsFieldRefs {
    readonly ticket_id: FieldRef<"ticket_details", 'Int'>
    readonly product_id: FieldRef<"ticket_details", 'Int'>
    readonly quantity: FieldRef<"ticket_details", 'Int'>
    readonly discount: FieldRef<"ticket_details", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * ticket_details findUnique
   */
  export type ticket_detailsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter, which ticket_details to fetch.
     */
    where: ticket_detailsWhereUniqueInput
  }

  /**
   * ticket_details findUniqueOrThrow
   */
  export type ticket_detailsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter, which ticket_details to fetch.
     */
    where: ticket_detailsWhereUniqueInput
  }

  /**
   * ticket_details findFirst
   */
  export type ticket_detailsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter, which ticket_details to fetch.
     */
    where?: ticket_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ticket_details to fetch.
     */
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ticket_details.
     */
    cursor?: ticket_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ticket_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ticket_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ticket_details.
     */
    distinct?: Ticket_detailsScalarFieldEnum | Ticket_detailsScalarFieldEnum[]
  }

  /**
   * ticket_details findFirstOrThrow
   */
  export type ticket_detailsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter, which ticket_details to fetch.
     */
    where?: ticket_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ticket_details to fetch.
     */
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ticket_details.
     */
    cursor?: ticket_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ticket_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ticket_details.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ticket_details.
     */
    distinct?: Ticket_detailsScalarFieldEnum | Ticket_detailsScalarFieldEnum[]
  }

  /**
   * ticket_details findMany
   */
  export type ticket_detailsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter, which ticket_details to fetch.
     */
    where?: ticket_detailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ticket_details to fetch.
     */
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ticket_details.
     */
    cursor?: ticket_detailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ticket_details from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ticket_details.
     */
    skip?: number
    distinct?: Ticket_detailsScalarFieldEnum | Ticket_detailsScalarFieldEnum[]
  }

  /**
   * ticket_details create
   */
  export type ticket_detailsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * The data needed to create a ticket_details.
     */
    data: XOR<ticket_detailsCreateInput, ticket_detailsUncheckedCreateInput>
  }

  /**
   * ticket_details createMany
   */
  export type ticket_detailsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ticket_details.
     */
    data: ticket_detailsCreateManyInput | ticket_detailsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ticket_details createManyAndReturn
   */
  export type ticket_detailsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * The data used to create many ticket_details.
     */
    data: ticket_detailsCreateManyInput | ticket_detailsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ticket_details update
   */
  export type ticket_detailsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * The data needed to update a ticket_details.
     */
    data: XOR<ticket_detailsUpdateInput, ticket_detailsUncheckedUpdateInput>
    /**
     * Choose, which ticket_details to update.
     */
    where: ticket_detailsWhereUniqueInput
  }

  /**
   * ticket_details updateMany
   */
  export type ticket_detailsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ticket_details.
     */
    data: XOR<ticket_detailsUpdateManyMutationInput, ticket_detailsUncheckedUpdateManyInput>
    /**
     * Filter which ticket_details to update
     */
    where?: ticket_detailsWhereInput
    /**
     * Limit how many ticket_details to update.
     */
    limit?: number
  }

  /**
   * ticket_details updateManyAndReturn
   */
  export type ticket_detailsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * The data used to update ticket_details.
     */
    data: XOR<ticket_detailsUpdateManyMutationInput, ticket_detailsUncheckedUpdateManyInput>
    /**
     * Filter which ticket_details to update
     */
    where?: ticket_detailsWhereInput
    /**
     * Limit how many ticket_details to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ticket_details upsert
   */
  export type ticket_detailsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * The filter to search for the ticket_details to update in case it exists.
     */
    where: ticket_detailsWhereUniqueInput
    /**
     * In case the ticket_details found by the `where` argument doesn't exist, create a new ticket_details with this data.
     */
    create: XOR<ticket_detailsCreateInput, ticket_detailsUncheckedCreateInput>
    /**
     * In case the ticket_details was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ticket_detailsUpdateInput, ticket_detailsUncheckedUpdateInput>
  }

  /**
   * ticket_details delete
   */
  export type ticket_detailsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    /**
     * Filter which ticket_details to delete.
     */
    where: ticket_detailsWhereUniqueInput
  }

  /**
   * ticket_details deleteMany
   */
  export type ticket_detailsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ticket_details to delete
     */
    where?: ticket_detailsWhereInput
    /**
     * Limit how many ticket_details to delete.
     */
    limit?: number
  }

  /**
   * ticket_details without action
   */
  export type ticket_detailsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
  }


  /**
   * Model tickets
   */

  export type AggregateTickets = {
    _count: TicketsCountAggregateOutputType | null
    _avg: TicketsAvgAggregateOutputType | null
    _sum: TicketsSumAggregateOutputType | null
    _min: TicketsMinAggregateOutputType | null
    _max: TicketsMaxAggregateOutputType | null
  }

  export type TicketsAvgAggregateOutputType = {
    id: number | null
    office_id: number | null
    user_id: number | null
    client_id: number | null
    total: Decimal | null
  }

  export type TicketsSumAggregateOutputType = {
    id: number | null
    office_id: number | null
    user_id: number | null
    client_id: number | null
    total: Decimal | null
  }

  export type TicketsMinAggregateOutputType = {
    id: number | null
    office_id: number | null
    user_id: number | null
    client_id: number | null
    type: string | null
    vehicle_plate: string | null
    date: Date | null
    needs_facture: boolean | null
    total: Decimal | null
  }

  export type TicketsMaxAggregateOutputType = {
    id: number | null
    office_id: number | null
    user_id: number | null
    client_id: number | null
    type: string | null
    vehicle_plate: string | null
    date: Date | null
    needs_facture: boolean | null
    total: Decimal | null
  }

  export type TicketsCountAggregateOutputType = {
    id: number
    office_id: number
    user_id: number
    client_id: number
    type: number
    vehicle_plate: number
    date: number
    needs_facture: number
    total: number
    _all: number
  }


  export type TicketsAvgAggregateInputType = {
    id?: true
    office_id?: true
    user_id?: true
    client_id?: true
    total?: true
  }

  export type TicketsSumAggregateInputType = {
    id?: true
    office_id?: true
    user_id?: true
    client_id?: true
    total?: true
  }

  export type TicketsMinAggregateInputType = {
    id?: true
    office_id?: true
    user_id?: true
    client_id?: true
    type?: true
    vehicle_plate?: true
    date?: true
    needs_facture?: true
    total?: true
  }

  export type TicketsMaxAggregateInputType = {
    id?: true
    office_id?: true
    user_id?: true
    client_id?: true
    type?: true
    vehicle_plate?: true
    date?: true
    needs_facture?: true
    total?: true
  }

  export type TicketsCountAggregateInputType = {
    id?: true
    office_id?: true
    user_id?: true
    client_id?: true
    type?: true
    vehicle_plate?: true
    date?: true
    needs_facture?: true
    total?: true
    _all?: true
  }

  export type TicketsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which tickets to aggregate.
     */
    where?: ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tickets to fetch.
     */
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned tickets
    **/
    _count?: true | TicketsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TicketsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TicketsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TicketsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TicketsMaxAggregateInputType
  }

  export type GetTicketsAggregateType<T extends TicketsAggregateArgs> = {
        [P in keyof T & keyof AggregateTickets]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTickets[P]>
      : GetScalarType<T[P], AggregateTickets[P]>
  }




  export type ticketsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ticketsWhereInput
    orderBy?: ticketsOrderByWithAggregationInput | ticketsOrderByWithAggregationInput[]
    by: TicketsScalarFieldEnum[] | TicketsScalarFieldEnum
    having?: ticketsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TicketsCountAggregateInputType | true
    _avg?: TicketsAvgAggregateInputType
    _sum?: TicketsSumAggregateInputType
    _min?: TicketsMinAggregateInputType
    _max?: TicketsMaxAggregateInputType
  }

  export type TicketsGroupByOutputType = {
    id: number
    office_id: number | null
    user_id: number | null
    client_id: number | null
    type: string | null
    vehicle_plate: string | null
    date: Date | null
    needs_facture: boolean | null
    total: Decimal | null
    _count: TicketsCountAggregateOutputType | null
    _avg: TicketsAvgAggregateOutputType | null
    _sum: TicketsSumAggregateOutputType | null
    _min: TicketsMinAggregateOutputType | null
    _max: TicketsMaxAggregateOutputType | null
  }

  type GetTicketsGroupByPayload<T extends ticketsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TicketsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TicketsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TicketsGroupByOutputType[P]>
            : GetScalarType<T[P], TicketsGroupByOutputType[P]>
        }
      >
    >


  export type ticketsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    user_id?: boolean
    client_id?: boolean
    type?: boolean
    vehicle_plate?: boolean
    date?: boolean
    needs_facture?: boolean
    total?: boolean
    pays?: boolean | tickets$paysArgs<ExtArgs>
    pending_pay_tickets?: boolean | tickets$pending_pay_ticketsArgs<ExtArgs>
    ticket_details?: boolean | tickets$ticket_detailsArgs<ExtArgs>
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
    _count?: boolean | TicketsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["tickets"]>

  export type ticketsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    user_id?: boolean
    client_id?: boolean
    type?: boolean
    vehicle_plate?: boolean
    date?: boolean
    needs_facture?: boolean
    total?: boolean
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
  }, ExtArgs["result"]["tickets"]>

  export type ticketsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    office_id?: boolean
    user_id?: boolean
    client_id?: boolean
    type?: boolean
    vehicle_plate?: boolean
    date?: boolean
    needs_facture?: boolean
    total?: boolean
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
  }, ExtArgs["result"]["tickets"]>

  export type ticketsSelectScalar = {
    id?: boolean
    office_id?: boolean
    user_id?: boolean
    client_id?: boolean
    type?: boolean
    vehicle_plate?: boolean
    date?: boolean
    needs_facture?: boolean
    total?: boolean
  }

  export type ticketsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "office_id" | "user_id" | "client_id" | "type" | "vehicle_plate" | "date" | "needs_facture" | "total", ExtArgs["result"]["tickets"]>
  export type ticketsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    pays?: boolean | tickets$paysArgs<ExtArgs>
    pending_pay_tickets?: boolean | tickets$pending_pay_ticketsArgs<ExtArgs>
    ticket_details?: boolean | tickets$ticket_detailsArgs<ExtArgs>
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
    _count?: boolean | TicketsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type ticketsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
  }
  export type ticketsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    clients?: boolean | tickets$clientsArgs<ExtArgs>
    offices?: boolean | tickets$officesArgs<ExtArgs>
    users?: boolean | tickets$usersArgs<ExtArgs>
  }

  export type $ticketsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "tickets"
    objects: {
      pays: Prisma.$paysPayload<ExtArgs>[]
      pending_pay_tickets: Prisma.$pending_pay_ticketsPayload<ExtArgs> | null
      ticket_details: Prisma.$ticket_detailsPayload<ExtArgs>[]
      clients: Prisma.$clientsPayload<ExtArgs> | null
      offices: Prisma.$officesPayload<ExtArgs> | null
      users: Prisma.$usersPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      office_id: number | null
      user_id: number | null
      client_id: number | null
      type: string | null
      vehicle_plate: string | null
      date: Date | null
      needs_facture: boolean | null
      total: Prisma.Decimal | null
    }, ExtArgs["result"]["tickets"]>
    composites: {}
  }

  type ticketsGetPayload<S extends boolean | null | undefined | ticketsDefaultArgs> = $Result.GetResult<Prisma.$ticketsPayload, S>

  type ticketsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ticketsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TicketsCountAggregateInputType | true
    }

  export interface ticketsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['tickets'], meta: { name: 'tickets' } }
    /**
     * Find zero or one Tickets that matches the filter.
     * @param {ticketsFindUniqueArgs} args - Arguments to find a Tickets
     * @example
     * // Get one Tickets
     * const tickets = await prisma.tickets.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ticketsFindUniqueArgs>(args: SelectSubset<T, ticketsFindUniqueArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Tickets that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ticketsFindUniqueOrThrowArgs} args - Arguments to find a Tickets
     * @example
     * // Get one Tickets
     * const tickets = await prisma.tickets.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ticketsFindUniqueOrThrowArgs>(args: SelectSubset<T, ticketsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tickets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsFindFirstArgs} args - Arguments to find a Tickets
     * @example
     * // Get one Tickets
     * const tickets = await prisma.tickets.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ticketsFindFirstArgs>(args?: SelectSubset<T, ticketsFindFirstArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tickets that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsFindFirstOrThrowArgs} args - Arguments to find a Tickets
     * @example
     * // Get one Tickets
     * const tickets = await prisma.tickets.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ticketsFindFirstOrThrowArgs>(args?: SelectSubset<T, ticketsFindFirstOrThrowArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Tickets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Tickets
     * const tickets = await prisma.tickets.findMany()
     * 
     * // Get first 10 Tickets
     * const tickets = await prisma.tickets.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ticketsWithIdOnly = await prisma.tickets.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ticketsFindManyArgs>(args?: SelectSubset<T, ticketsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Tickets.
     * @param {ticketsCreateArgs} args - Arguments to create a Tickets.
     * @example
     * // Create one Tickets
     * const Tickets = await prisma.tickets.create({
     *   data: {
     *     // ... data to create a Tickets
     *   }
     * })
     * 
     */
    create<T extends ticketsCreateArgs>(args: SelectSubset<T, ticketsCreateArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Tickets.
     * @param {ticketsCreateManyArgs} args - Arguments to create many Tickets.
     * @example
     * // Create many Tickets
     * const tickets = await prisma.tickets.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ticketsCreateManyArgs>(args?: SelectSubset<T, ticketsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Tickets and returns the data saved in the database.
     * @param {ticketsCreateManyAndReturnArgs} args - Arguments to create many Tickets.
     * @example
     * // Create many Tickets
     * const tickets = await prisma.tickets.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Tickets and only return the `id`
     * const ticketsWithIdOnly = await prisma.tickets.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ticketsCreateManyAndReturnArgs>(args?: SelectSubset<T, ticketsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Tickets.
     * @param {ticketsDeleteArgs} args - Arguments to delete one Tickets.
     * @example
     * // Delete one Tickets
     * const Tickets = await prisma.tickets.delete({
     *   where: {
     *     // ... filter to delete one Tickets
     *   }
     * })
     * 
     */
    delete<T extends ticketsDeleteArgs>(args: SelectSubset<T, ticketsDeleteArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Tickets.
     * @param {ticketsUpdateArgs} args - Arguments to update one Tickets.
     * @example
     * // Update one Tickets
     * const tickets = await prisma.tickets.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ticketsUpdateArgs>(args: SelectSubset<T, ticketsUpdateArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Tickets.
     * @param {ticketsDeleteManyArgs} args - Arguments to filter Tickets to delete.
     * @example
     * // Delete a few Tickets
     * const { count } = await prisma.tickets.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ticketsDeleteManyArgs>(args?: SelectSubset<T, ticketsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Tickets
     * const tickets = await prisma.tickets.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ticketsUpdateManyArgs>(args: SelectSubset<T, ticketsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Tickets and returns the data updated in the database.
     * @param {ticketsUpdateManyAndReturnArgs} args - Arguments to update many Tickets.
     * @example
     * // Update many Tickets
     * const tickets = await prisma.tickets.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Tickets and only return the `id`
     * const ticketsWithIdOnly = await prisma.tickets.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ticketsUpdateManyAndReturnArgs>(args: SelectSubset<T, ticketsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Tickets.
     * @param {ticketsUpsertArgs} args - Arguments to update or create a Tickets.
     * @example
     * // Update or create a Tickets
     * const tickets = await prisma.tickets.upsert({
     *   create: {
     *     // ... data to create a Tickets
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Tickets we want to update
     *   }
     * })
     */
    upsert<T extends ticketsUpsertArgs>(args: SelectSubset<T, ticketsUpsertArgs<ExtArgs>>): Prisma__ticketsClient<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsCountArgs} args - Arguments to filter Tickets to count.
     * @example
     * // Count the number of Tickets
     * const count = await prisma.tickets.count({
     *   where: {
     *     // ... the filter for the Tickets we want to count
     *   }
     * })
    **/
    count<T extends ticketsCountArgs>(
      args?: Subset<T, ticketsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TicketsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TicketsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TicketsAggregateArgs>(args: Subset<T, TicketsAggregateArgs>): Prisma.PrismaPromise<GetTicketsAggregateType<T>>

    /**
     * Group by Tickets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ticketsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ticketsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ticketsGroupByArgs['orderBy'] }
        : { orderBy?: ticketsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ticketsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTicketsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the tickets model
   */
  readonly fields: ticketsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for tickets.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ticketsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    pays<T extends tickets$paysArgs<ExtArgs> = {}>(args?: Subset<T, tickets$paysArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$paysPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    pending_pay_tickets<T extends tickets$pending_pay_ticketsArgs<ExtArgs> = {}>(args?: Subset<T, tickets$pending_pay_ticketsArgs<ExtArgs>>): Prisma__pending_pay_ticketsClient<$Result.GetResult<Prisma.$pending_pay_ticketsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    ticket_details<T extends tickets$ticket_detailsArgs<ExtArgs> = {}>(args?: Subset<T, tickets$ticket_detailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticket_detailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    clients<T extends tickets$clientsArgs<ExtArgs> = {}>(args?: Subset<T, tickets$clientsArgs<ExtArgs>>): Prisma__clientsClient<$Result.GetResult<Prisma.$clientsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    offices<T extends tickets$officesArgs<ExtArgs> = {}>(args?: Subset<T, tickets$officesArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    users<T extends tickets$usersArgs<ExtArgs> = {}>(args?: Subset<T, tickets$usersArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the tickets model
   */
  interface ticketsFieldRefs {
    readonly id: FieldRef<"tickets", 'Int'>
    readonly office_id: FieldRef<"tickets", 'Int'>
    readonly user_id: FieldRef<"tickets", 'Int'>
    readonly client_id: FieldRef<"tickets", 'Int'>
    readonly type: FieldRef<"tickets", 'String'>
    readonly vehicle_plate: FieldRef<"tickets", 'String'>
    readonly date: FieldRef<"tickets", 'DateTime'>
    readonly needs_facture: FieldRef<"tickets", 'Boolean'>
    readonly total: FieldRef<"tickets", 'Decimal'>
  }
    

  // Custom InputTypes
  /**
   * tickets findUnique
   */
  export type ticketsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter, which tickets to fetch.
     */
    where: ticketsWhereUniqueInput
  }

  /**
   * tickets findUniqueOrThrow
   */
  export type ticketsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter, which tickets to fetch.
     */
    where: ticketsWhereUniqueInput
  }

  /**
   * tickets findFirst
   */
  export type ticketsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter, which tickets to fetch.
     */
    where?: ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tickets to fetch.
     */
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for tickets.
     */
    cursor?: ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of tickets.
     */
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * tickets findFirstOrThrow
   */
  export type ticketsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter, which tickets to fetch.
     */
    where?: ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tickets to fetch.
     */
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for tickets.
     */
    cursor?: ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tickets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of tickets.
     */
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * tickets findMany
   */
  export type ticketsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter, which tickets to fetch.
     */
    where?: ticketsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tickets to fetch.
     */
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing tickets.
     */
    cursor?: ticketsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tickets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tickets.
     */
    skip?: number
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * tickets create
   */
  export type ticketsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * The data needed to create a tickets.
     */
    data?: XOR<ticketsCreateInput, ticketsUncheckedCreateInput>
  }

  /**
   * tickets createMany
   */
  export type ticketsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many tickets.
     */
    data: ticketsCreateManyInput | ticketsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * tickets createManyAndReturn
   */
  export type ticketsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * The data used to create many tickets.
     */
    data: ticketsCreateManyInput | ticketsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * tickets update
   */
  export type ticketsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * The data needed to update a tickets.
     */
    data: XOR<ticketsUpdateInput, ticketsUncheckedUpdateInput>
    /**
     * Choose, which tickets to update.
     */
    where: ticketsWhereUniqueInput
  }

  /**
   * tickets updateMany
   */
  export type ticketsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update tickets.
     */
    data: XOR<ticketsUpdateManyMutationInput, ticketsUncheckedUpdateManyInput>
    /**
     * Filter which tickets to update
     */
    where?: ticketsWhereInput
    /**
     * Limit how many tickets to update.
     */
    limit?: number
  }

  /**
   * tickets updateManyAndReturn
   */
  export type ticketsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * The data used to update tickets.
     */
    data: XOR<ticketsUpdateManyMutationInput, ticketsUncheckedUpdateManyInput>
    /**
     * Filter which tickets to update
     */
    where?: ticketsWhereInput
    /**
     * Limit how many tickets to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * tickets upsert
   */
  export type ticketsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * The filter to search for the tickets to update in case it exists.
     */
    where: ticketsWhereUniqueInput
    /**
     * In case the tickets found by the `where` argument doesn't exist, create a new tickets with this data.
     */
    create: XOR<ticketsCreateInput, ticketsUncheckedCreateInput>
    /**
     * In case the tickets was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ticketsUpdateInput, ticketsUncheckedUpdateInput>
  }

  /**
   * tickets delete
   */
  export type ticketsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    /**
     * Filter which tickets to delete.
     */
    where: ticketsWhereUniqueInput
  }

  /**
   * tickets deleteMany
   */
  export type ticketsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which tickets to delete
     */
    where?: ticketsWhereInput
    /**
     * Limit how many tickets to delete.
     */
    limit?: number
  }

  /**
   * tickets.pays
   */
  export type tickets$paysArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pays
     */
    select?: paysSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pays
     */
    omit?: paysOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: paysInclude<ExtArgs> | null
    where?: paysWhereInput
    orderBy?: paysOrderByWithRelationInput | paysOrderByWithRelationInput[]
    cursor?: paysWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaysScalarFieldEnum | PaysScalarFieldEnum[]
  }

  /**
   * tickets.pending_pay_tickets
   */
  export type tickets$pending_pay_ticketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the pending_pay_tickets
     */
    select?: pending_pay_ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the pending_pay_tickets
     */
    omit?: pending_pay_ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: pending_pay_ticketsInclude<ExtArgs> | null
    where?: pending_pay_ticketsWhereInput
  }

  /**
   * tickets.ticket_details
   */
  export type tickets$ticket_detailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ticket_details
     */
    select?: ticket_detailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ticket_details
     */
    omit?: ticket_detailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticket_detailsInclude<ExtArgs> | null
    where?: ticket_detailsWhereInput
    orderBy?: ticket_detailsOrderByWithRelationInput | ticket_detailsOrderByWithRelationInput[]
    cursor?: ticket_detailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Ticket_detailsScalarFieldEnum | Ticket_detailsScalarFieldEnum[]
  }

  /**
   * tickets.clients
   */
  export type tickets$clientsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the clients
     */
    select?: clientsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the clients
     */
    omit?: clientsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: clientsInclude<ExtArgs> | null
    where?: clientsWhereInput
  }

  /**
   * tickets.offices
   */
  export type tickets$officesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    where?: officesWhereInput
  }

  /**
   * tickets.users
   */
  export type tickets$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    where?: usersWhereInput
  }

  /**
   * tickets without action
   */
  export type ticketsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
  }


  /**
   * Model users
   */

  export type AggregateUsers = {
    _count: UsersCountAggregateOutputType | null
    _avg: UsersAvgAggregateOutputType | null
    _sum: UsersSumAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  export type UsersAvgAggregateOutputType = {
    id: number | null
    office_id: number | null
  }

  export type UsersSumAggregateOutputType = {
    id: number | null
    office_id: number | null
  }

  export type UsersMinAggregateOutputType = {
    id: number | null
    username: string | null
    password: string | null
    name: string | null
    role: $Enums.user_role | null
    office_id: number | null
  }

  export type UsersMaxAggregateOutputType = {
    id: number | null
    username: string | null
    password: string | null
    name: string | null
    role: $Enums.user_role | null
    office_id: number | null
  }

  export type UsersCountAggregateOutputType = {
    id: number
    username: number
    password: number
    name: number
    role: number
    office_id: number
    _all: number
  }


  export type UsersAvgAggregateInputType = {
    id?: true
    office_id?: true
  }

  export type UsersSumAggregateInputType = {
    id?: true
    office_id?: true
  }

  export type UsersMinAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    role?: true
    office_id?: true
  }

  export type UsersMaxAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    role?: true
    office_id?: true
  }

  export type UsersCountAggregateInputType = {
    id?: true
    username?: true
    password?: true
    name?: true
    role?: true
    office_id?: true
    _all?: true
  }

  export type UsersAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to aggregate.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned users
    **/
    _count?: true | UsersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsersAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsersSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsersMaxAggregateInputType
  }

  export type GetUsersAggregateType<T extends UsersAggregateArgs> = {
        [P in keyof T & keyof AggregateUsers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsers[P]>
      : GetScalarType<T[P], AggregateUsers[P]>
  }




  export type usersGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
    orderBy?: usersOrderByWithAggregationInput | usersOrderByWithAggregationInput[]
    by: UsersScalarFieldEnum[] | UsersScalarFieldEnum
    having?: usersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsersCountAggregateInputType | true
    _avg?: UsersAvgAggregateInputType
    _sum?: UsersSumAggregateInputType
    _min?: UsersMinAggregateInputType
    _max?: UsersMaxAggregateInputType
  }

  export type UsersGroupByOutputType = {
    id: number
    username: string
    password: string
    name: string | null
    role: $Enums.user_role | null
    office_id: number | null
    _count: UsersCountAggregateOutputType | null
    _avg: UsersAvgAggregateOutputType | null
    _sum: UsersSumAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  type GetUsersGroupByPayload<T extends usersGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsersGroupByOutputType[P]>
            : GetScalarType<T[P], UsersGroupByOutputType[P]>
        }
      >
    >


  export type usersSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    office_id?: boolean
    tickets?: boolean | users$ticketsArgs<ExtArgs>
    offices?: boolean | users$officesArgs<ExtArgs>
    _count?: boolean | UsersCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    office_id?: boolean
    offices?: boolean | users$officesArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    office_id?: boolean
    offices?: boolean | users$officesArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectScalar = {
    id?: boolean
    username?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    office_id?: boolean
  }

  export type usersOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "username" | "password" | "name" | "role" | "office_id", ExtArgs["result"]["users"]>
  export type usersInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tickets?: boolean | users$ticketsArgs<ExtArgs>
    offices?: boolean | users$officesArgs<ExtArgs>
    _count?: boolean | UsersCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type usersIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | users$officesArgs<ExtArgs>
  }
  export type usersIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    offices?: boolean | users$officesArgs<ExtArgs>
  }

  export type $usersPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "users"
    objects: {
      tickets: Prisma.$ticketsPayload<ExtArgs>[]
      offices: Prisma.$officesPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      username: string
      password: string
      name: string | null
      role: $Enums.user_role | null
      office_id: number | null
    }, ExtArgs["result"]["users"]>
    composites: {}
  }

  type usersGetPayload<S extends boolean | null | undefined | usersDefaultArgs> = $Result.GetResult<Prisma.$usersPayload, S>

  type usersCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usersFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsersCountAggregateInputType | true
    }

  export interface usersDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['users'], meta: { name: 'users' } }
    /**
     * Find zero or one Users that matches the filter.
     * @param {usersFindUniqueArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usersFindUniqueArgs>(args: SelectSubset<T, usersFindUniqueArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Users that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usersFindUniqueOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usersFindUniqueOrThrowArgs>(args: SelectSubset<T, usersFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usersFindFirstArgs>(args?: SelectSubset<T, usersFindFirstArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Users that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usersFindFirstOrThrowArgs>(args?: SelectSubset<T, usersFindFirstOrThrowArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.users.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.users.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const usersWithIdOnly = await prisma.users.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends usersFindManyArgs>(args?: SelectSubset<T, usersFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Users.
     * @param {usersCreateArgs} args - Arguments to create a Users.
     * @example
     * // Create one Users
     * const Users = await prisma.users.create({
     *   data: {
     *     // ... data to create a Users
     *   }
     * })
     * 
     */
    create<T extends usersCreateArgs>(args: SelectSubset<T, usersCreateArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {usersCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const users = await prisma.users.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usersCreateManyArgs>(args?: SelectSubset<T, usersCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {usersCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const users = await prisma.users.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const usersWithIdOnly = await prisma.users.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends usersCreateManyAndReturnArgs>(args?: SelectSubset<T, usersCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Users.
     * @param {usersDeleteArgs} args - Arguments to delete one Users.
     * @example
     * // Delete one Users
     * const Users = await prisma.users.delete({
     *   where: {
     *     // ... filter to delete one Users
     *   }
     * })
     * 
     */
    delete<T extends usersDeleteArgs>(args: SelectSubset<T, usersDeleteArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Users.
     * @param {usersUpdateArgs} args - Arguments to update one Users.
     * @example
     * // Update one Users
     * const users = await prisma.users.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usersUpdateArgs>(args: SelectSubset<T, usersUpdateArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {usersDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.users.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usersDeleteManyArgs>(args?: SelectSubset<T, usersDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const users = await prisma.users.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usersUpdateManyArgs>(args: SelectSubset<T, usersUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {usersUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const users = await prisma.users.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const usersWithIdOnly = await prisma.users.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends usersUpdateManyAndReturnArgs>(args: SelectSubset<T, usersUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Users.
     * @param {usersUpsertArgs} args - Arguments to update or create a Users.
     * @example
     * // Update or create a Users
     * const users = await prisma.users.upsert({
     *   create: {
     *     // ... data to create a Users
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Users we want to update
     *   }
     * })
     */
    upsert<T extends usersUpsertArgs>(args: SelectSubset<T, usersUpsertArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.users.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends usersCountArgs>(
      args?: Subset<T, usersCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsersAggregateArgs>(args: Subset<T, UsersAggregateArgs>): Prisma.PrismaPromise<GetUsersAggregateType<T>>

    /**
     * Group by Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usersGroupByArgs['orderBy'] }
        : { orderBy?: usersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsersGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the users model
   */
  readonly fields: usersFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for users.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usersClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    tickets<T extends users$ticketsArgs<ExtArgs> = {}>(args?: Subset<T, users$ticketsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ticketsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    offices<T extends users$officesArgs<ExtArgs> = {}>(args?: Subset<T, users$officesArgs<ExtArgs>>): Prisma__officesClient<$Result.GetResult<Prisma.$officesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the users model
   */
  interface usersFieldRefs {
    readonly id: FieldRef<"users", 'Int'>
    readonly username: FieldRef<"users", 'String'>
    readonly password: FieldRef<"users", 'String'>
    readonly name: FieldRef<"users", 'String'>
    readonly role: FieldRef<"users", 'user_role'>
    readonly office_id: FieldRef<"users", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * users findUnique
   */
  export type usersFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findUniqueOrThrow
   */
  export type usersFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findFirst
   */
  export type usersFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findFirstOrThrow
   */
  export type usersFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findMany
   */
  export type usersFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users create
   */
  export type usersCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to create a users.
     */
    data: XOR<usersCreateInput, usersUncheckedCreateInput>
  }

  /**
   * users createMany
   */
  export type usersCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many users.
     */
    data: usersCreateManyInput | usersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * users createManyAndReturn
   */
  export type usersCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * The data used to create many users.
     */
    data: usersCreateManyInput | usersCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * users update
   */
  export type usersUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to update a users.
     */
    data: XOR<usersUpdateInput, usersUncheckedUpdateInput>
    /**
     * Choose, which users to update.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users updateMany
   */
  export type usersUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update users.
     */
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: usersWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
  }

  /**
   * users updateManyAndReturn
   */
  export type usersUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * The data used to update users.
     */
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: usersWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * users upsert
   */
  export type usersUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The filter to search for the users to update in case it exists.
     */
    where: usersWhereUniqueInput
    /**
     * In case the users found by the `where` argument doesn't exist, create a new users with this data.
     */
    create: XOR<usersCreateInput, usersUncheckedCreateInput>
    /**
     * In case the users was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usersUpdateInput, usersUncheckedUpdateInput>
  }

  /**
   * users delete
   */
  export type usersDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter which users to delete.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users deleteMany
   */
  export type usersDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to delete
     */
    where?: usersWhereInput
    /**
     * Limit how many users to delete.
     */
    limit?: number
  }

  /**
   * users.tickets
   */
  export type users$ticketsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tickets
     */
    select?: ticketsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tickets
     */
    omit?: ticketsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ticketsInclude<ExtArgs> | null
    where?: ticketsWhereInput
    orderBy?: ticketsOrderByWithRelationInput | ticketsOrderByWithRelationInput[]
    cursor?: ticketsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TicketsScalarFieldEnum | TicketsScalarFieldEnum[]
  }

  /**
   * users.offices
   */
  export type users$officesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the offices
     */
    select?: officesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the offices
     */
    omit?: officesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: officesInclude<ExtArgs> | null
    where?: officesWhereInput
  }

  /**
   * users without action
   */
  export type usersDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const ClientsScalarFieldEnum: {
    id: 'id',
    office_id: 'office_id',
    id_card: 'id_card',
    name: 'name',
    phone: 'phone',
    email: 'email',
    address: 'address'
  };

  export type ClientsScalarFieldEnum = (typeof ClientsScalarFieldEnum)[keyof typeof ClientsScalarFieldEnum]


  export const OfficesScalarFieldEnum: {
    id: 'id',
    name: 'name',
    phone: 'phone',
    address: 'address',
    email: 'email',
    id_card: 'id_card'
  };

  export type OfficesScalarFieldEnum = (typeof OfficesScalarFieldEnum)[keyof typeof OfficesScalarFieldEnum]


  export const PaysScalarFieldEnum: {
    id: 'id',
    office_id: 'office_id',
    ticket_id: 'ticket_id',
    client_id: 'client_id',
    type: 'type',
    cash: 'cash',
    transfer: 'transfer',
    card: 'card',
    sinpe: 'sinpe',
    bank_check: 'bank_check',
    mixed: 'mixed'
  };

  export type PaysScalarFieldEnum = (typeof PaysScalarFieldEnum)[keyof typeof PaysScalarFieldEnum]


  export const Pending_pay_ticketsScalarFieldEnum: {
    id_ticket: 'id_ticket',
    state: 'state',
    exp_date: 'exp_date',
    total_to_pay: 'total_to_pay',
    total_payed: 'total_payed'
  };

  export type Pending_pay_ticketsScalarFieldEnum = (typeof Pending_pay_ticketsScalarFieldEnum)[keyof typeof Pending_pay_ticketsScalarFieldEnum]


  export const ProductsScalarFieldEnum: {
    id: 'id',
    name: 'name',
    price: 'price',
    office_id: 'office_id'
  };

  export type ProductsScalarFieldEnum = (typeof ProductsScalarFieldEnum)[keyof typeof ProductsScalarFieldEnum]


  export const Ticket_detailsScalarFieldEnum: {
    ticket_id: 'ticket_id',
    product_id: 'product_id',
    quantity: 'quantity',
    discount: 'discount'
  };

  export type Ticket_detailsScalarFieldEnum = (typeof Ticket_detailsScalarFieldEnum)[keyof typeof Ticket_detailsScalarFieldEnum]


  export const TicketsScalarFieldEnum: {
    id: 'id',
    office_id: 'office_id',
    user_id: 'user_id',
    client_id: 'client_id',
    type: 'type',
    vehicle_plate: 'vehicle_plate',
    date: 'date',
    needs_facture: 'needs_facture',
    total: 'total'
  };

  export type TicketsScalarFieldEnum = (typeof TicketsScalarFieldEnum)[keyof typeof TicketsScalarFieldEnum]


  export const UsersScalarFieldEnum: {
    id: 'id',
    username: 'username',
    password: 'password',
    name: 'name',
    role: 'role',
    office_id: 'office_id'
  };

  export type UsersScalarFieldEnum = (typeof UsersScalarFieldEnum)[keyof typeof UsersScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Decimal[]'
   */
  export type ListDecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'user_role'
   */
  export type Enumuser_roleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'user_role'>
    


  /**
   * Reference to a field of type 'user_role[]'
   */
  export type ListEnumuser_roleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'user_role[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type clientsWhereInput = {
    AND?: clientsWhereInput | clientsWhereInput[]
    OR?: clientsWhereInput[]
    NOT?: clientsWhereInput | clientsWhereInput[]
    id?: IntFilter<"clients"> | number
    office_id?: IntNullableFilter<"clients"> | number | null
    id_card?: StringNullableFilter<"clients"> | string | null
    name?: StringNullableFilter<"clients"> | string | null
    phone?: StringNullableFilter<"clients"> | string | null
    email?: StringNullableFilter<"clients"> | string | null
    address?: StringNullableFilter<"clients"> | string | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    pays?: PaysListRelationFilter
    tickets?: TicketsListRelationFilter
  }

  export type clientsOrderByWithRelationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    id_card?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    offices?: officesOrderByWithRelationInput
    pays?: paysOrderByRelationAggregateInput
    tickets?: ticketsOrderByRelationAggregateInput
  }

  export type clientsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: clientsWhereInput | clientsWhereInput[]
    OR?: clientsWhereInput[]
    NOT?: clientsWhereInput | clientsWhereInput[]
    office_id?: IntNullableFilter<"clients"> | number | null
    id_card?: StringNullableFilter<"clients"> | string | null
    name?: StringNullableFilter<"clients"> | string | null
    phone?: StringNullableFilter<"clients"> | string | null
    email?: StringNullableFilter<"clients"> | string | null
    address?: StringNullableFilter<"clients"> | string | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    pays?: PaysListRelationFilter
    tickets?: TicketsListRelationFilter
  }, "id">

  export type clientsOrderByWithAggregationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    id_card?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    _count?: clientsCountOrderByAggregateInput
    _avg?: clientsAvgOrderByAggregateInput
    _max?: clientsMaxOrderByAggregateInput
    _min?: clientsMinOrderByAggregateInput
    _sum?: clientsSumOrderByAggregateInput
  }

  export type clientsScalarWhereWithAggregatesInput = {
    AND?: clientsScalarWhereWithAggregatesInput | clientsScalarWhereWithAggregatesInput[]
    OR?: clientsScalarWhereWithAggregatesInput[]
    NOT?: clientsScalarWhereWithAggregatesInput | clientsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"clients"> | number
    office_id?: IntNullableWithAggregatesFilter<"clients"> | number | null
    id_card?: StringNullableWithAggregatesFilter<"clients"> | string | null
    name?: StringNullableWithAggregatesFilter<"clients"> | string | null
    phone?: StringNullableWithAggregatesFilter<"clients"> | string | null
    email?: StringNullableWithAggregatesFilter<"clients"> | string | null
    address?: StringNullableWithAggregatesFilter<"clients"> | string | null
  }

  export type officesWhereInput = {
    AND?: officesWhereInput | officesWhereInput[]
    OR?: officesWhereInput[]
    NOT?: officesWhereInput | officesWhereInput[]
    id?: IntFilter<"offices"> | number
    name?: StringNullableFilter<"offices"> | string | null
    phone?: StringNullableFilter<"offices"> | string | null
    address?: StringNullableFilter<"offices"> | string | null
    email?: StringNullableFilter<"offices"> | string | null
    id_card?: StringNullableFilter<"offices"> | string | null
    clients?: ClientsListRelationFilter
    pays?: PaysListRelationFilter
    products?: ProductsListRelationFilter
    tickets?: TicketsListRelationFilter
    users?: UsersListRelationFilter
  }

  export type officesOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    id_card?: SortOrderInput | SortOrder
    clients?: clientsOrderByRelationAggregateInput
    pays?: paysOrderByRelationAggregateInput
    products?: productsOrderByRelationAggregateInput
    tickets?: ticketsOrderByRelationAggregateInput
    users?: usersOrderByRelationAggregateInput
  }

  export type officesWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: officesWhereInput | officesWhereInput[]
    OR?: officesWhereInput[]
    NOT?: officesWhereInput | officesWhereInput[]
    name?: StringNullableFilter<"offices"> | string | null
    phone?: StringNullableFilter<"offices"> | string | null
    address?: StringNullableFilter<"offices"> | string | null
    email?: StringNullableFilter<"offices"> | string | null
    id_card?: StringNullableFilter<"offices"> | string | null
    clients?: ClientsListRelationFilter
    pays?: PaysListRelationFilter
    products?: ProductsListRelationFilter
    tickets?: TicketsListRelationFilter
    users?: UsersListRelationFilter
  }, "id">

  export type officesOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    id_card?: SortOrderInput | SortOrder
    _count?: officesCountOrderByAggregateInput
    _avg?: officesAvgOrderByAggregateInput
    _max?: officesMaxOrderByAggregateInput
    _min?: officesMinOrderByAggregateInput
    _sum?: officesSumOrderByAggregateInput
  }

  export type officesScalarWhereWithAggregatesInput = {
    AND?: officesScalarWhereWithAggregatesInput | officesScalarWhereWithAggregatesInput[]
    OR?: officesScalarWhereWithAggregatesInput[]
    NOT?: officesScalarWhereWithAggregatesInput | officesScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"offices"> | number
    name?: StringNullableWithAggregatesFilter<"offices"> | string | null
    phone?: StringNullableWithAggregatesFilter<"offices"> | string | null
    address?: StringNullableWithAggregatesFilter<"offices"> | string | null
    email?: StringNullableWithAggregatesFilter<"offices"> | string | null
    id_card?: StringNullableWithAggregatesFilter<"offices"> | string | null
  }

  export type paysWhereInput = {
    AND?: paysWhereInput | paysWhereInput[]
    OR?: paysWhereInput[]
    NOT?: paysWhereInput | paysWhereInput[]
    id?: IntFilter<"pays"> | number
    office_id?: IntNullableFilter<"pays"> | number | null
    ticket_id?: IntNullableFilter<"pays"> | number | null
    client_id?: IntNullableFilter<"pays"> | number | null
    type?: StringNullableFilter<"pays"> | string | null
    cash?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    transfer?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    card?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    sinpe?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    bank_check?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    mixed?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    clients?: XOR<ClientsNullableScalarRelationFilter, clientsWhereInput> | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    tickets?: XOR<TicketsNullableScalarRelationFilter, ticketsWhereInput> | null
  }

  export type paysOrderByWithRelationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    ticket_id?: SortOrderInput | SortOrder
    client_id?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    cash?: SortOrderInput | SortOrder
    transfer?: SortOrderInput | SortOrder
    card?: SortOrderInput | SortOrder
    sinpe?: SortOrderInput | SortOrder
    bank_check?: SortOrderInput | SortOrder
    mixed?: SortOrderInput | SortOrder
    clients?: clientsOrderByWithRelationInput
    offices?: officesOrderByWithRelationInput
    tickets?: ticketsOrderByWithRelationInput
  }

  export type paysWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: paysWhereInput | paysWhereInput[]
    OR?: paysWhereInput[]
    NOT?: paysWhereInput | paysWhereInput[]
    office_id?: IntNullableFilter<"pays"> | number | null
    ticket_id?: IntNullableFilter<"pays"> | number | null
    client_id?: IntNullableFilter<"pays"> | number | null
    type?: StringNullableFilter<"pays"> | string | null
    cash?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    transfer?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    card?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    sinpe?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    bank_check?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    mixed?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    clients?: XOR<ClientsNullableScalarRelationFilter, clientsWhereInput> | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    tickets?: XOR<TicketsNullableScalarRelationFilter, ticketsWhereInput> | null
  }, "id">

  export type paysOrderByWithAggregationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    ticket_id?: SortOrderInput | SortOrder
    client_id?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    cash?: SortOrderInput | SortOrder
    transfer?: SortOrderInput | SortOrder
    card?: SortOrderInput | SortOrder
    sinpe?: SortOrderInput | SortOrder
    bank_check?: SortOrderInput | SortOrder
    mixed?: SortOrderInput | SortOrder
    _count?: paysCountOrderByAggregateInput
    _avg?: paysAvgOrderByAggregateInput
    _max?: paysMaxOrderByAggregateInput
    _min?: paysMinOrderByAggregateInput
    _sum?: paysSumOrderByAggregateInput
  }

  export type paysScalarWhereWithAggregatesInput = {
    AND?: paysScalarWhereWithAggregatesInput | paysScalarWhereWithAggregatesInput[]
    OR?: paysScalarWhereWithAggregatesInput[]
    NOT?: paysScalarWhereWithAggregatesInput | paysScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"pays"> | number
    office_id?: IntNullableWithAggregatesFilter<"pays"> | number | null
    ticket_id?: IntNullableWithAggregatesFilter<"pays"> | number | null
    client_id?: IntNullableWithAggregatesFilter<"pays"> | number | null
    type?: StringNullableWithAggregatesFilter<"pays"> | string | null
    cash?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    transfer?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    card?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    sinpe?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    bank_check?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    mixed?: DecimalNullableWithAggregatesFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsWhereInput = {
    AND?: pending_pay_ticketsWhereInput | pending_pay_ticketsWhereInput[]
    OR?: pending_pay_ticketsWhereInput[]
    NOT?: pending_pay_ticketsWhereInput | pending_pay_ticketsWhereInput[]
    id_ticket?: IntFilter<"pending_pay_tickets"> | number
    state?: StringNullableFilter<"pending_pay_tickets"> | string | null
    exp_date?: DateTimeNullableFilter<"pending_pay_tickets"> | Date | string | null
    total_to_pay?: DecimalNullableFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
    total_payed?: DecimalNullableFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
    tickets?: XOR<TicketsScalarRelationFilter, ticketsWhereInput>
  }

  export type pending_pay_ticketsOrderByWithRelationInput = {
    id_ticket?: SortOrder
    state?: SortOrderInput | SortOrder
    exp_date?: SortOrderInput | SortOrder
    total_to_pay?: SortOrderInput | SortOrder
    total_payed?: SortOrderInput | SortOrder
    tickets?: ticketsOrderByWithRelationInput
  }

  export type pending_pay_ticketsWhereUniqueInput = Prisma.AtLeast<{
    id_ticket?: number
    AND?: pending_pay_ticketsWhereInput | pending_pay_ticketsWhereInput[]
    OR?: pending_pay_ticketsWhereInput[]
    NOT?: pending_pay_ticketsWhereInput | pending_pay_ticketsWhereInput[]
    state?: StringNullableFilter<"pending_pay_tickets"> | string | null
    exp_date?: DateTimeNullableFilter<"pending_pay_tickets"> | Date | string | null
    total_to_pay?: DecimalNullableFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
    total_payed?: DecimalNullableFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
    tickets?: XOR<TicketsScalarRelationFilter, ticketsWhereInput>
  }, "id_ticket">

  export type pending_pay_ticketsOrderByWithAggregationInput = {
    id_ticket?: SortOrder
    state?: SortOrderInput | SortOrder
    exp_date?: SortOrderInput | SortOrder
    total_to_pay?: SortOrderInput | SortOrder
    total_payed?: SortOrderInput | SortOrder
    _count?: pending_pay_ticketsCountOrderByAggregateInput
    _avg?: pending_pay_ticketsAvgOrderByAggregateInput
    _max?: pending_pay_ticketsMaxOrderByAggregateInput
    _min?: pending_pay_ticketsMinOrderByAggregateInput
    _sum?: pending_pay_ticketsSumOrderByAggregateInput
  }

  export type pending_pay_ticketsScalarWhereWithAggregatesInput = {
    AND?: pending_pay_ticketsScalarWhereWithAggregatesInput | pending_pay_ticketsScalarWhereWithAggregatesInput[]
    OR?: pending_pay_ticketsScalarWhereWithAggregatesInput[]
    NOT?: pending_pay_ticketsScalarWhereWithAggregatesInput | pending_pay_ticketsScalarWhereWithAggregatesInput[]
    id_ticket?: IntWithAggregatesFilter<"pending_pay_tickets"> | number
    state?: StringNullableWithAggregatesFilter<"pending_pay_tickets"> | string | null
    exp_date?: DateTimeNullableWithAggregatesFilter<"pending_pay_tickets"> | Date | string | null
    total_to_pay?: DecimalNullableWithAggregatesFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
    total_payed?: DecimalNullableWithAggregatesFilter<"pending_pay_tickets"> | Decimal | DecimalJsLike | number | string | null
  }

  export type productsWhereInput = {
    AND?: productsWhereInput | productsWhereInput[]
    OR?: productsWhereInput[]
    NOT?: productsWhereInput | productsWhereInput[]
    id?: IntFilter<"products"> | number
    name?: StringNullableFilter<"products"> | string | null
    price?: DecimalNullableFilter<"products"> | Decimal | DecimalJsLike | number | string | null
    office_id?: IntNullableFilter<"products"> | number | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    ticket_details?: Ticket_detailsListRelationFilter
  }

  export type productsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    price?: SortOrderInput | SortOrder
    office_id?: SortOrderInput | SortOrder
    offices?: officesOrderByWithRelationInput
    ticket_details?: ticket_detailsOrderByRelationAggregateInput
  }

  export type productsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: productsWhereInput | productsWhereInput[]
    OR?: productsWhereInput[]
    NOT?: productsWhereInput | productsWhereInput[]
    name?: StringNullableFilter<"products"> | string | null
    price?: DecimalNullableFilter<"products"> | Decimal | DecimalJsLike | number | string | null
    office_id?: IntNullableFilter<"products"> | number | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    ticket_details?: Ticket_detailsListRelationFilter
  }, "id">

  export type productsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    price?: SortOrderInput | SortOrder
    office_id?: SortOrderInput | SortOrder
    _count?: productsCountOrderByAggregateInput
    _avg?: productsAvgOrderByAggregateInput
    _max?: productsMaxOrderByAggregateInput
    _min?: productsMinOrderByAggregateInput
    _sum?: productsSumOrderByAggregateInput
  }

  export type productsScalarWhereWithAggregatesInput = {
    AND?: productsScalarWhereWithAggregatesInput | productsScalarWhereWithAggregatesInput[]
    OR?: productsScalarWhereWithAggregatesInput[]
    NOT?: productsScalarWhereWithAggregatesInput | productsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"products"> | number
    name?: StringNullableWithAggregatesFilter<"products"> | string | null
    price?: DecimalNullableWithAggregatesFilter<"products"> | Decimal | DecimalJsLike | number | string | null
    office_id?: IntNullableWithAggregatesFilter<"products"> | number | null
  }

  export type ticket_detailsWhereInput = {
    AND?: ticket_detailsWhereInput | ticket_detailsWhereInput[]
    OR?: ticket_detailsWhereInput[]
    NOT?: ticket_detailsWhereInput | ticket_detailsWhereInput[]
    ticket_id?: IntFilter<"ticket_details"> | number
    product_id?: IntFilter<"ticket_details"> | number
    quantity?: IntNullableFilter<"ticket_details"> | number | null
    discount?: DecimalNullableFilter<"ticket_details"> | Decimal | DecimalJsLike | number | string | null
    products?: XOR<ProductsScalarRelationFilter, productsWhereInput>
    tickets?: XOR<TicketsScalarRelationFilter, ticketsWhereInput>
  }

  export type ticket_detailsOrderByWithRelationInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrderInput | SortOrder
    discount?: SortOrderInput | SortOrder
    products?: productsOrderByWithRelationInput
    tickets?: ticketsOrderByWithRelationInput
  }

  export type ticket_detailsWhereUniqueInput = Prisma.AtLeast<{
    ticket_id_product_id?: ticket_detailsTicket_idProduct_idCompoundUniqueInput
    AND?: ticket_detailsWhereInput | ticket_detailsWhereInput[]
    OR?: ticket_detailsWhereInput[]
    NOT?: ticket_detailsWhereInput | ticket_detailsWhereInput[]
    ticket_id?: IntFilter<"ticket_details"> | number
    product_id?: IntFilter<"ticket_details"> | number
    quantity?: IntNullableFilter<"ticket_details"> | number | null
    discount?: DecimalNullableFilter<"ticket_details"> | Decimal | DecimalJsLike | number | string | null
    products?: XOR<ProductsScalarRelationFilter, productsWhereInput>
    tickets?: XOR<TicketsScalarRelationFilter, ticketsWhereInput>
  }, "ticket_id_product_id">

  export type ticket_detailsOrderByWithAggregationInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrderInput | SortOrder
    discount?: SortOrderInput | SortOrder
    _count?: ticket_detailsCountOrderByAggregateInput
    _avg?: ticket_detailsAvgOrderByAggregateInput
    _max?: ticket_detailsMaxOrderByAggregateInput
    _min?: ticket_detailsMinOrderByAggregateInput
    _sum?: ticket_detailsSumOrderByAggregateInput
  }

  export type ticket_detailsScalarWhereWithAggregatesInput = {
    AND?: ticket_detailsScalarWhereWithAggregatesInput | ticket_detailsScalarWhereWithAggregatesInput[]
    OR?: ticket_detailsScalarWhereWithAggregatesInput[]
    NOT?: ticket_detailsScalarWhereWithAggregatesInput | ticket_detailsScalarWhereWithAggregatesInput[]
    ticket_id?: IntWithAggregatesFilter<"ticket_details"> | number
    product_id?: IntWithAggregatesFilter<"ticket_details"> | number
    quantity?: IntNullableWithAggregatesFilter<"ticket_details"> | number | null
    discount?: DecimalNullableWithAggregatesFilter<"ticket_details"> | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsWhereInput = {
    AND?: ticketsWhereInput | ticketsWhereInput[]
    OR?: ticketsWhereInput[]
    NOT?: ticketsWhereInput | ticketsWhereInput[]
    id?: IntFilter<"tickets"> | number
    office_id?: IntNullableFilter<"tickets"> | number | null
    user_id?: IntNullableFilter<"tickets"> | number | null
    client_id?: IntNullableFilter<"tickets"> | number | null
    type?: StringNullableFilter<"tickets"> | string | null
    vehicle_plate?: StringNullableFilter<"tickets"> | string | null
    date?: DateTimeNullableFilter<"tickets"> | Date | string | null
    needs_facture?: BoolNullableFilter<"tickets"> | boolean | null
    total?: DecimalNullableFilter<"tickets"> | Decimal | DecimalJsLike | number | string | null
    pays?: PaysListRelationFilter
    pending_pay_tickets?: XOR<Pending_pay_ticketsNullableScalarRelationFilter, pending_pay_ticketsWhereInput> | null
    ticket_details?: Ticket_detailsListRelationFilter
    clients?: XOR<ClientsNullableScalarRelationFilter, clientsWhereInput> | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    users?: XOR<UsersNullableScalarRelationFilter, usersWhereInput> | null
  }

  export type ticketsOrderByWithRelationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    user_id?: SortOrderInput | SortOrder
    client_id?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    vehicle_plate?: SortOrderInput | SortOrder
    date?: SortOrderInput | SortOrder
    needs_facture?: SortOrderInput | SortOrder
    total?: SortOrderInput | SortOrder
    pays?: paysOrderByRelationAggregateInput
    pending_pay_tickets?: pending_pay_ticketsOrderByWithRelationInput
    ticket_details?: ticket_detailsOrderByRelationAggregateInput
    clients?: clientsOrderByWithRelationInput
    offices?: officesOrderByWithRelationInput
    users?: usersOrderByWithRelationInput
  }

  export type ticketsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ticketsWhereInput | ticketsWhereInput[]
    OR?: ticketsWhereInput[]
    NOT?: ticketsWhereInput | ticketsWhereInput[]
    office_id?: IntNullableFilter<"tickets"> | number | null
    user_id?: IntNullableFilter<"tickets"> | number | null
    client_id?: IntNullableFilter<"tickets"> | number | null
    type?: StringNullableFilter<"tickets"> | string | null
    vehicle_plate?: StringNullableFilter<"tickets"> | string | null
    date?: DateTimeNullableFilter<"tickets"> | Date | string | null
    needs_facture?: BoolNullableFilter<"tickets"> | boolean | null
    total?: DecimalNullableFilter<"tickets"> | Decimal | DecimalJsLike | number | string | null
    pays?: PaysListRelationFilter
    pending_pay_tickets?: XOR<Pending_pay_ticketsNullableScalarRelationFilter, pending_pay_ticketsWhereInput> | null
    ticket_details?: Ticket_detailsListRelationFilter
    clients?: XOR<ClientsNullableScalarRelationFilter, clientsWhereInput> | null
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
    users?: XOR<UsersNullableScalarRelationFilter, usersWhereInput> | null
  }, "id">

  export type ticketsOrderByWithAggregationInput = {
    id?: SortOrder
    office_id?: SortOrderInput | SortOrder
    user_id?: SortOrderInput | SortOrder
    client_id?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    vehicle_plate?: SortOrderInput | SortOrder
    date?: SortOrderInput | SortOrder
    needs_facture?: SortOrderInput | SortOrder
    total?: SortOrderInput | SortOrder
    _count?: ticketsCountOrderByAggregateInput
    _avg?: ticketsAvgOrderByAggregateInput
    _max?: ticketsMaxOrderByAggregateInput
    _min?: ticketsMinOrderByAggregateInput
    _sum?: ticketsSumOrderByAggregateInput
  }

  export type ticketsScalarWhereWithAggregatesInput = {
    AND?: ticketsScalarWhereWithAggregatesInput | ticketsScalarWhereWithAggregatesInput[]
    OR?: ticketsScalarWhereWithAggregatesInput[]
    NOT?: ticketsScalarWhereWithAggregatesInput | ticketsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"tickets"> | number
    office_id?: IntNullableWithAggregatesFilter<"tickets"> | number | null
    user_id?: IntNullableWithAggregatesFilter<"tickets"> | number | null
    client_id?: IntNullableWithAggregatesFilter<"tickets"> | number | null
    type?: StringNullableWithAggregatesFilter<"tickets"> | string | null
    vehicle_plate?: StringNullableWithAggregatesFilter<"tickets"> | string | null
    date?: DateTimeNullableWithAggregatesFilter<"tickets"> | Date | string | null
    needs_facture?: BoolNullableWithAggregatesFilter<"tickets"> | boolean | null
    total?: DecimalNullableWithAggregatesFilter<"tickets"> | Decimal | DecimalJsLike | number | string | null
  }

  export type usersWhereInput = {
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    id?: IntFilter<"users"> | number
    username?: StringFilter<"users"> | string
    password?: StringFilter<"users"> | string
    name?: StringNullableFilter<"users"> | string | null
    role?: Enumuser_roleNullableFilter<"users"> | $Enums.user_role | null
    office_id?: IntNullableFilter<"users"> | number | null
    tickets?: TicketsListRelationFilter
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
  }

  export type usersOrderByWithRelationInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrderInput | SortOrder
    office_id?: SortOrderInput | SortOrder
    tickets?: ticketsOrderByRelationAggregateInput
    offices?: officesOrderByWithRelationInput
  }

  export type usersWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    username?: string
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    password?: StringFilter<"users"> | string
    name?: StringNullableFilter<"users"> | string | null
    role?: Enumuser_roleNullableFilter<"users"> | $Enums.user_role | null
    office_id?: IntNullableFilter<"users"> | number | null
    tickets?: TicketsListRelationFilter
    offices?: XOR<OfficesNullableScalarRelationFilter, officesWhereInput> | null
  }, "id" | "username">

  export type usersOrderByWithAggregationInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrderInput | SortOrder
    office_id?: SortOrderInput | SortOrder
    _count?: usersCountOrderByAggregateInput
    _avg?: usersAvgOrderByAggregateInput
    _max?: usersMaxOrderByAggregateInput
    _min?: usersMinOrderByAggregateInput
    _sum?: usersSumOrderByAggregateInput
  }

  export type usersScalarWhereWithAggregatesInput = {
    AND?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    OR?: usersScalarWhereWithAggregatesInput[]
    NOT?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"users"> | number
    username?: StringWithAggregatesFilter<"users"> | string
    password?: StringWithAggregatesFilter<"users"> | string
    name?: StringNullableWithAggregatesFilter<"users"> | string | null
    role?: Enumuser_roleNullableWithAggregatesFilter<"users"> | $Enums.user_role | null
    office_id?: IntNullableWithAggregatesFilter<"users"> | number | null
  }

  export type clientsCreateInput = {
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    offices?: officesCreateNestedOneWithoutClientsInput
    pays?: paysCreateNestedManyWithoutClientsInput
    tickets?: ticketsCreateNestedManyWithoutClientsInput
  }

  export type clientsUncheckedCreateInput = {
    id?: number
    office_id?: number | null
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    pays?: paysUncheckedCreateNestedManyWithoutClientsInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutClientsInput
  }

  export type clientsUpdateInput = {
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    offices?: officesUpdateOneWithoutClientsNestedInput
    pays?: paysUpdateManyWithoutClientsNestedInput
    tickets?: ticketsUpdateManyWithoutClientsNestedInput
  }

  export type clientsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUncheckedUpdateManyWithoutClientsNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutClientsNestedInput
  }

  export type clientsCreateManyInput = {
    id?: number
    office_id?: number | null
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
  }

  export type clientsUpdateManyMutationInput = {
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type clientsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type officesCreateInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsCreateNestedManyWithoutOfficesInput
    pays?: paysCreateNestedManyWithoutOfficesInput
    products?: productsCreateNestedManyWithoutOfficesInput
    tickets?: ticketsCreateNestedManyWithoutOfficesInput
    users?: usersCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsUncheckedCreateNestedManyWithoutOfficesInput
    pays?: paysUncheckedCreateNestedManyWithoutOfficesInput
    products?: productsUncheckedCreateNestedManyWithoutOfficesInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutOfficesInput
    users?: usersUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesUpdateInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUpdateManyWithoutOfficesNestedInput
    pays?: paysUpdateManyWithoutOfficesNestedInput
    products?: productsUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUpdateManyWithoutOfficesNestedInput
    users?: usersUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUncheckedUpdateManyWithoutOfficesNestedInput
    pays?: paysUncheckedUpdateManyWithoutOfficesNestedInput
    products?: productsUncheckedUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutOfficesNestedInput
    users?: usersUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type officesCreateManyInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
  }

  export type officesUpdateManyMutationInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type officesUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type paysCreateInput = {
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
    clients?: clientsCreateNestedOneWithoutPaysInput
    offices?: officesCreateNestedOneWithoutPaysInput
    tickets?: ticketsCreateNestedOneWithoutPaysInput
  }

  export type paysUncheckedCreateInput = {
    id?: number
    office_id?: number | null
    ticket_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysUpdateInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    clients?: clientsUpdateOneWithoutPaysNestedInput
    offices?: officesUpdateOneWithoutPaysNestedInput
    tickets?: ticketsUpdateOneWithoutPaysNestedInput
  }

  export type paysUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysCreateManyInput = {
    id?: number
    office_id?: number | null
    ticket_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysUpdateManyMutationInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsCreateInput = {
    state?: string | null
    exp_date?: Date | string | null
    total_to_pay?: Decimal | DecimalJsLike | number | string | null
    total_payed?: Decimal | DecimalJsLike | number | string | null
    tickets: ticketsCreateNestedOneWithoutPending_pay_ticketsInput
  }

  export type pending_pay_ticketsUncheckedCreateInput = {
    id_ticket: number
    state?: string | null
    exp_date?: Date | string | null
    total_to_pay?: Decimal | DecimalJsLike | number | string | null
    total_payed?: Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsUpdateInput = {
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    tickets?: ticketsUpdateOneRequiredWithoutPending_pay_ticketsNestedInput
  }

  export type pending_pay_ticketsUncheckedUpdateInput = {
    id_ticket?: IntFieldUpdateOperationsInput | number
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsCreateManyInput = {
    id_ticket: number
    state?: string | null
    exp_date?: Date | string | null
    total_to_pay?: Decimal | DecimalJsLike | number | string | null
    total_payed?: Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsUpdateManyMutationInput = {
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsUncheckedUpdateManyInput = {
    id_ticket?: IntFieldUpdateOperationsInput | number
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type productsCreateInput = {
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    offices?: officesCreateNestedOneWithoutProductsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutProductsInput
  }

  export type productsUncheckedCreateInput = {
    id?: number
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    office_id?: number | null
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutProductsInput
  }

  export type productsUpdateInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    offices?: officesUpdateOneWithoutProductsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutProductsNestedInput
  }

  export type productsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutProductsNestedInput
  }

  export type productsCreateManyInput = {
    id?: number
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    office_id?: number | null
  }

  export type productsUpdateManyMutationInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type productsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type ticket_detailsCreateInput = {
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
    products: productsCreateNestedOneWithoutTicket_detailsInput
    tickets: ticketsCreateNestedOneWithoutTicket_detailsInput
  }

  export type ticket_detailsUncheckedCreateInput = {
    ticket_id: number
    product_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUpdateInput = {
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    products?: productsUpdateOneRequiredWithoutTicket_detailsNestedInput
    tickets?: ticketsUpdateOneRequiredWithoutTicket_detailsNestedInput
  }

  export type ticket_detailsUncheckedUpdateInput = {
    ticket_id?: IntFieldUpdateOperationsInput | number
    product_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsCreateManyInput = {
    ticket_id: number
    product_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUpdateManyMutationInput = {
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUncheckedUpdateManyInput = {
    ticket_id?: IntFieldUpdateOperationsInput | number
    product_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsCreateInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsUpdateInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type ticketsCreateManyInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUpdateManyMutationInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type usersCreateInput = {
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    tickets?: ticketsCreateNestedManyWithoutUsersInput
    offices?: officesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateInput = {
    id?: number
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    office_id?: number | null
    tickets?: ticketsUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersUpdateInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    tickets?: ticketsUpdateManyWithoutUsersNestedInput
    offices?: officesUpdateOneWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    tickets?: ticketsUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type usersCreateManyInput = {
    id?: number
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    office_id?: number | null
  }

  export type usersUpdateManyMutationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
  }

  export type usersUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type OfficesNullableScalarRelationFilter = {
    is?: officesWhereInput | null
    isNot?: officesWhereInput | null
  }

  export type PaysListRelationFilter = {
    every?: paysWhereInput
    some?: paysWhereInput
    none?: paysWhereInput
  }

  export type TicketsListRelationFilter = {
    every?: ticketsWhereInput
    some?: ticketsWhereInput
    none?: ticketsWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type paysOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ticketsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type clientsCountOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    id_card?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    address?: SortOrder
  }

  export type clientsAvgOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
  }

  export type clientsMaxOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    id_card?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    address?: SortOrder
  }

  export type clientsMinOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    id_card?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    address?: SortOrder
  }

  export type clientsSumOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type ClientsListRelationFilter = {
    every?: clientsWhereInput
    some?: clientsWhereInput
    none?: clientsWhereInput
  }

  export type ProductsListRelationFilter = {
    every?: productsWhereInput
    some?: productsWhereInput
    none?: productsWhereInput
  }

  export type UsersListRelationFilter = {
    every?: usersWhereInput
    some?: usersWhereInput
    none?: usersWhereInput
  }

  export type clientsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type productsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type usersOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type officesCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    email?: SortOrder
    id_card?: SortOrder
  }

  export type officesAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type officesMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    email?: SortOrder
    id_card?: SortOrder
  }

  export type officesMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    email?: SortOrder
    id_card?: SortOrder
  }

  export type officesSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type DecimalNullableFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
  }

  export type ClientsNullableScalarRelationFilter = {
    is?: clientsWhereInput | null
    isNot?: clientsWhereInput | null
  }

  export type TicketsNullableScalarRelationFilter = {
    is?: ticketsWhereInput | null
    isNot?: ticketsWhereInput | null
  }

  export type paysCountOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    ticket_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    cash?: SortOrder
    transfer?: SortOrder
    card?: SortOrder
    sinpe?: SortOrder
    bank_check?: SortOrder
    mixed?: SortOrder
  }

  export type paysAvgOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    ticket_id?: SortOrder
    client_id?: SortOrder
    cash?: SortOrder
    transfer?: SortOrder
    card?: SortOrder
    sinpe?: SortOrder
    bank_check?: SortOrder
    mixed?: SortOrder
  }

  export type paysMaxOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    ticket_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    cash?: SortOrder
    transfer?: SortOrder
    card?: SortOrder
    sinpe?: SortOrder
    bank_check?: SortOrder
    mixed?: SortOrder
  }

  export type paysMinOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    ticket_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    cash?: SortOrder
    transfer?: SortOrder
    card?: SortOrder
    sinpe?: SortOrder
    bank_check?: SortOrder
    mixed?: SortOrder
  }

  export type paysSumOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    ticket_id?: SortOrder
    client_id?: SortOrder
    cash?: SortOrder
    transfer?: SortOrder
    card?: SortOrder
    sinpe?: SortOrder
    bank_check?: SortOrder
    mixed?: SortOrder
  }

  export type DecimalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedDecimalNullableFilter<$PrismaModel>
    _sum?: NestedDecimalNullableFilter<$PrismaModel>
    _min?: NestedDecimalNullableFilter<$PrismaModel>
    _max?: NestedDecimalNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type TicketsScalarRelationFilter = {
    is?: ticketsWhereInput
    isNot?: ticketsWhereInput
  }

  export type pending_pay_ticketsCountOrderByAggregateInput = {
    id_ticket?: SortOrder
    state?: SortOrder
    exp_date?: SortOrder
    total_to_pay?: SortOrder
    total_payed?: SortOrder
  }

  export type pending_pay_ticketsAvgOrderByAggregateInput = {
    id_ticket?: SortOrder
    total_to_pay?: SortOrder
    total_payed?: SortOrder
  }

  export type pending_pay_ticketsMaxOrderByAggregateInput = {
    id_ticket?: SortOrder
    state?: SortOrder
    exp_date?: SortOrder
    total_to_pay?: SortOrder
    total_payed?: SortOrder
  }

  export type pending_pay_ticketsMinOrderByAggregateInput = {
    id_ticket?: SortOrder
    state?: SortOrder
    exp_date?: SortOrder
    total_to_pay?: SortOrder
    total_payed?: SortOrder
  }

  export type pending_pay_ticketsSumOrderByAggregateInput = {
    id_ticket?: SortOrder
    total_to_pay?: SortOrder
    total_payed?: SortOrder
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type Ticket_detailsListRelationFilter = {
    every?: ticket_detailsWhereInput
    some?: ticket_detailsWhereInput
    none?: ticket_detailsWhereInput
  }

  export type ticket_detailsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type productsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    price?: SortOrder
    office_id?: SortOrder
  }

  export type productsAvgOrderByAggregateInput = {
    id?: SortOrder
    price?: SortOrder
    office_id?: SortOrder
  }

  export type productsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    price?: SortOrder
    office_id?: SortOrder
  }

  export type productsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    price?: SortOrder
    office_id?: SortOrder
  }

  export type productsSumOrderByAggregateInput = {
    id?: SortOrder
    price?: SortOrder
    office_id?: SortOrder
  }

  export type ProductsScalarRelationFilter = {
    is?: productsWhereInput
    isNot?: productsWhereInput
  }

  export type ticket_detailsTicket_idProduct_idCompoundUniqueInput = {
    ticket_id: number
    product_id: number
  }

  export type ticket_detailsCountOrderByAggregateInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    discount?: SortOrder
  }

  export type ticket_detailsAvgOrderByAggregateInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    discount?: SortOrder
  }

  export type ticket_detailsMaxOrderByAggregateInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    discount?: SortOrder
  }

  export type ticket_detailsMinOrderByAggregateInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    discount?: SortOrder
  }

  export type ticket_detailsSumOrderByAggregateInput = {
    ticket_id?: SortOrder
    product_id?: SortOrder
    quantity?: SortOrder
    discount?: SortOrder
  }

  export type BoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type Pending_pay_ticketsNullableScalarRelationFilter = {
    is?: pending_pay_ticketsWhereInput | null
    isNot?: pending_pay_ticketsWhereInput | null
  }

  export type UsersNullableScalarRelationFilter = {
    is?: usersWhereInput | null
    isNot?: usersWhereInput | null
  }

  export type ticketsCountOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    user_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    vehicle_plate?: SortOrder
    date?: SortOrder
    needs_facture?: SortOrder
    total?: SortOrder
  }

  export type ticketsAvgOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    user_id?: SortOrder
    client_id?: SortOrder
    total?: SortOrder
  }

  export type ticketsMaxOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    user_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    vehicle_plate?: SortOrder
    date?: SortOrder
    needs_facture?: SortOrder
    total?: SortOrder
  }

  export type ticketsMinOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    user_id?: SortOrder
    client_id?: SortOrder
    type?: SortOrder
    vehicle_plate?: SortOrder
    date?: SortOrder
    needs_facture?: SortOrder
    total?: SortOrder
  }

  export type ticketsSumOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
    user_id?: SortOrder
    client_id?: SortOrder
    total?: SortOrder
  }

  export type BoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type Enumuser_roleNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.user_role | Enumuser_roleFieldRefInput<$PrismaModel> | null
    in?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    not?: NestedEnumuser_roleNullableFilter<$PrismaModel> | $Enums.user_role | null
  }

  export type usersCountOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    office_id?: SortOrder
  }

  export type usersAvgOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
  }

  export type usersMaxOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    office_id?: SortOrder
  }

  export type usersMinOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    office_id?: SortOrder
  }

  export type usersSumOrderByAggregateInput = {
    id?: SortOrder
    office_id?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type Enumuser_roleNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.user_role | Enumuser_roleFieldRefInput<$PrismaModel> | null
    in?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    not?: NestedEnumuser_roleNullableWithAggregatesFilter<$PrismaModel> | $Enums.user_role | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumuser_roleNullableFilter<$PrismaModel>
    _max?: NestedEnumuser_roleNullableFilter<$PrismaModel>
  }

  export type officesCreateNestedOneWithoutClientsInput = {
    create?: XOR<officesCreateWithoutClientsInput, officesUncheckedCreateWithoutClientsInput>
    connectOrCreate?: officesCreateOrConnectWithoutClientsInput
    connect?: officesWhereUniqueInput
  }

  export type paysCreateNestedManyWithoutClientsInput = {
    create?: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput> | paysCreateWithoutClientsInput[] | paysUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutClientsInput | paysCreateOrConnectWithoutClientsInput[]
    createMany?: paysCreateManyClientsInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type ticketsCreateNestedManyWithoutClientsInput = {
    create?: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput> | ticketsCreateWithoutClientsInput[] | ticketsUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutClientsInput | ticketsCreateOrConnectWithoutClientsInput[]
    createMany?: ticketsCreateManyClientsInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type paysUncheckedCreateNestedManyWithoutClientsInput = {
    create?: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput> | paysCreateWithoutClientsInput[] | paysUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutClientsInput | paysCreateOrConnectWithoutClientsInput[]
    createMany?: paysCreateManyClientsInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type ticketsUncheckedCreateNestedManyWithoutClientsInput = {
    create?: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput> | ticketsCreateWithoutClientsInput[] | ticketsUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutClientsInput | ticketsCreateOrConnectWithoutClientsInput[]
    createMany?: ticketsCreateManyClientsInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type officesUpdateOneWithoutClientsNestedInput = {
    create?: XOR<officesCreateWithoutClientsInput, officesUncheckedCreateWithoutClientsInput>
    connectOrCreate?: officesCreateOrConnectWithoutClientsInput
    upsert?: officesUpsertWithoutClientsInput
    disconnect?: officesWhereInput | boolean
    delete?: officesWhereInput | boolean
    connect?: officesWhereUniqueInput
    update?: XOR<XOR<officesUpdateToOneWithWhereWithoutClientsInput, officesUpdateWithoutClientsInput>, officesUncheckedUpdateWithoutClientsInput>
  }

  export type paysUpdateManyWithoutClientsNestedInput = {
    create?: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput> | paysCreateWithoutClientsInput[] | paysUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutClientsInput | paysCreateOrConnectWithoutClientsInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutClientsInput | paysUpsertWithWhereUniqueWithoutClientsInput[]
    createMany?: paysCreateManyClientsInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutClientsInput | paysUpdateWithWhereUniqueWithoutClientsInput[]
    updateMany?: paysUpdateManyWithWhereWithoutClientsInput | paysUpdateManyWithWhereWithoutClientsInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type ticketsUpdateManyWithoutClientsNestedInput = {
    create?: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput> | ticketsCreateWithoutClientsInput[] | ticketsUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutClientsInput | ticketsCreateOrConnectWithoutClientsInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutClientsInput | ticketsUpsertWithWhereUniqueWithoutClientsInput[]
    createMany?: ticketsCreateManyClientsInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutClientsInput | ticketsUpdateWithWhereUniqueWithoutClientsInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutClientsInput | ticketsUpdateManyWithWhereWithoutClientsInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type paysUncheckedUpdateManyWithoutClientsNestedInput = {
    create?: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput> | paysCreateWithoutClientsInput[] | paysUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutClientsInput | paysCreateOrConnectWithoutClientsInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutClientsInput | paysUpsertWithWhereUniqueWithoutClientsInput[]
    createMany?: paysCreateManyClientsInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutClientsInput | paysUpdateWithWhereUniqueWithoutClientsInput[]
    updateMany?: paysUpdateManyWithWhereWithoutClientsInput | paysUpdateManyWithWhereWithoutClientsInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type ticketsUncheckedUpdateManyWithoutClientsNestedInput = {
    create?: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput> | ticketsCreateWithoutClientsInput[] | ticketsUncheckedCreateWithoutClientsInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutClientsInput | ticketsCreateOrConnectWithoutClientsInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutClientsInput | ticketsUpsertWithWhereUniqueWithoutClientsInput[]
    createMany?: ticketsCreateManyClientsInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutClientsInput | ticketsUpdateWithWhereUniqueWithoutClientsInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutClientsInput | ticketsUpdateManyWithWhereWithoutClientsInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type clientsCreateNestedManyWithoutOfficesInput = {
    create?: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput> | clientsCreateWithoutOfficesInput[] | clientsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: clientsCreateOrConnectWithoutOfficesInput | clientsCreateOrConnectWithoutOfficesInput[]
    createMany?: clientsCreateManyOfficesInputEnvelope
    connect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
  }

  export type paysCreateNestedManyWithoutOfficesInput = {
    create?: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput> | paysCreateWithoutOfficesInput[] | paysUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: paysCreateOrConnectWithoutOfficesInput | paysCreateOrConnectWithoutOfficesInput[]
    createMany?: paysCreateManyOfficesInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type productsCreateNestedManyWithoutOfficesInput = {
    create?: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput> | productsCreateWithoutOfficesInput[] | productsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: productsCreateOrConnectWithoutOfficesInput | productsCreateOrConnectWithoutOfficesInput[]
    createMany?: productsCreateManyOfficesInputEnvelope
    connect?: productsWhereUniqueInput | productsWhereUniqueInput[]
  }

  export type ticketsCreateNestedManyWithoutOfficesInput = {
    create?: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput> | ticketsCreateWithoutOfficesInput[] | ticketsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutOfficesInput | ticketsCreateOrConnectWithoutOfficesInput[]
    createMany?: ticketsCreateManyOfficesInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type usersCreateNestedManyWithoutOfficesInput = {
    create?: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput> | usersCreateWithoutOfficesInput[] | usersUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOfficesInput | usersCreateOrConnectWithoutOfficesInput[]
    createMany?: usersCreateManyOfficesInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type clientsUncheckedCreateNestedManyWithoutOfficesInput = {
    create?: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput> | clientsCreateWithoutOfficesInput[] | clientsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: clientsCreateOrConnectWithoutOfficesInput | clientsCreateOrConnectWithoutOfficesInput[]
    createMany?: clientsCreateManyOfficesInputEnvelope
    connect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
  }

  export type paysUncheckedCreateNestedManyWithoutOfficesInput = {
    create?: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput> | paysCreateWithoutOfficesInput[] | paysUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: paysCreateOrConnectWithoutOfficesInput | paysCreateOrConnectWithoutOfficesInput[]
    createMany?: paysCreateManyOfficesInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type productsUncheckedCreateNestedManyWithoutOfficesInput = {
    create?: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput> | productsCreateWithoutOfficesInput[] | productsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: productsCreateOrConnectWithoutOfficesInput | productsCreateOrConnectWithoutOfficesInput[]
    createMany?: productsCreateManyOfficesInputEnvelope
    connect?: productsWhereUniqueInput | productsWhereUniqueInput[]
  }

  export type ticketsUncheckedCreateNestedManyWithoutOfficesInput = {
    create?: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput> | ticketsCreateWithoutOfficesInput[] | ticketsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutOfficesInput | ticketsCreateOrConnectWithoutOfficesInput[]
    createMany?: ticketsCreateManyOfficesInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type usersUncheckedCreateNestedManyWithoutOfficesInput = {
    create?: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput> | usersCreateWithoutOfficesInput[] | usersUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOfficesInput | usersCreateOrConnectWithoutOfficesInput[]
    createMany?: usersCreateManyOfficesInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type clientsUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput> | clientsCreateWithoutOfficesInput[] | clientsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: clientsCreateOrConnectWithoutOfficesInput | clientsCreateOrConnectWithoutOfficesInput[]
    upsert?: clientsUpsertWithWhereUniqueWithoutOfficesInput | clientsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: clientsCreateManyOfficesInputEnvelope
    set?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    disconnect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    delete?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    connect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    update?: clientsUpdateWithWhereUniqueWithoutOfficesInput | clientsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: clientsUpdateManyWithWhereWithoutOfficesInput | clientsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: clientsScalarWhereInput | clientsScalarWhereInput[]
  }

  export type paysUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput> | paysCreateWithoutOfficesInput[] | paysUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: paysCreateOrConnectWithoutOfficesInput | paysCreateOrConnectWithoutOfficesInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutOfficesInput | paysUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: paysCreateManyOfficesInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutOfficesInput | paysUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: paysUpdateManyWithWhereWithoutOfficesInput | paysUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type productsUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput> | productsCreateWithoutOfficesInput[] | productsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: productsCreateOrConnectWithoutOfficesInput | productsCreateOrConnectWithoutOfficesInput[]
    upsert?: productsUpsertWithWhereUniqueWithoutOfficesInput | productsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: productsCreateManyOfficesInputEnvelope
    set?: productsWhereUniqueInput | productsWhereUniqueInput[]
    disconnect?: productsWhereUniqueInput | productsWhereUniqueInput[]
    delete?: productsWhereUniqueInput | productsWhereUniqueInput[]
    connect?: productsWhereUniqueInput | productsWhereUniqueInput[]
    update?: productsUpdateWithWhereUniqueWithoutOfficesInput | productsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: productsUpdateManyWithWhereWithoutOfficesInput | productsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: productsScalarWhereInput | productsScalarWhereInput[]
  }

  export type ticketsUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput> | ticketsCreateWithoutOfficesInput[] | ticketsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutOfficesInput | ticketsCreateOrConnectWithoutOfficesInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutOfficesInput | ticketsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: ticketsCreateManyOfficesInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutOfficesInput | ticketsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutOfficesInput | ticketsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type usersUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput> | usersCreateWithoutOfficesInput[] | usersUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOfficesInput | usersCreateOrConnectWithoutOfficesInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutOfficesInput | usersUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: usersCreateManyOfficesInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutOfficesInput | usersUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: usersUpdateManyWithWhereWithoutOfficesInput | usersUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type clientsUncheckedUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput> | clientsCreateWithoutOfficesInput[] | clientsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: clientsCreateOrConnectWithoutOfficesInput | clientsCreateOrConnectWithoutOfficesInput[]
    upsert?: clientsUpsertWithWhereUniqueWithoutOfficesInput | clientsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: clientsCreateManyOfficesInputEnvelope
    set?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    disconnect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    delete?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    connect?: clientsWhereUniqueInput | clientsWhereUniqueInput[]
    update?: clientsUpdateWithWhereUniqueWithoutOfficesInput | clientsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: clientsUpdateManyWithWhereWithoutOfficesInput | clientsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: clientsScalarWhereInput | clientsScalarWhereInput[]
  }

  export type paysUncheckedUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput> | paysCreateWithoutOfficesInput[] | paysUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: paysCreateOrConnectWithoutOfficesInput | paysCreateOrConnectWithoutOfficesInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutOfficesInput | paysUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: paysCreateManyOfficesInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutOfficesInput | paysUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: paysUpdateManyWithWhereWithoutOfficesInput | paysUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type productsUncheckedUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput> | productsCreateWithoutOfficesInput[] | productsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: productsCreateOrConnectWithoutOfficesInput | productsCreateOrConnectWithoutOfficesInput[]
    upsert?: productsUpsertWithWhereUniqueWithoutOfficesInput | productsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: productsCreateManyOfficesInputEnvelope
    set?: productsWhereUniqueInput | productsWhereUniqueInput[]
    disconnect?: productsWhereUniqueInput | productsWhereUniqueInput[]
    delete?: productsWhereUniqueInput | productsWhereUniqueInput[]
    connect?: productsWhereUniqueInput | productsWhereUniqueInput[]
    update?: productsUpdateWithWhereUniqueWithoutOfficesInput | productsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: productsUpdateManyWithWhereWithoutOfficesInput | productsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: productsScalarWhereInput | productsScalarWhereInput[]
  }

  export type ticketsUncheckedUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput> | ticketsCreateWithoutOfficesInput[] | ticketsUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutOfficesInput | ticketsCreateOrConnectWithoutOfficesInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutOfficesInput | ticketsUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: ticketsCreateManyOfficesInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutOfficesInput | ticketsUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutOfficesInput | ticketsUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type usersUncheckedUpdateManyWithoutOfficesNestedInput = {
    create?: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput> | usersCreateWithoutOfficesInput[] | usersUncheckedCreateWithoutOfficesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOfficesInput | usersCreateOrConnectWithoutOfficesInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutOfficesInput | usersUpsertWithWhereUniqueWithoutOfficesInput[]
    createMany?: usersCreateManyOfficesInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutOfficesInput | usersUpdateWithWhereUniqueWithoutOfficesInput[]
    updateMany?: usersUpdateManyWithWhereWithoutOfficesInput | usersUpdateManyWithWhereWithoutOfficesInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type clientsCreateNestedOneWithoutPaysInput = {
    create?: XOR<clientsCreateWithoutPaysInput, clientsUncheckedCreateWithoutPaysInput>
    connectOrCreate?: clientsCreateOrConnectWithoutPaysInput
    connect?: clientsWhereUniqueInput
  }

  export type officesCreateNestedOneWithoutPaysInput = {
    create?: XOR<officesCreateWithoutPaysInput, officesUncheckedCreateWithoutPaysInput>
    connectOrCreate?: officesCreateOrConnectWithoutPaysInput
    connect?: officesWhereUniqueInput
  }

  export type ticketsCreateNestedOneWithoutPaysInput = {
    create?: XOR<ticketsCreateWithoutPaysInput, ticketsUncheckedCreateWithoutPaysInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutPaysInput
    connect?: ticketsWhereUniqueInput
  }

  export type NullableDecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string | null
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type clientsUpdateOneWithoutPaysNestedInput = {
    create?: XOR<clientsCreateWithoutPaysInput, clientsUncheckedCreateWithoutPaysInput>
    connectOrCreate?: clientsCreateOrConnectWithoutPaysInput
    upsert?: clientsUpsertWithoutPaysInput
    disconnect?: clientsWhereInput | boolean
    delete?: clientsWhereInput | boolean
    connect?: clientsWhereUniqueInput
    update?: XOR<XOR<clientsUpdateToOneWithWhereWithoutPaysInput, clientsUpdateWithoutPaysInput>, clientsUncheckedUpdateWithoutPaysInput>
  }

  export type officesUpdateOneWithoutPaysNestedInput = {
    create?: XOR<officesCreateWithoutPaysInput, officesUncheckedCreateWithoutPaysInput>
    connectOrCreate?: officesCreateOrConnectWithoutPaysInput
    upsert?: officesUpsertWithoutPaysInput
    disconnect?: officesWhereInput | boolean
    delete?: officesWhereInput | boolean
    connect?: officesWhereUniqueInput
    update?: XOR<XOR<officesUpdateToOneWithWhereWithoutPaysInput, officesUpdateWithoutPaysInput>, officesUncheckedUpdateWithoutPaysInput>
  }

  export type ticketsUpdateOneWithoutPaysNestedInput = {
    create?: XOR<ticketsCreateWithoutPaysInput, ticketsUncheckedCreateWithoutPaysInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutPaysInput
    upsert?: ticketsUpsertWithoutPaysInput
    disconnect?: ticketsWhereInput | boolean
    delete?: ticketsWhereInput | boolean
    connect?: ticketsWhereUniqueInput
    update?: XOR<XOR<ticketsUpdateToOneWithWhereWithoutPaysInput, ticketsUpdateWithoutPaysInput>, ticketsUncheckedUpdateWithoutPaysInput>
  }

  export type ticketsCreateNestedOneWithoutPending_pay_ticketsInput = {
    create?: XOR<ticketsCreateWithoutPending_pay_ticketsInput, ticketsUncheckedCreateWithoutPending_pay_ticketsInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutPending_pay_ticketsInput
    connect?: ticketsWhereUniqueInput
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type ticketsUpdateOneRequiredWithoutPending_pay_ticketsNestedInput = {
    create?: XOR<ticketsCreateWithoutPending_pay_ticketsInput, ticketsUncheckedCreateWithoutPending_pay_ticketsInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutPending_pay_ticketsInput
    upsert?: ticketsUpsertWithoutPending_pay_ticketsInput
    connect?: ticketsWhereUniqueInput
    update?: XOR<XOR<ticketsUpdateToOneWithWhereWithoutPending_pay_ticketsInput, ticketsUpdateWithoutPending_pay_ticketsInput>, ticketsUncheckedUpdateWithoutPending_pay_ticketsInput>
  }

  export type officesCreateNestedOneWithoutProductsInput = {
    create?: XOR<officesCreateWithoutProductsInput, officesUncheckedCreateWithoutProductsInput>
    connectOrCreate?: officesCreateOrConnectWithoutProductsInput
    connect?: officesWhereUniqueInput
  }

  export type ticket_detailsCreateNestedManyWithoutProductsInput = {
    create?: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput> | ticket_detailsCreateWithoutProductsInput[] | ticket_detailsUncheckedCreateWithoutProductsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutProductsInput | ticket_detailsCreateOrConnectWithoutProductsInput[]
    createMany?: ticket_detailsCreateManyProductsInputEnvelope
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
  }

  export type ticket_detailsUncheckedCreateNestedManyWithoutProductsInput = {
    create?: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput> | ticket_detailsCreateWithoutProductsInput[] | ticket_detailsUncheckedCreateWithoutProductsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutProductsInput | ticket_detailsCreateOrConnectWithoutProductsInput[]
    createMany?: ticket_detailsCreateManyProductsInputEnvelope
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
  }

  export type officesUpdateOneWithoutProductsNestedInput = {
    create?: XOR<officesCreateWithoutProductsInput, officesUncheckedCreateWithoutProductsInput>
    connectOrCreate?: officesCreateOrConnectWithoutProductsInput
    upsert?: officesUpsertWithoutProductsInput
    disconnect?: officesWhereInput | boolean
    delete?: officesWhereInput | boolean
    connect?: officesWhereUniqueInput
    update?: XOR<XOR<officesUpdateToOneWithWhereWithoutProductsInput, officesUpdateWithoutProductsInput>, officesUncheckedUpdateWithoutProductsInput>
  }

  export type ticket_detailsUpdateManyWithoutProductsNestedInput = {
    create?: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput> | ticket_detailsCreateWithoutProductsInput[] | ticket_detailsUncheckedCreateWithoutProductsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutProductsInput | ticket_detailsCreateOrConnectWithoutProductsInput[]
    upsert?: ticket_detailsUpsertWithWhereUniqueWithoutProductsInput | ticket_detailsUpsertWithWhereUniqueWithoutProductsInput[]
    createMany?: ticket_detailsCreateManyProductsInputEnvelope
    set?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    disconnect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    delete?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    update?: ticket_detailsUpdateWithWhereUniqueWithoutProductsInput | ticket_detailsUpdateWithWhereUniqueWithoutProductsInput[]
    updateMany?: ticket_detailsUpdateManyWithWhereWithoutProductsInput | ticket_detailsUpdateManyWithWhereWithoutProductsInput[]
    deleteMany?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
  }

  export type ticket_detailsUncheckedUpdateManyWithoutProductsNestedInput = {
    create?: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput> | ticket_detailsCreateWithoutProductsInput[] | ticket_detailsUncheckedCreateWithoutProductsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutProductsInput | ticket_detailsCreateOrConnectWithoutProductsInput[]
    upsert?: ticket_detailsUpsertWithWhereUniqueWithoutProductsInput | ticket_detailsUpsertWithWhereUniqueWithoutProductsInput[]
    createMany?: ticket_detailsCreateManyProductsInputEnvelope
    set?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    disconnect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    delete?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    update?: ticket_detailsUpdateWithWhereUniqueWithoutProductsInput | ticket_detailsUpdateWithWhereUniqueWithoutProductsInput[]
    updateMany?: ticket_detailsUpdateManyWithWhereWithoutProductsInput | ticket_detailsUpdateManyWithWhereWithoutProductsInput[]
    deleteMany?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
  }

  export type productsCreateNestedOneWithoutTicket_detailsInput = {
    create?: XOR<productsCreateWithoutTicket_detailsInput, productsUncheckedCreateWithoutTicket_detailsInput>
    connectOrCreate?: productsCreateOrConnectWithoutTicket_detailsInput
    connect?: productsWhereUniqueInput
  }

  export type ticketsCreateNestedOneWithoutTicket_detailsInput = {
    create?: XOR<ticketsCreateWithoutTicket_detailsInput, ticketsUncheckedCreateWithoutTicket_detailsInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutTicket_detailsInput
    connect?: ticketsWhereUniqueInput
  }

  export type productsUpdateOneRequiredWithoutTicket_detailsNestedInput = {
    create?: XOR<productsCreateWithoutTicket_detailsInput, productsUncheckedCreateWithoutTicket_detailsInput>
    connectOrCreate?: productsCreateOrConnectWithoutTicket_detailsInput
    upsert?: productsUpsertWithoutTicket_detailsInput
    connect?: productsWhereUniqueInput
    update?: XOR<XOR<productsUpdateToOneWithWhereWithoutTicket_detailsInput, productsUpdateWithoutTicket_detailsInput>, productsUncheckedUpdateWithoutTicket_detailsInput>
  }

  export type ticketsUpdateOneRequiredWithoutTicket_detailsNestedInput = {
    create?: XOR<ticketsCreateWithoutTicket_detailsInput, ticketsUncheckedCreateWithoutTicket_detailsInput>
    connectOrCreate?: ticketsCreateOrConnectWithoutTicket_detailsInput
    upsert?: ticketsUpsertWithoutTicket_detailsInput
    connect?: ticketsWhereUniqueInput
    update?: XOR<XOR<ticketsUpdateToOneWithWhereWithoutTicket_detailsInput, ticketsUpdateWithoutTicket_detailsInput>, ticketsUncheckedUpdateWithoutTicket_detailsInput>
  }

  export type paysCreateNestedManyWithoutTicketsInput = {
    create?: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput> | paysCreateWithoutTicketsInput[] | paysUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutTicketsInput | paysCreateOrConnectWithoutTicketsInput[]
    createMany?: paysCreateManyTicketsInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type pending_pay_ticketsCreateNestedOneWithoutTicketsInput = {
    create?: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: pending_pay_ticketsCreateOrConnectWithoutTicketsInput
    connect?: pending_pay_ticketsWhereUniqueInput
  }

  export type ticket_detailsCreateNestedManyWithoutTicketsInput = {
    create?: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput> | ticket_detailsCreateWithoutTicketsInput[] | ticket_detailsUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutTicketsInput | ticket_detailsCreateOrConnectWithoutTicketsInput[]
    createMany?: ticket_detailsCreateManyTicketsInputEnvelope
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
  }

  export type clientsCreateNestedOneWithoutTicketsInput = {
    create?: XOR<clientsCreateWithoutTicketsInput, clientsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: clientsCreateOrConnectWithoutTicketsInput
    connect?: clientsWhereUniqueInput
  }

  export type officesCreateNestedOneWithoutTicketsInput = {
    create?: XOR<officesCreateWithoutTicketsInput, officesUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: officesCreateOrConnectWithoutTicketsInput
    connect?: officesWhereUniqueInput
  }

  export type usersCreateNestedOneWithoutTicketsInput = {
    create?: XOR<usersCreateWithoutTicketsInput, usersUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: usersCreateOrConnectWithoutTicketsInput
    connect?: usersWhereUniqueInput
  }

  export type paysUncheckedCreateNestedManyWithoutTicketsInput = {
    create?: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput> | paysCreateWithoutTicketsInput[] | paysUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutTicketsInput | paysCreateOrConnectWithoutTicketsInput[]
    createMany?: paysCreateManyTicketsInputEnvelope
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
  }

  export type pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput = {
    create?: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: pending_pay_ticketsCreateOrConnectWithoutTicketsInput
    connect?: pending_pay_ticketsWhereUniqueInput
  }

  export type ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput = {
    create?: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput> | ticket_detailsCreateWithoutTicketsInput[] | ticket_detailsUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutTicketsInput | ticket_detailsCreateOrConnectWithoutTicketsInput[]
    createMany?: ticket_detailsCreateManyTicketsInputEnvelope
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type paysUpdateManyWithoutTicketsNestedInput = {
    create?: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput> | paysCreateWithoutTicketsInput[] | paysUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutTicketsInput | paysCreateOrConnectWithoutTicketsInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutTicketsInput | paysUpsertWithWhereUniqueWithoutTicketsInput[]
    createMany?: paysCreateManyTicketsInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutTicketsInput | paysUpdateWithWhereUniqueWithoutTicketsInput[]
    updateMany?: paysUpdateManyWithWhereWithoutTicketsInput | paysUpdateManyWithWhereWithoutTicketsInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type pending_pay_ticketsUpdateOneWithoutTicketsNestedInput = {
    create?: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: pending_pay_ticketsCreateOrConnectWithoutTicketsInput
    upsert?: pending_pay_ticketsUpsertWithoutTicketsInput
    disconnect?: pending_pay_ticketsWhereInput | boolean
    delete?: pending_pay_ticketsWhereInput | boolean
    connect?: pending_pay_ticketsWhereUniqueInput
    update?: XOR<XOR<pending_pay_ticketsUpdateToOneWithWhereWithoutTicketsInput, pending_pay_ticketsUpdateWithoutTicketsInput>, pending_pay_ticketsUncheckedUpdateWithoutTicketsInput>
  }

  export type ticket_detailsUpdateManyWithoutTicketsNestedInput = {
    create?: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput> | ticket_detailsCreateWithoutTicketsInput[] | ticket_detailsUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutTicketsInput | ticket_detailsCreateOrConnectWithoutTicketsInput[]
    upsert?: ticket_detailsUpsertWithWhereUniqueWithoutTicketsInput | ticket_detailsUpsertWithWhereUniqueWithoutTicketsInput[]
    createMany?: ticket_detailsCreateManyTicketsInputEnvelope
    set?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    disconnect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    delete?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    update?: ticket_detailsUpdateWithWhereUniqueWithoutTicketsInput | ticket_detailsUpdateWithWhereUniqueWithoutTicketsInput[]
    updateMany?: ticket_detailsUpdateManyWithWhereWithoutTicketsInput | ticket_detailsUpdateManyWithWhereWithoutTicketsInput[]
    deleteMany?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
  }

  export type clientsUpdateOneWithoutTicketsNestedInput = {
    create?: XOR<clientsCreateWithoutTicketsInput, clientsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: clientsCreateOrConnectWithoutTicketsInput
    upsert?: clientsUpsertWithoutTicketsInput
    disconnect?: clientsWhereInput | boolean
    delete?: clientsWhereInput | boolean
    connect?: clientsWhereUniqueInput
    update?: XOR<XOR<clientsUpdateToOneWithWhereWithoutTicketsInput, clientsUpdateWithoutTicketsInput>, clientsUncheckedUpdateWithoutTicketsInput>
  }

  export type officesUpdateOneWithoutTicketsNestedInput = {
    create?: XOR<officesCreateWithoutTicketsInput, officesUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: officesCreateOrConnectWithoutTicketsInput
    upsert?: officesUpsertWithoutTicketsInput
    disconnect?: officesWhereInput | boolean
    delete?: officesWhereInput | boolean
    connect?: officesWhereUniqueInput
    update?: XOR<XOR<officesUpdateToOneWithWhereWithoutTicketsInput, officesUpdateWithoutTicketsInput>, officesUncheckedUpdateWithoutTicketsInput>
  }

  export type usersUpdateOneWithoutTicketsNestedInput = {
    create?: XOR<usersCreateWithoutTicketsInput, usersUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: usersCreateOrConnectWithoutTicketsInput
    upsert?: usersUpsertWithoutTicketsInput
    disconnect?: usersWhereInput | boolean
    delete?: usersWhereInput | boolean
    connect?: usersWhereUniqueInput
    update?: XOR<XOR<usersUpdateToOneWithWhereWithoutTicketsInput, usersUpdateWithoutTicketsInput>, usersUncheckedUpdateWithoutTicketsInput>
  }

  export type paysUncheckedUpdateManyWithoutTicketsNestedInput = {
    create?: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput> | paysCreateWithoutTicketsInput[] | paysUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: paysCreateOrConnectWithoutTicketsInput | paysCreateOrConnectWithoutTicketsInput[]
    upsert?: paysUpsertWithWhereUniqueWithoutTicketsInput | paysUpsertWithWhereUniqueWithoutTicketsInput[]
    createMany?: paysCreateManyTicketsInputEnvelope
    set?: paysWhereUniqueInput | paysWhereUniqueInput[]
    disconnect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    delete?: paysWhereUniqueInput | paysWhereUniqueInput[]
    connect?: paysWhereUniqueInput | paysWhereUniqueInput[]
    update?: paysUpdateWithWhereUniqueWithoutTicketsInput | paysUpdateWithWhereUniqueWithoutTicketsInput[]
    updateMany?: paysUpdateManyWithWhereWithoutTicketsInput | paysUpdateManyWithWhereWithoutTicketsInput[]
    deleteMany?: paysScalarWhereInput | paysScalarWhereInput[]
  }

  export type pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput = {
    create?: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
    connectOrCreate?: pending_pay_ticketsCreateOrConnectWithoutTicketsInput
    upsert?: pending_pay_ticketsUpsertWithoutTicketsInput
    disconnect?: pending_pay_ticketsWhereInput | boolean
    delete?: pending_pay_ticketsWhereInput | boolean
    connect?: pending_pay_ticketsWhereUniqueInput
    update?: XOR<XOR<pending_pay_ticketsUpdateToOneWithWhereWithoutTicketsInput, pending_pay_ticketsUpdateWithoutTicketsInput>, pending_pay_ticketsUncheckedUpdateWithoutTicketsInput>
  }

  export type ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput = {
    create?: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput> | ticket_detailsCreateWithoutTicketsInput[] | ticket_detailsUncheckedCreateWithoutTicketsInput[]
    connectOrCreate?: ticket_detailsCreateOrConnectWithoutTicketsInput | ticket_detailsCreateOrConnectWithoutTicketsInput[]
    upsert?: ticket_detailsUpsertWithWhereUniqueWithoutTicketsInput | ticket_detailsUpsertWithWhereUniqueWithoutTicketsInput[]
    createMany?: ticket_detailsCreateManyTicketsInputEnvelope
    set?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    disconnect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    delete?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    connect?: ticket_detailsWhereUniqueInput | ticket_detailsWhereUniqueInput[]
    update?: ticket_detailsUpdateWithWhereUniqueWithoutTicketsInput | ticket_detailsUpdateWithWhereUniqueWithoutTicketsInput[]
    updateMany?: ticket_detailsUpdateManyWithWhereWithoutTicketsInput | ticket_detailsUpdateManyWithWhereWithoutTicketsInput[]
    deleteMany?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
  }

  export type ticketsCreateNestedManyWithoutUsersInput = {
    create?: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput> | ticketsCreateWithoutUsersInput[] | ticketsUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutUsersInput | ticketsCreateOrConnectWithoutUsersInput[]
    createMany?: ticketsCreateManyUsersInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type officesCreateNestedOneWithoutUsersInput = {
    create?: XOR<officesCreateWithoutUsersInput, officesUncheckedCreateWithoutUsersInput>
    connectOrCreate?: officesCreateOrConnectWithoutUsersInput
    connect?: officesWhereUniqueInput
  }

  export type ticketsUncheckedCreateNestedManyWithoutUsersInput = {
    create?: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput> | ticketsCreateWithoutUsersInput[] | ticketsUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutUsersInput | ticketsCreateOrConnectWithoutUsersInput[]
    createMany?: ticketsCreateManyUsersInputEnvelope
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableEnumuser_roleFieldUpdateOperationsInput = {
    set?: $Enums.user_role | null
  }

  export type ticketsUpdateManyWithoutUsersNestedInput = {
    create?: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput> | ticketsCreateWithoutUsersInput[] | ticketsUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutUsersInput | ticketsCreateOrConnectWithoutUsersInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutUsersInput | ticketsUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: ticketsCreateManyUsersInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutUsersInput | ticketsUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutUsersInput | ticketsUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type officesUpdateOneWithoutUsersNestedInput = {
    create?: XOR<officesCreateWithoutUsersInput, officesUncheckedCreateWithoutUsersInput>
    connectOrCreate?: officesCreateOrConnectWithoutUsersInput
    upsert?: officesUpsertWithoutUsersInput
    disconnect?: officesWhereInput | boolean
    delete?: officesWhereInput | boolean
    connect?: officesWhereUniqueInput
    update?: XOR<XOR<officesUpdateToOneWithWhereWithoutUsersInput, officesUpdateWithoutUsersInput>, officesUncheckedUpdateWithoutUsersInput>
  }

  export type ticketsUncheckedUpdateManyWithoutUsersNestedInput = {
    create?: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput> | ticketsCreateWithoutUsersInput[] | ticketsUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: ticketsCreateOrConnectWithoutUsersInput | ticketsCreateOrConnectWithoutUsersInput[]
    upsert?: ticketsUpsertWithWhereUniqueWithoutUsersInput | ticketsUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: ticketsCreateManyUsersInputEnvelope
    set?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    disconnect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    delete?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    connect?: ticketsWhereUniqueInput | ticketsWhereUniqueInput[]
    update?: ticketsUpdateWithWhereUniqueWithoutUsersInput | ticketsUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: ticketsUpdateManyWithWhereWithoutUsersInput | ticketsUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedDecimalNullableFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
  }

  export type NestedDecimalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel> | null
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel> | null
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalNullableWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedDecimalNullableFilter<$PrismaModel>
    _sum?: NestedDecimalNullableFilter<$PrismaModel>
    _min?: NestedDecimalNullableFilter<$PrismaModel>
    _max?: NestedDecimalNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedBoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type NestedBoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumuser_roleNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.user_role | Enumuser_roleFieldRefInput<$PrismaModel> | null
    in?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    not?: NestedEnumuser_roleNullableFilter<$PrismaModel> | $Enums.user_role | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumuser_roleNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.user_role | Enumuser_roleFieldRefInput<$PrismaModel> | null
    in?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.user_role[] | ListEnumuser_roleFieldRefInput<$PrismaModel> | null
    not?: NestedEnumuser_roleNullableWithAggregatesFilter<$PrismaModel> | $Enums.user_role | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumuser_roleNullableFilter<$PrismaModel>
    _max?: NestedEnumuser_roleNullableFilter<$PrismaModel>
  }

  export type officesCreateWithoutClientsInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    pays?: paysCreateNestedManyWithoutOfficesInput
    products?: productsCreateNestedManyWithoutOfficesInput
    tickets?: ticketsCreateNestedManyWithoutOfficesInput
    users?: usersCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateWithoutClientsInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    pays?: paysUncheckedCreateNestedManyWithoutOfficesInput
    products?: productsUncheckedCreateNestedManyWithoutOfficesInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutOfficesInput
    users?: usersUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesCreateOrConnectWithoutClientsInput = {
    where: officesWhereUniqueInput
    create: XOR<officesCreateWithoutClientsInput, officesUncheckedCreateWithoutClientsInput>
  }

  export type paysCreateWithoutClientsInput = {
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
    offices?: officesCreateNestedOneWithoutPaysInput
    tickets?: ticketsCreateNestedOneWithoutPaysInput
  }

  export type paysUncheckedCreateWithoutClientsInput = {
    id?: number
    office_id?: number | null
    ticket_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysCreateOrConnectWithoutClientsInput = {
    where: paysWhereUniqueInput
    create: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput>
  }

  export type paysCreateManyClientsInputEnvelope = {
    data: paysCreateManyClientsInput | paysCreateManyClientsInput[]
    skipDuplicates?: boolean
  }

  export type ticketsCreateWithoutClientsInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutClientsInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutClientsInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput>
  }

  export type ticketsCreateManyClientsInputEnvelope = {
    data: ticketsCreateManyClientsInput | ticketsCreateManyClientsInput[]
    skipDuplicates?: boolean
  }

  export type officesUpsertWithoutClientsInput = {
    update: XOR<officesUpdateWithoutClientsInput, officesUncheckedUpdateWithoutClientsInput>
    create: XOR<officesCreateWithoutClientsInput, officesUncheckedCreateWithoutClientsInput>
    where?: officesWhereInput
  }

  export type officesUpdateToOneWithWhereWithoutClientsInput = {
    where?: officesWhereInput
    data: XOR<officesUpdateWithoutClientsInput, officesUncheckedUpdateWithoutClientsInput>
  }

  export type officesUpdateWithoutClientsInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUpdateManyWithoutOfficesNestedInput
    products?: productsUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUpdateManyWithoutOfficesNestedInput
    users?: usersUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateWithoutClientsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUncheckedUpdateManyWithoutOfficesNestedInput
    products?: productsUncheckedUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutOfficesNestedInput
    users?: usersUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type paysUpsertWithWhereUniqueWithoutClientsInput = {
    where: paysWhereUniqueInput
    update: XOR<paysUpdateWithoutClientsInput, paysUncheckedUpdateWithoutClientsInput>
    create: XOR<paysCreateWithoutClientsInput, paysUncheckedCreateWithoutClientsInput>
  }

  export type paysUpdateWithWhereUniqueWithoutClientsInput = {
    where: paysWhereUniqueInput
    data: XOR<paysUpdateWithoutClientsInput, paysUncheckedUpdateWithoutClientsInput>
  }

  export type paysUpdateManyWithWhereWithoutClientsInput = {
    where: paysScalarWhereInput
    data: XOR<paysUpdateManyMutationInput, paysUncheckedUpdateManyWithoutClientsInput>
  }

  export type paysScalarWhereInput = {
    AND?: paysScalarWhereInput | paysScalarWhereInput[]
    OR?: paysScalarWhereInput[]
    NOT?: paysScalarWhereInput | paysScalarWhereInput[]
    id?: IntFilter<"pays"> | number
    office_id?: IntNullableFilter<"pays"> | number | null
    ticket_id?: IntNullableFilter<"pays"> | number | null
    client_id?: IntNullableFilter<"pays"> | number | null
    type?: StringNullableFilter<"pays"> | string | null
    cash?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    transfer?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    card?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    sinpe?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    bank_check?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
    mixed?: DecimalNullableFilter<"pays"> | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUpsertWithWhereUniqueWithoutClientsInput = {
    where: ticketsWhereUniqueInput
    update: XOR<ticketsUpdateWithoutClientsInput, ticketsUncheckedUpdateWithoutClientsInput>
    create: XOR<ticketsCreateWithoutClientsInput, ticketsUncheckedCreateWithoutClientsInput>
  }

  export type ticketsUpdateWithWhereUniqueWithoutClientsInput = {
    where: ticketsWhereUniqueInput
    data: XOR<ticketsUpdateWithoutClientsInput, ticketsUncheckedUpdateWithoutClientsInput>
  }

  export type ticketsUpdateManyWithWhereWithoutClientsInput = {
    where: ticketsScalarWhereInput
    data: XOR<ticketsUpdateManyMutationInput, ticketsUncheckedUpdateManyWithoutClientsInput>
  }

  export type ticketsScalarWhereInput = {
    AND?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
    OR?: ticketsScalarWhereInput[]
    NOT?: ticketsScalarWhereInput | ticketsScalarWhereInput[]
    id?: IntFilter<"tickets"> | number
    office_id?: IntNullableFilter<"tickets"> | number | null
    user_id?: IntNullableFilter<"tickets"> | number | null
    client_id?: IntNullableFilter<"tickets"> | number | null
    type?: StringNullableFilter<"tickets"> | string | null
    vehicle_plate?: StringNullableFilter<"tickets"> | string | null
    date?: DateTimeNullableFilter<"tickets"> | Date | string | null
    needs_facture?: BoolNullableFilter<"tickets"> | boolean | null
    total?: DecimalNullableFilter<"tickets"> | Decimal | DecimalJsLike | number | string | null
  }

  export type clientsCreateWithoutOfficesInput = {
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    pays?: paysCreateNestedManyWithoutClientsInput
    tickets?: ticketsCreateNestedManyWithoutClientsInput
  }

  export type clientsUncheckedCreateWithoutOfficesInput = {
    id?: number
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    pays?: paysUncheckedCreateNestedManyWithoutClientsInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutClientsInput
  }

  export type clientsCreateOrConnectWithoutOfficesInput = {
    where: clientsWhereUniqueInput
    create: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput>
  }

  export type clientsCreateManyOfficesInputEnvelope = {
    data: clientsCreateManyOfficesInput | clientsCreateManyOfficesInput[]
    skipDuplicates?: boolean
  }

  export type paysCreateWithoutOfficesInput = {
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
    clients?: clientsCreateNestedOneWithoutPaysInput
    tickets?: ticketsCreateNestedOneWithoutPaysInput
  }

  export type paysUncheckedCreateWithoutOfficesInput = {
    id?: number
    ticket_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysCreateOrConnectWithoutOfficesInput = {
    where: paysWhereUniqueInput
    create: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput>
  }

  export type paysCreateManyOfficesInputEnvelope = {
    data: paysCreateManyOfficesInput | paysCreateManyOfficesInput[]
    skipDuplicates?: boolean
  }

  export type productsCreateWithoutOfficesInput = {
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    ticket_details?: ticket_detailsCreateNestedManyWithoutProductsInput
  }

  export type productsUncheckedCreateWithoutOfficesInput = {
    id?: number
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutProductsInput
  }

  export type productsCreateOrConnectWithoutOfficesInput = {
    where: productsWhereUniqueInput
    create: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput>
  }

  export type productsCreateManyOfficesInputEnvelope = {
    data: productsCreateManyOfficesInput | productsCreateManyOfficesInput[]
    skipDuplicates?: boolean
  }

  export type ticketsCreateWithoutOfficesInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutOfficesInput = {
    id?: number
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutOfficesInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput>
  }

  export type ticketsCreateManyOfficesInputEnvelope = {
    data: ticketsCreateManyOfficesInput | ticketsCreateManyOfficesInput[]
    skipDuplicates?: boolean
  }

  export type usersCreateWithoutOfficesInput = {
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    tickets?: ticketsCreateNestedManyWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutOfficesInput = {
    id?: number
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    tickets?: ticketsUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutOfficesInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput>
  }

  export type usersCreateManyOfficesInputEnvelope = {
    data: usersCreateManyOfficesInput | usersCreateManyOfficesInput[]
    skipDuplicates?: boolean
  }

  export type clientsUpsertWithWhereUniqueWithoutOfficesInput = {
    where: clientsWhereUniqueInput
    update: XOR<clientsUpdateWithoutOfficesInput, clientsUncheckedUpdateWithoutOfficesInput>
    create: XOR<clientsCreateWithoutOfficesInput, clientsUncheckedCreateWithoutOfficesInput>
  }

  export type clientsUpdateWithWhereUniqueWithoutOfficesInput = {
    where: clientsWhereUniqueInput
    data: XOR<clientsUpdateWithoutOfficesInput, clientsUncheckedUpdateWithoutOfficesInput>
  }

  export type clientsUpdateManyWithWhereWithoutOfficesInput = {
    where: clientsScalarWhereInput
    data: XOR<clientsUpdateManyMutationInput, clientsUncheckedUpdateManyWithoutOfficesInput>
  }

  export type clientsScalarWhereInput = {
    AND?: clientsScalarWhereInput | clientsScalarWhereInput[]
    OR?: clientsScalarWhereInput[]
    NOT?: clientsScalarWhereInput | clientsScalarWhereInput[]
    id?: IntFilter<"clients"> | number
    office_id?: IntNullableFilter<"clients"> | number | null
    id_card?: StringNullableFilter<"clients"> | string | null
    name?: StringNullableFilter<"clients"> | string | null
    phone?: StringNullableFilter<"clients"> | string | null
    email?: StringNullableFilter<"clients"> | string | null
    address?: StringNullableFilter<"clients"> | string | null
  }

  export type paysUpsertWithWhereUniqueWithoutOfficesInput = {
    where: paysWhereUniqueInput
    update: XOR<paysUpdateWithoutOfficesInput, paysUncheckedUpdateWithoutOfficesInput>
    create: XOR<paysCreateWithoutOfficesInput, paysUncheckedCreateWithoutOfficesInput>
  }

  export type paysUpdateWithWhereUniqueWithoutOfficesInput = {
    where: paysWhereUniqueInput
    data: XOR<paysUpdateWithoutOfficesInput, paysUncheckedUpdateWithoutOfficesInput>
  }

  export type paysUpdateManyWithWhereWithoutOfficesInput = {
    where: paysScalarWhereInput
    data: XOR<paysUpdateManyMutationInput, paysUncheckedUpdateManyWithoutOfficesInput>
  }

  export type productsUpsertWithWhereUniqueWithoutOfficesInput = {
    where: productsWhereUniqueInput
    update: XOR<productsUpdateWithoutOfficesInput, productsUncheckedUpdateWithoutOfficesInput>
    create: XOR<productsCreateWithoutOfficesInput, productsUncheckedCreateWithoutOfficesInput>
  }

  export type productsUpdateWithWhereUniqueWithoutOfficesInput = {
    where: productsWhereUniqueInput
    data: XOR<productsUpdateWithoutOfficesInput, productsUncheckedUpdateWithoutOfficesInput>
  }

  export type productsUpdateManyWithWhereWithoutOfficesInput = {
    where: productsScalarWhereInput
    data: XOR<productsUpdateManyMutationInput, productsUncheckedUpdateManyWithoutOfficesInput>
  }

  export type productsScalarWhereInput = {
    AND?: productsScalarWhereInput | productsScalarWhereInput[]
    OR?: productsScalarWhereInput[]
    NOT?: productsScalarWhereInput | productsScalarWhereInput[]
    id?: IntFilter<"products"> | number
    name?: StringNullableFilter<"products"> | string | null
    price?: DecimalNullableFilter<"products"> | Decimal | DecimalJsLike | number | string | null
    office_id?: IntNullableFilter<"products"> | number | null
  }

  export type ticketsUpsertWithWhereUniqueWithoutOfficesInput = {
    where: ticketsWhereUniqueInput
    update: XOR<ticketsUpdateWithoutOfficesInput, ticketsUncheckedUpdateWithoutOfficesInput>
    create: XOR<ticketsCreateWithoutOfficesInput, ticketsUncheckedCreateWithoutOfficesInput>
  }

  export type ticketsUpdateWithWhereUniqueWithoutOfficesInput = {
    where: ticketsWhereUniqueInput
    data: XOR<ticketsUpdateWithoutOfficesInput, ticketsUncheckedUpdateWithoutOfficesInput>
  }

  export type ticketsUpdateManyWithWhereWithoutOfficesInput = {
    where: ticketsScalarWhereInput
    data: XOR<ticketsUpdateManyMutationInput, ticketsUncheckedUpdateManyWithoutOfficesInput>
  }

  export type usersUpsertWithWhereUniqueWithoutOfficesInput = {
    where: usersWhereUniqueInput
    update: XOR<usersUpdateWithoutOfficesInput, usersUncheckedUpdateWithoutOfficesInput>
    create: XOR<usersCreateWithoutOfficesInput, usersUncheckedCreateWithoutOfficesInput>
  }

  export type usersUpdateWithWhereUniqueWithoutOfficesInput = {
    where: usersWhereUniqueInput
    data: XOR<usersUpdateWithoutOfficesInput, usersUncheckedUpdateWithoutOfficesInput>
  }

  export type usersUpdateManyWithWhereWithoutOfficesInput = {
    where: usersScalarWhereInput
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyWithoutOfficesInput>
  }

  export type usersScalarWhereInput = {
    AND?: usersScalarWhereInput | usersScalarWhereInput[]
    OR?: usersScalarWhereInput[]
    NOT?: usersScalarWhereInput | usersScalarWhereInput[]
    id?: IntFilter<"users"> | number
    username?: StringFilter<"users"> | string
    password?: StringFilter<"users"> | string
    name?: StringNullableFilter<"users"> | string | null
    role?: Enumuser_roleNullableFilter<"users"> | $Enums.user_role | null
    office_id?: IntNullableFilter<"users"> | number | null
  }

  export type clientsCreateWithoutPaysInput = {
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    offices?: officesCreateNestedOneWithoutClientsInput
    tickets?: ticketsCreateNestedManyWithoutClientsInput
  }

  export type clientsUncheckedCreateWithoutPaysInput = {
    id?: number
    office_id?: number | null
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    tickets?: ticketsUncheckedCreateNestedManyWithoutClientsInput
  }

  export type clientsCreateOrConnectWithoutPaysInput = {
    where: clientsWhereUniqueInput
    create: XOR<clientsCreateWithoutPaysInput, clientsUncheckedCreateWithoutPaysInput>
  }

  export type officesCreateWithoutPaysInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsCreateNestedManyWithoutOfficesInput
    products?: productsCreateNestedManyWithoutOfficesInput
    tickets?: ticketsCreateNestedManyWithoutOfficesInput
    users?: usersCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateWithoutPaysInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsUncheckedCreateNestedManyWithoutOfficesInput
    products?: productsUncheckedCreateNestedManyWithoutOfficesInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutOfficesInput
    users?: usersUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesCreateOrConnectWithoutPaysInput = {
    where: officesWhereUniqueInput
    create: XOR<officesCreateWithoutPaysInput, officesUncheckedCreateWithoutPaysInput>
  }

  export type ticketsCreateWithoutPaysInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutPaysInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutPaysInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutPaysInput, ticketsUncheckedCreateWithoutPaysInput>
  }

  export type clientsUpsertWithoutPaysInput = {
    update: XOR<clientsUpdateWithoutPaysInput, clientsUncheckedUpdateWithoutPaysInput>
    create: XOR<clientsCreateWithoutPaysInput, clientsUncheckedCreateWithoutPaysInput>
    where?: clientsWhereInput
  }

  export type clientsUpdateToOneWithWhereWithoutPaysInput = {
    where?: clientsWhereInput
    data: XOR<clientsUpdateWithoutPaysInput, clientsUncheckedUpdateWithoutPaysInput>
  }

  export type clientsUpdateWithoutPaysInput = {
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    offices?: officesUpdateOneWithoutClientsNestedInput
    tickets?: ticketsUpdateManyWithoutClientsNestedInput
  }

  export type clientsUncheckedUpdateWithoutPaysInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    tickets?: ticketsUncheckedUpdateManyWithoutClientsNestedInput
  }

  export type officesUpsertWithoutPaysInput = {
    update: XOR<officesUpdateWithoutPaysInput, officesUncheckedUpdateWithoutPaysInput>
    create: XOR<officesCreateWithoutPaysInput, officesUncheckedCreateWithoutPaysInput>
    where?: officesWhereInput
  }

  export type officesUpdateToOneWithWhereWithoutPaysInput = {
    where?: officesWhereInput
    data: XOR<officesUpdateWithoutPaysInput, officesUncheckedUpdateWithoutPaysInput>
  }

  export type officesUpdateWithoutPaysInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUpdateManyWithoutOfficesNestedInput
    products?: productsUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUpdateManyWithoutOfficesNestedInput
    users?: usersUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateWithoutPaysInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUncheckedUpdateManyWithoutOfficesNestedInput
    products?: productsUncheckedUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutOfficesNestedInput
    users?: usersUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type ticketsUpsertWithoutPaysInput = {
    update: XOR<ticketsUpdateWithoutPaysInput, ticketsUncheckedUpdateWithoutPaysInput>
    create: XOR<ticketsCreateWithoutPaysInput, ticketsUncheckedCreateWithoutPaysInput>
    where?: ticketsWhereInput
  }

  export type ticketsUpdateToOneWithWhereWithoutPaysInput = {
    where?: ticketsWhereInput
    data: XOR<ticketsUpdateWithoutPaysInput, ticketsUncheckedUpdateWithoutPaysInput>
  }

  export type ticketsUpdateWithoutPaysInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutPaysInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type ticketsCreateWithoutPending_pay_ticketsInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutPending_pay_ticketsInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutPending_pay_ticketsInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutPending_pay_ticketsInput, ticketsUncheckedCreateWithoutPending_pay_ticketsInput>
  }

  export type ticketsUpsertWithoutPending_pay_ticketsInput = {
    update: XOR<ticketsUpdateWithoutPending_pay_ticketsInput, ticketsUncheckedUpdateWithoutPending_pay_ticketsInput>
    create: XOR<ticketsCreateWithoutPending_pay_ticketsInput, ticketsUncheckedCreateWithoutPending_pay_ticketsInput>
    where?: ticketsWhereInput
  }

  export type ticketsUpdateToOneWithWhereWithoutPending_pay_ticketsInput = {
    where?: ticketsWhereInput
    data: XOR<ticketsUpdateWithoutPending_pay_ticketsInput, ticketsUncheckedUpdateWithoutPending_pay_ticketsInput>
  }

  export type ticketsUpdateWithoutPending_pay_ticketsInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutPending_pay_ticketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type officesCreateWithoutProductsInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsCreateNestedManyWithoutOfficesInput
    pays?: paysCreateNestedManyWithoutOfficesInput
    tickets?: ticketsCreateNestedManyWithoutOfficesInput
    users?: usersCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateWithoutProductsInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsUncheckedCreateNestedManyWithoutOfficesInput
    pays?: paysUncheckedCreateNestedManyWithoutOfficesInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutOfficesInput
    users?: usersUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesCreateOrConnectWithoutProductsInput = {
    where: officesWhereUniqueInput
    create: XOR<officesCreateWithoutProductsInput, officesUncheckedCreateWithoutProductsInput>
  }

  export type ticket_detailsCreateWithoutProductsInput = {
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
    tickets: ticketsCreateNestedOneWithoutTicket_detailsInput
  }

  export type ticket_detailsUncheckedCreateWithoutProductsInput = {
    ticket_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsCreateOrConnectWithoutProductsInput = {
    where: ticket_detailsWhereUniqueInput
    create: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput>
  }

  export type ticket_detailsCreateManyProductsInputEnvelope = {
    data: ticket_detailsCreateManyProductsInput | ticket_detailsCreateManyProductsInput[]
    skipDuplicates?: boolean
  }

  export type officesUpsertWithoutProductsInput = {
    update: XOR<officesUpdateWithoutProductsInput, officesUncheckedUpdateWithoutProductsInput>
    create: XOR<officesCreateWithoutProductsInput, officesUncheckedCreateWithoutProductsInput>
    where?: officesWhereInput
  }

  export type officesUpdateToOneWithWhereWithoutProductsInput = {
    where?: officesWhereInput
    data: XOR<officesUpdateWithoutProductsInput, officesUncheckedUpdateWithoutProductsInput>
  }

  export type officesUpdateWithoutProductsInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUpdateManyWithoutOfficesNestedInput
    pays?: paysUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUpdateManyWithoutOfficesNestedInput
    users?: usersUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateWithoutProductsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUncheckedUpdateManyWithoutOfficesNestedInput
    pays?: paysUncheckedUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutOfficesNestedInput
    users?: usersUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type ticket_detailsUpsertWithWhereUniqueWithoutProductsInput = {
    where: ticket_detailsWhereUniqueInput
    update: XOR<ticket_detailsUpdateWithoutProductsInput, ticket_detailsUncheckedUpdateWithoutProductsInput>
    create: XOR<ticket_detailsCreateWithoutProductsInput, ticket_detailsUncheckedCreateWithoutProductsInput>
  }

  export type ticket_detailsUpdateWithWhereUniqueWithoutProductsInput = {
    where: ticket_detailsWhereUniqueInput
    data: XOR<ticket_detailsUpdateWithoutProductsInput, ticket_detailsUncheckedUpdateWithoutProductsInput>
  }

  export type ticket_detailsUpdateManyWithWhereWithoutProductsInput = {
    where: ticket_detailsScalarWhereInput
    data: XOR<ticket_detailsUpdateManyMutationInput, ticket_detailsUncheckedUpdateManyWithoutProductsInput>
  }

  export type ticket_detailsScalarWhereInput = {
    AND?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
    OR?: ticket_detailsScalarWhereInput[]
    NOT?: ticket_detailsScalarWhereInput | ticket_detailsScalarWhereInput[]
    ticket_id?: IntFilter<"ticket_details"> | number
    product_id?: IntFilter<"ticket_details"> | number
    quantity?: IntNullableFilter<"ticket_details"> | number | null
    discount?: DecimalNullableFilter<"ticket_details"> | Decimal | DecimalJsLike | number | string | null
  }

  export type productsCreateWithoutTicket_detailsInput = {
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    offices?: officesCreateNestedOneWithoutProductsInput
  }

  export type productsUncheckedCreateWithoutTicket_detailsInput = {
    id?: number
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
    office_id?: number | null
  }

  export type productsCreateOrConnectWithoutTicket_detailsInput = {
    where: productsWhereUniqueInput
    create: XOR<productsCreateWithoutTicket_detailsInput, productsUncheckedCreateWithoutTicket_detailsInput>
  }

  export type ticketsCreateWithoutTicket_detailsInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
    users?: usersCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutTicket_detailsInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutTicket_detailsInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutTicket_detailsInput, ticketsUncheckedCreateWithoutTicket_detailsInput>
  }

  export type productsUpsertWithoutTicket_detailsInput = {
    update: XOR<productsUpdateWithoutTicket_detailsInput, productsUncheckedUpdateWithoutTicket_detailsInput>
    create: XOR<productsCreateWithoutTicket_detailsInput, productsUncheckedCreateWithoutTicket_detailsInput>
    where?: productsWhereInput
  }

  export type productsUpdateToOneWithWhereWithoutTicket_detailsInput = {
    where?: productsWhereInput
    data: XOR<productsUpdateWithoutTicket_detailsInput, productsUncheckedUpdateWithoutTicket_detailsInput>
  }

  export type productsUpdateWithoutTicket_detailsInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    offices?: officesUpdateOneWithoutProductsNestedInput
  }

  export type productsUncheckedUpdateWithoutTicket_detailsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type ticketsUpsertWithoutTicket_detailsInput = {
    update: XOR<ticketsUpdateWithoutTicket_detailsInput, ticketsUncheckedUpdateWithoutTicket_detailsInput>
    create: XOR<ticketsCreateWithoutTicket_detailsInput, ticketsUncheckedCreateWithoutTicket_detailsInput>
    where?: ticketsWhereInput
  }

  export type ticketsUpdateToOneWithWhereWithoutTicket_detailsInput = {
    where?: ticketsWhereInput
    data: XOR<ticketsUpdateWithoutTicket_detailsInput, ticketsUncheckedUpdateWithoutTicket_detailsInput>
  }

  export type ticketsUpdateWithoutTicket_detailsInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutTicket_detailsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
  }

  export type paysCreateWithoutTicketsInput = {
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
    clients?: clientsCreateNestedOneWithoutPaysInput
    offices?: officesCreateNestedOneWithoutPaysInput
  }

  export type paysUncheckedCreateWithoutTicketsInput = {
    id?: number
    office_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysCreateOrConnectWithoutTicketsInput = {
    where: paysWhereUniqueInput
    create: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput>
  }

  export type paysCreateManyTicketsInputEnvelope = {
    data: paysCreateManyTicketsInput | paysCreateManyTicketsInput[]
    skipDuplicates?: boolean
  }

  export type pending_pay_ticketsCreateWithoutTicketsInput = {
    state?: string | null
    exp_date?: Date | string | null
    total_to_pay?: Decimal | DecimalJsLike | number | string | null
    total_payed?: Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsUncheckedCreateWithoutTicketsInput = {
    state?: string | null
    exp_date?: Date | string | null
    total_to_pay?: Decimal | DecimalJsLike | number | string | null
    total_payed?: Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsCreateOrConnectWithoutTicketsInput = {
    where: pending_pay_ticketsWhereUniqueInput
    create: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
  }

  export type ticket_detailsCreateWithoutTicketsInput = {
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
    products: productsCreateNestedOneWithoutTicket_detailsInput
  }

  export type ticket_detailsUncheckedCreateWithoutTicketsInput = {
    product_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsCreateOrConnectWithoutTicketsInput = {
    where: ticket_detailsWhereUniqueInput
    create: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput>
  }

  export type ticket_detailsCreateManyTicketsInputEnvelope = {
    data: ticket_detailsCreateManyTicketsInput | ticket_detailsCreateManyTicketsInput[]
    skipDuplicates?: boolean
  }

  export type clientsCreateWithoutTicketsInput = {
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    offices?: officesCreateNestedOneWithoutClientsInput
    pays?: paysCreateNestedManyWithoutClientsInput
  }

  export type clientsUncheckedCreateWithoutTicketsInput = {
    id?: number
    office_id?: number | null
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
    pays?: paysUncheckedCreateNestedManyWithoutClientsInput
  }

  export type clientsCreateOrConnectWithoutTicketsInput = {
    where: clientsWhereUniqueInput
    create: XOR<clientsCreateWithoutTicketsInput, clientsUncheckedCreateWithoutTicketsInput>
  }

  export type officesCreateWithoutTicketsInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsCreateNestedManyWithoutOfficesInput
    pays?: paysCreateNestedManyWithoutOfficesInput
    products?: productsCreateNestedManyWithoutOfficesInput
    users?: usersCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateWithoutTicketsInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsUncheckedCreateNestedManyWithoutOfficesInput
    pays?: paysUncheckedCreateNestedManyWithoutOfficesInput
    products?: productsUncheckedCreateNestedManyWithoutOfficesInput
    users?: usersUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesCreateOrConnectWithoutTicketsInput = {
    where: officesWhereUniqueInput
    create: XOR<officesCreateWithoutTicketsInput, officesUncheckedCreateWithoutTicketsInput>
  }

  export type usersCreateWithoutTicketsInput = {
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    offices?: officesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutTicketsInput = {
    id?: number
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
    office_id?: number | null
  }

  export type usersCreateOrConnectWithoutTicketsInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutTicketsInput, usersUncheckedCreateWithoutTicketsInput>
  }

  export type paysUpsertWithWhereUniqueWithoutTicketsInput = {
    where: paysWhereUniqueInput
    update: XOR<paysUpdateWithoutTicketsInput, paysUncheckedUpdateWithoutTicketsInput>
    create: XOR<paysCreateWithoutTicketsInput, paysUncheckedCreateWithoutTicketsInput>
  }

  export type paysUpdateWithWhereUniqueWithoutTicketsInput = {
    where: paysWhereUniqueInput
    data: XOR<paysUpdateWithoutTicketsInput, paysUncheckedUpdateWithoutTicketsInput>
  }

  export type paysUpdateManyWithWhereWithoutTicketsInput = {
    where: paysScalarWhereInput
    data: XOR<paysUpdateManyMutationInput, paysUncheckedUpdateManyWithoutTicketsInput>
  }

  export type pending_pay_ticketsUpsertWithoutTicketsInput = {
    update: XOR<pending_pay_ticketsUpdateWithoutTicketsInput, pending_pay_ticketsUncheckedUpdateWithoutTicketsInput>
    create: XOR<pending_pay_ticketsCreateWithoutTicketsInput, pending_pay_ticketsUncheckedCreateWithoutTicketsInput>
    where?: pending_pay_ticketsWhereInput
  }

  export type pending_pay_ticketsUpdateToOneWithWhereWithoutTicketsInput = {
    where?: pending_pay_ticketsWhereInput
    data: XOR<pending_pay_ticketsUpdateWithoutTicketsInput, pending_pay_ticketsUncheckedUpdateWithoutTicketsInput>
  }

  export type pending_pay_ticketsUpdateWithoutTicketsInput = {
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type pending_pay_ticketsUncheckedUpdateWithoutTicketsInput = {
    state?: NullableStringFieldUpdateOperationsInput | string | null
    exp_date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    total_to_pay?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    total_payed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUpsertWithWhereUniqueWithoutTicketsInput = {
    where: ticket_detailsWhereUniqueInput
    update: XOR<ticket_detailsUpdateWithoutTicketsInput, ticket_detailsUncheckedUpdateWithoutTicketsInput>
    create: XOR<ticket_detailsCreateWithoutTicketsInput, ticket_detailsUncheckedCreateWithoutTicketsInput>
  }

  export type ticket_detailsUpdateWithWhereUniqueWithoutTicketsInput = {
    where: ticket_detailsWhereUniqueInput
    data: XOR<ticket_detailsUpdateWithoutTicketsInput, ticket_detailsUncheckedUpdateWithoutTicketsInput>
  }

  export type ticket_detailsUpdateManyWithWhereWithoutTicketsInput = {
    where: ticket_detailsScalarWhereInput
    data: XOR<ticket_detailsUpdateManyMutationInput, ticket_detailsUncheckedUpdateManyWithoutTicketsInput>
  }

  export type clientsUpsertWithoutTicketsInput = {
    update: XOR<clientsUpdateWithoutTicketsInput, clientsUncheckedUpdateWithoutTicketsInput>
    create: XOR<clientsCreateWithoutTicketsInput, clientsUncheckedCreateWithoutTicketsInput>
    where?: clientsWhereInput
  }

  export type clientsUpdateToOneWithWhereWithoutTicketsInput = {
    where?: clientsWhereInput
    data: XOR<clientsUpdateWithoutTicketsInput, clientsUncheckedUpdateWithoutTicketsInput>
  }

  export type clientsUpdateWithoutTicketsInput = {
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    offices?: officesUpdateOneWithoutClientsNestedInput
    pays?: paysUpdateManyWithoutClientsNestedInput
  }

  export type clientsUncheckedUpdateWithoutTicketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUncheckedUpdateManyWithoutClientsNestedInput
  }

  export type officesUpsertWithoutTicketsInput = {
    update: XOR<officesUpdateWithoutTicketsInput, officesUncheckedUpdateWithoutTicketsInput>
    create: XOR<officesCreateWithoutTicketsInput, officesUncheckedCreateWithoutTicketsInput>
    where?: officesWhereInput
  }

  export type officesUpdateToOneWithWhereWithoutTicketsInput = {
    where?: officesWhereInput
    data: XOR<officesUpdateWithoutTicketsInput, officesUncheckedUpdateWithoutTicketsInput>
  }

  export type officesUpdateWithoutTicketsInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUpdateManyWithoutOfficesNestedInput
    pays?: paysUpdateManyWithoutOfficesNestedInput
    products?: productsUpdateManyWithoutOfficesNestedInput
    users?: usersUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateWithoutTicketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUncheckedUpdateManyWithoutOfficesNestedInput
    pays?: paysUncheckedUpdateManyWithoutOfficesNestedInput
    products?: productsUncheckedUpdateManyWithoutOfficesNestedInput
    users?: usersUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type usersUpsertWithoutTicketsInput = {
    update: XOR<usersUpdateWithoutTicketsInput, usersUncheckedUpdateWithoutTicketsInput>
    create: XOR<usersCreateWithoutTicketsInput, usersUncheckedCreateWithoutTicketsInput>
    where?: usersWhereInput
  }

  export type usersUpdateToOneWithWhereWithoutTicketsInput = {
    where?: usersWhereInput
    data: XOR<usersUpdateWithoutTicketsInput, usersUncheckedUpdateWithoutTicketsInput>
  }

  export type usersUpdateWithoutTicketsInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    offices?: officesUpdateOneWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutTicketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type ticketsCreateWithoutUsersInput = {
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsCreateNestedManyWithoutTicketsInput
    clients?: clientsCreateNestedOneWithoutTicketsInput
    offices?: officesCreateNestedOneWithoutTicketsInput
  }

  export type ticketsUncheckedCreateWithoutUsersInput = {
    id?: number
    office_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedCreateNestedManyWithoutTicketsInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedCreateNestedOneWithoutTicketsInput
    ticket_details?: ticket_detailsUncheckedCreateNestedManyWithoutTicketsInput
  }

  export type ticketsCreateOrConnectWithoutUsersInput = {
    where: ticketsWhereUniqueInput
    create: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput>
  }

  export type ticketsCreateManyUsersInputEnvelope = {
    data: ticketsCreateManyUsersInput | ticketsCreateManyUsersInput[]
    skipDuplicates?: boolean
  }

  export type officesCreateWithoutUsersInput = {
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsCreateNestedManyWithoutOfficesInput
    pays?: paysCreateNestedManyWithoutOfficesInput
    products?: productsCreateNestedManyWithoutOfficesInput
    tickets?: ticketsCreateNestedManyWithoutOfficesInput
  }

  export type officesUncheckedCreateWithoutUsersInput = {
    id?: number
    name?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    id_card?: string | null
    clients?: clientsUncheckedCreateNestedManyWithoutOfficesInput
    pays?: paysUncheckedCreateNestedManyWithoutOfficesInput
    products?: productsUncheckedCreateNestedManyWithoutOfficesInput
    tickets?: ticketsUncheckedCreateNestedManyWithoutOfficesInput
  }

  export type officesCreateOrConnectWithoutUsersInput = {
    where: officesWhereUniqueInput
    create: XOR<officesCreateWithoutUsersInput, officesUncheckedCreateWithoutUsersInput>
  }

  export type ticketsUpsertWithWhereUniqueWithoutUsersInput = {
    where: ticketsWhereUniqueInput
    update: XOR<ticketsUpdateWithoutUsersInput, ticketsUncheckedUpdateWithoutUsersInput>
    create: XOR<ticketsCreateWithoutUsersInput, ticketsUncheckedCreateWithoutUsersInput>
  }

  export type ticketsUpdateWithWhereUniqueWithoutUsersInput = {
    where: ticketsWhereUniqueInput
    data: XOR<ticketsUpdateWithoutUsersInput, ticketsUncheckedUpdateWithoutUsersInput>
  }

  export type ticketsUpdateManyWithWhereWithoutUsersInput = {
    where: ticketsScalarWhereInput
    data: XOR<ticketsUpdateManyMutationInput, ticketsUncheckedUpdateManyWithoutUsersInput>
  }

  export type officesUpsertWithoutUsersInput = {
    update: XOR<officesUpdateWithoutUsersInput, officesUncheckedUpdateWithoutUsersInput>
    create: XOR<officesCreateWithoutUsersInput, officesUncheckedCreateWithoutUsersInput>
    where?: officesWhereInput
  }

  export type officesUpdateToOneWithWhereWithoutUsersInput = {
    where?: officesWhereInput
    data: XOR<officesUpdateWithoutUsersInput, officesUncheckedUpdateWithoutUsersInput>
  }

  export type officesUpdateWithoutUsersInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUpdateManyWithoutOfficesNestedInput
    pays?: paysUpdateManyWithoutOfficesNestedInput
    products?: productsUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUpdateManyWithoutOfficesNestedInput
  }

  export type officesUncheckedUpdateWithoutUsersInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    clients?: clientsUncheckedUpdateManyWithoutOfficesNestedInput
    pays?: paysUncheckedUpdateManyWithoutOfficesNestedInput
    products?: productsUncheckedUpdateManyWithoutOfficesNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutOfficesNestedInput
  }

  export type paysCreateManyClientsInput = {
    id?: number
    office_id?: number | null
    ticket_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsCreateManyClientsInput = {
    id?: number
    office_id?: number | null
    user_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysUpdateWithoutClientsInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    offices?: officesUpdateOneWithoutPaysNestedInput
    tickets?: ticketsUpdateOneWithoutPaysNestedInput
  }

  export type paysUncheckedUpdateWithoutClientsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysUncheckedUpdateManyWithoutClientsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUpdateWithoutClientsInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutClientsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateManyWithoutClientsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type clientsCreateManyOfficesInput = {
    id?: number
    id_card?: string | null
    name?: string | null
    phone?: string | null
    email?: string | null
    address?: string | null
  }

  export type paysCreateManyOfficesInput = {
    id?: number
    ticket_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type productsCreateManyOfficesInput = {
    id?: number
    name?: string | null
    price?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsCreateManyOfficesInput = {
    id?: number
    user_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
  }

  export type usersCreateManyOfficesInput = {
    id?: number
    username: string
    password: string
    name?: string | null
    role?: $Enums.user_role | null
  }

  export type clientsUpdateWithoutOfficesInput = {
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUpdateManyWithoutClientsNestedInput
    tickets?: ticketsUpdateManyWithoutClientsNestedInput
  }

  export type clientsUncheckedUpdateWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    pays?: paysUncheckedUpdateManyWithoutClientsNestedInput
    tickets?: ticketsUncheckedUpdateManyWithoutClientsNestedInput
  }

  export type clientsUncheckedUpdateManyWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    id_card?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type paysUpdateWithoutOfficesInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    clients?: clientsUpdateOneWithoutPaysNestedInput
    tickets?: ticketsUpdateOneWithoutPaysNestedInput
  }

  export type paysUncheckedUpdateWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysUncheckedUpdateManyWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    ticket_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type productsUpdateWithoutOfficesInput = {
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    ticket_details?: ticket_detailsUpdateManyWithoutProductsNestedInput
  }

  export type productsUncheckedUpdateWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutProductsNestedInput
  }

  export type productsUncheckedUpdateManyWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: NullableStringFieldUpdateOperationsInput | string | null
    price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUpdateWithoutOfficesInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    users?: usersUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateManyWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type usersUpdateWithoutOfficesInput = {
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    tickets?: ticketsUpdateManyWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
    tickets?: ticketsUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateManyWithoutOfficesInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: NullableEnumuser_roleFieldUpdateOperationsInput | $Enums.user_role | null
  }

  export type ticket_detailsCreateManyProductsInput = {
    ticket_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUpdateWithoutProductsInput = {
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    tickets?: ticketsUpdateOneRequiredWithoutTicket_detailsNestedInput
  }

  export type ticket_detailsUncheckedUpdateWithoutProductsInput = {
    ticket_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUncheckedUpdateManyWithoutProductsInput = {
    ticket_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysCreateManyTicketsInput = {
    id?: number
    office_id?: number | null
    client_id?: number | null
    type?: string | null
    cash?: Decimal | DecimalJsLike | number | string | null
    transfer?: Decimal | DecimalJsLike | number | string | null
    card?: Decimal | DecimalJsLike | number | string | null
    sinpe?: Decimal | DecimalJsLike | number | string | null
    bank_check?: Decimal | DecimalJsLike | number | string | null
    mixed?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsCreateManyTicketsInput = {
    product_id: number
    quantity?: number | null
    discount?: Decimal | DecimalJsLike | number | string | null
  }

  export type paysUpdateWithoutTicketsInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    clients?: clientsUpdateOneWithoutPaysNestedInput
    offices?: officesUpdateOneWithoutPaysNestedInput
  }

  export type paysUncheckedUpdateWithoutTicketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type paysUncheckedUpdateManyWithoutTicketsInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    cash?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    transfer?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    card?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    sinpe?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    bank_check?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    mixed?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUpdateWithoutTicketsInput = {
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    products?: productsUpdateOneRequiredWithoutTicket_detailsNestedInput
  }

  export type ticket_detailsUncheckedUpdateWithoutTicketsInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticket_detailsUncheckedUpdateManyWithoutTicketsInput = {
    product_id?: IntFieldUpdateOperationsInput | number
    quantity?: NullableIntFieldUpdateOperationsInput | number | null
    discount?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsCreateManyUsersInput = {
    id?: number
    office_id?: number | null
    client_id?: number | null
    type?: string | null
    vehicle_plate?: string | null
    date?: Date | string | null
    needs_facture?: boolean | null
    total?: Decimal | DecimalJsLike | number | string | null
  }

  export type ticketsUpdateWithoutUsersInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUpdateManyWithoutTicketsNestedInput
    clients?: clientsUpdateOneWithoutTicketsNestedInput
    offices?: officesUpdateOneWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateWithoutUsersInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    pays?: paysUncheckedUpdateManyWithoutTicketsNestedInput
    pending_pay_tickets?: pending_pay_ticketsUncheckedUpdateOneWithoutTicketsNestedInput
    ticket_details?: ticket_detailsUncheckedUpdateManyWithoutTicketsNestedInput
  }

  export type ticketsUncheckedUpdateManyWithoutUsersInput = {
    id?: IntFieldUpdateOperationsInput | number
    office_id?: NullableIntFieldUpdateOperationsInput | number | null
    client_id?: NullableIntFieldUpdateOperationsInput | number | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    vehicle_plate?: NullableStringFieldUpdateOperationsInput | string | null
    date?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    needs_facture?: NullableBoolFieldUpdateOperationsInput | boolean | null
    total?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}