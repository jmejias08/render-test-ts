// pages/index.tsx
export default function Home() {
  return <h1>Bienvenido a la app</h1>;
}