import { GetServerSideProps } from 'next';
import jwt from 'jsonwebtoken';
import nookies from 'nookies';

type Props = {
  username: string;
  role: string;
  officeId: number;
};

export default function Dashboard({ username, role, officeId }: Props) {
  return (
    <div style={{ padding: 20 }}>
      <h1>Bienvenido {username}</h1>
      <p>Rol: {role}</p>
      <p>Oficina ID: {officeId}</p>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const cookies = nookies.get(ctx);
  const token = cookies.token;

  if (!token) {
    return {
      redirect: {
        destination: '/login',
        permanent: false
      }
    };
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as {
      username: string;
      role: string;
      officeId: number;
    };

    return {
      props: decoded
    };
  } catch {
    return {
      redirect: {
        destination: '/login',
        permanent: false
      }
    };
  }
};
