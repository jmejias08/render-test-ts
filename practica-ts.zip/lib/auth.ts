import jwt from 'jsonwebtoken';
import { NextApiRequest } from 'next';

export function getUserFromRequest(req: NextApiRequest) {
  const token = req.cookies.token;
  if (!token) return null;

  try {
    return jwt.verify(token, process.env.JWT_SECRET!) as {
      username: string;
      role: string;
      officeId: number;
    };
  } catch {
    return null;
  }
}
